All information on documentation of IT4KT can be found on site https://pages.kpi.fei.tuke.sk/it4kt/it4kt-builder/


Guide to run code in WSL (Linux)

1. Install Python in WSL

sudo apt update

sudo apt install python3 python3-venv python3-pip

2.  Create a Virtual Environment in project folder

cd C:\Users\User\Desktop\course-master

python -m venv venv

3. Activate the Virtual Environment

venv\Scripts\activate

4. Install Dependencies

pip install -r requirements.txt

5. Run the Build scriopt

chmod +x build.sh

./build.sh


Guide to run code in Command Prompt (Windows)

1. Download python https://www.python.org/downloads/windows/

2. Create a Virtual Environment in project folder

cd C:\Users\User\Desktop\course-master

3. Activate the Virtual Environment

venv\Scripts\activate

4. Install Dependencies

pip install -r requirements.txt

5. Run the Build scriopt

build.bat
