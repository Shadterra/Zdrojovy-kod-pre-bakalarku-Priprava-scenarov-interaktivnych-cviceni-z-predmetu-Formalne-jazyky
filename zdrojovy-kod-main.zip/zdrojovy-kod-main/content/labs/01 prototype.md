---
Nadpis: Úvod do formálnych jazykov, Operácie nad jazykmi, Úvod do regulárnych výrazov
---

## Ciele

  1. {ciel_organizacia} Oboznámiť sa s organizáciou cvičení predmetu Formálne jazyky.
  2. {ciel_uvoddoformaljazykov} Prejsť úvod do formálnych jazykov a naučiť sa základné pojmy.
  3. {ciel_gramatika} Oboznámiť sa z operáciami na jazykmi a ich abecedami.
  4. {ciel_regexp} Oboznámiť sa z regulárnymi výrazmi.
  5. {ciel_regexp_cvic} Prakticky precvičiť zostavenie vybraných regulárnych výrazov.


## Úvod

Na tomto cvičení sa oboznámite s organizáciou cvičení a podmienkami udelenia priebežného hodnotenia (zápočtu). Následne si prejdeme úvodom do formálnych, približíme si základné pojmy, a oboznámime sa z operáciami nad jazykmi a ich abecedami. V poslednom rade si preberieme regulárne výrazy a konečno-stavové automaty akceptujúce vstup podľa zadaného regulárneho výrazu. Tieto zručnosti si prakticky overíte na cvičení.

## Krok {ciel_organizacia}

Oboznámte sa s [organizáciou cvičení predmetu Formálne jazyky a prekladače](resources/FJ_cvicenia.pdf) a podmienkami udelenia zápočtu.

> Vyučujúci:
> Študijné materiály na prednášky sú v systéme Moodle - <https://moodle.fei.tuke.sk>, predmet Formálne jazyky a prekladače. Prihlasovací kľúč na predmet je „mudricitajuknihy”.


## Krok {ciel_uvoddoformaljazykov}

Programovací jazyk je prostriedok, v ktorom programátor formuluje algoritmické problémy. Formálne jazyky a gramatiky predstavujú teoretické prostriedky, pomocou ktorých je možné popísať syntax počítačových jazykov.
Zohrávajú kľúčovú úlohu nielen pri definovaní programovacích jazykov, ale aj pri vývoji kompilátorov(prekladačov), ktoré umožňujú transformáciu programov do podoby vykonateľnej počítačom zvanej jazyk strojových inštrukcii. 

>* Programovací jazyk – jazyk pre špecifikáciu algoritmov
>* Program – zápis algoritmu v programovacom jazyku
>* Jazyk strojových inštrukcií - jazyk, v ktorom je problém pripravený na vykonanie v počítači

Programátori sú ľudia, uvažujú abstraktne a vyjadrujú sa pomocou slov a symbolov. Počítače sú stroje, ktoré dokážu realizovať veľmi jednoduché úlohy v rámci stanovených pravidiel.
Našou úlohou je sa naučiť ako vieme komunikovať s počítačom v rámci matematicky presnými konštrukčnými pravidlami a byť schopný dekonštruovať problém na abecedu a gramatiku, aby sme potom vedeli naprogramovať počítač na manipuláciu s nimi. 
Napríklad, ak vezmeme abecedu pozostávajúcu z písmen a, b, c, formálny jazyk nad touto abecedou môže byť množina {a, aa, aba, ca}. 
Samozrejme, takýto jazyk nie je až tak užitočný. Pointa je, že so solídnym súborom konštrukčných pravidiel je môžné vytvoriť jazyk ako C alebo PostScript.

<!-- Nahradné vysvetlenie toto by malo byt zakomentovane a nezobrazovať sa
Formálny jazyk je súbor reťazcov symbolov zobraných z konečnej abecedy. 
Formálny jazyk môže byť špecifikovaný buď súborom pravidiel (ako sú regulárne výrazy alebo bezkontextová gramatika), ktoré generujú jazyk, alebo formálnym strojom, ktorý jazyk akceptuje (rozpoznáva). 
Formálny stroj berie reťazce symbolov ako vstup a výstupy buď „áno“ alebo „nie“. 
Hovorí sa, že stroj akceptuje jazyk, ak povie „áno“ všetkým a iba tým reťazcom, ktoré sú v jazyku. 
Alternatívne môže byť jazyk definovaný ako množina reťazcov, pre ktoré konkrétny stroj povie „áno“.
https://www.sciencedirect.com/topics/computer-science/formal-language
https://www.quora.com/What-is-the-purpose-of-formal-languages-in-computer-science
-->

Na pochopenie formálnych jazykov je potrebné zoznámiť sa s niekoľkými základnými pojmami:

**1) Abeceda – Konečná neprázdna množina prvkov zvané symboly.**
* Napríklad nech A je abeceda a obsahuje symboly a, b, c. 
* Zápis je nasledovný $A = \{ a, b, c \}$


**2) Reťazec - Ľubovoľná konečná postupnosť symbolov z abecedy.**
* Napríklad nech A je abeceda. Potom ľubovoľnú konečnú postupnosť symbolov z A nazývame **reťazcom** (slovom,vetou) nad abecedou A.
* **a)** Počet symbolov v reťazci $x$ nazývame dĺžkou reťazca a označujeme $|x|$ 
* Reťazec môže mať nulovú dĺžku a teda sa nazýva prázny reťazec $\{\epsilon\}$ . <br>
> Prázdny reťazec $\{\epsilon\}$ nezávisí od abecedy, pretože neobsahuje žiadne symboly. To znamená, že je súčasťou akejkoľvek množiny reťazcov A, bez ohľadu na to, aké symboly abeceda A obsahuje.

* **b)** Existuje aj pojem zvaný obrátený reťazec. Ak $ x = a_1 \dots a_n $ je reťazec nad abecedou A, potom obrátený reťazec k reťazcu $x$ je reťazec:
$$ x^R = a_n \dots a_1 $$


* **c)** Je možné aj spojiť reťazce pomocou operáce zvanej zreťazenie. Nech $u = a_1...a_j$ a $v = b_1...b_k$ sú reťazce nad abecedou A. <br>
Potom zreťazenie reťazcov $u$ a $v$ je reťazec $u.v$ (alebo skrátene $uv$), 
>
> $$ u \cdot v = a_1 \dots a_j b_1 \dots b_k $$

* **d)** Ak $x$ je reťazec a i ≥ 0 je prirodzené číslo, potom reťazec 
> $$ x^i = x \cdot x \cdot x \cdot \dots \text{ až po } i $$
> je reťazec, ktorý vznikne zreťazením i kópií reťazca x.

> Príklad:
> a) Nech je reťazec $y = abc$ tak jeho dĺžka je $|y|=3$  <br>
> b) Nech je reťazec $y = abc$ tak jeho obrátený reťazec je $ x^R = cba $ <br>
> c) Nech je reťazec $y = abc$ a $x = pov$ tak jeho zreťazenie je $yx = abcpov$ <br>
> d) Nech je reťazec $y = abc$ tak $ x^3 = abcabcabc$ <br>

**3) Abeceda (rozšírenie)**
* Nech A je abeceda. Potom:
* Ak $x, y, z$ sú tri reťazce, potom $x$ je predponou, $y$ je podreťazcom az je príponou reťazca $xyz$.
* Symbolom $ A^* $ označujeme množinu všetkých reťazcov nad abecedou $A$.
* Symbolom $ A^+ = A^* − \{\epsilon\}$ množinu všetkých neprázdnych reťazcov nad abecedou A.
* Symbolom $A_{\epsilon}$ označujeme tzv. rozšírenú abecedu, $ A_{\epsilon} = A \cup \{\epsilon\} $


**4) Formálny jazyk – Ľubovoľná podmnožina množiny všetkých možných reťazcov nad danou abecedou.**
* **a)** Napríklad nech A je abeceda. ľubovoľnú podmnožinu $L$ množiny $ A^* $ nazývame (formálnym) jazykom nad abecedou $A$.
* **b)** Nech $L_1$, $L_2$ sú jazyky. Potom ich zreťazením nazývame jazyk 
>  $$ L_1 L_2 = \{ xy, x \in L_1 \text{ a zároveň } y \in L_2 \} $$
* **c)** Nech $L$ je jazyk nad abecedou A. Potom jeho doplnkom $L^C$ (alebo komplementom) nazývame jazyk, ktorý obsahuje všetky reťazce nad abecedou A, ktoré nepatria do $L$.
>  $$ L^C = A^* - L $$
* **d)** Nech L je jazyk. Potom jeho n-tou mocninou $L^n$ nazývame jazyk definovaný takto: 
> $$ L^0 = \{ \epsilon \} $$ (kde ϵ je prázdny reťazec)  <br>
> $$ L^{k+1} = L \cdot L^k $$ <br>
> čo znamená, že množina $ L^{k+1} $ sa skladá zo všetkých reťazcov, ktoré vzniknú zreťazením reťazca $L$ s ľubovoľným reťazcom z $ L^k $.









> Príklad:
> a) Ak $ A = \{ a, b \} $ , potom $A^*$ zahŕňa reťazce ako ϵ, aa, bb, abab, baba, aabaab, babbab atď. <br>
> Ak by jazyk obsahoval len reťazce, ktoré začínajú písmenom "a", <br>
> bol by to jazyk $ L = \{ a, aa, ab, aab, \dots \} $, čo je podmnožina $A^*$.

> Príklad:
> B) Nech máme jazyk $ L_1 = \{ a, ab \} $ a jazyk $ L_2 = \{ b, ba \} $ . <br>
> Potom ich zreťazenie vyzerá nasledujúco <br>
> $ L_1 L_2 = \{ a \cdot b, a \cdot ba, ab \cdot b, ab \cdot ba \} = \{ ab, aba, abb, abba \} $ <br>

> Príklad:
> c) Nech máme abecedu $ A = \{ a, b \} $. Jazyk $L$ nech obsahuje len reťazce začínajúce na "a", teda: <br>
> $ L = \{ a, ab, aa, aab, aba, \dots \} $ <br>
> Doplnok $L^C$ obsahuje všetky ostatné reťazce nad A, ktoré nezačínajú na "a", teda: <br>
> $ L^C = \{ \epsilon, b, bb, ba, bab, bba, \dots \} $

> Príklad:
> d) Nech máme jazyk L={a,ab}. Vypočítajme jeho prvé mocniny:
> 1) $ L^0 : L^0 = \{ \epsilon \} $
> 2) $ L^1 = \{ a, ab \} $
> 3) $ L^2 = L \cdot L^1 : $ Zreťazujeme každý reťazec z $ L $ s každým reťazcom z $ L^1 $
> $$ L^2 = \{ a \cdot a, a \cdot ab, ab \cdot a, ab \cdot ab \} = \{ aa, aab, aba, abab \} $$ <br>
> 4) $ L^3 = L \cdot L^2 : $ Zreťazujeme každý reťazec z $ L $ s každým reťazcom z $ L^2 $
> $$ L^3 = \{ aaa, aaab, aaba, aabab, abaa, abaab, ababa, ababab \} $$



> Úloha:
> Nech $ L = \{ \epsilon, a \} $. Určte prvky jazyka $L^3$ a počet prvkov reťazca $w$ ktorý obsahuje všetky symboly začínajúce na a.

> Vyučujúci:
> $ L^2 = \{ \epsilon, a, aa, aaa \} $ a $|w|=3$

> Úloha:
> Máme reťazec $ t = bg3 $ . Spravte zreťazenie reťazca t a druhej mocniny obráteného reťazca t.

> Vyučujúci:
> $ t \cdot t^R^2 = bg3 \cdot 3gb3gb = bg33gb3gb $


> Úloha:
> Nech $ L = \{ a, x, po \} $ je jazyk nad abecedou $ G = \{ a, b, c, x, 1, po, d \} $ . Určte komplement jazyka L.
><details>
  <summary>Zobraziť riešenie</summary>
  <p><strong>Odpoveď:</strong></p>
  Kedže definícia komplementu je nasledovná $ L^C = G^* - L $ <br>
  Komplement $L^C$ obsahuje: <br>
  -Všetky reťazce, ktoré obsahujú symboly b,c,1,d <br>
  -Všetky reťazce, ktoré obsahujú symboly a,x,po v iných kombináciách ako a,x,po <br>
  -Prázdny reťazec ε.<br>
  Správna odpoveď: $ L^C = G^* - {a,x,po} $
</details>

> Vyučujúci:
> Kedže definícia komplementu je nasledovná $ L^C = G^* - L $ <br>
> Komplement $L^C$ obsahuje: <br>
> -Všetky reťazce, ktoré obsahujú symboly b,c,1,d <br>
> -Všetky reťazce, ktoré obsahujú symboly a,x,po v iných kombináciách ako a,x,po <br>
> -Prázdny reťazec ε.<br>
> Odpoveď: $ L^C = G^* - \{a,x,po\} $













## Krok {ciel_gramatika}

**Operácie nad jazykmi a ich abecedami**

V teórii formálnych jazykov sa taktiež pracuje s množinovými operáciami nad jazykmi. Tieto operácie nám umožňujú kombinovať jazyky a vytvárať nové jazyky z existujúcich. Medzi základné operácie patrí:

**1) Zjednotenie**
* Zjednotenie dvoch jazykov L1​ a L2 je jazyk, ktorý obsahuje všetky reťazce z L1​ a všetky reťazce z L2​. 
* Zápis: $$L1∪L2$$​
* Príklad: L1 = {a,ab}, L2 = {b,ba} → L1 ∪ L2 = {a, ab, b, ba}.


**2) Prienik**
* Prienik dvoch jazykov L1​ a L2​ je jazyk, ktorý obsahuje len tie reťazce, ktoré sú súčasne v L1​ aj L2​. 
* Zápis: $$L1∩L2$$
* Príklad: L1 ​= {a,ab,abc}, L2 = {ab,abc,abcd} → L1 ​∩ L2 ​= {ab,abc}


**3) Rozdiel**
* Rozdiel dvoch jazykov L1 a L2​ je jazyk, ktorý obsahuje reťazce z L1​, ktoré nie sú v L2. 
* Zápis: $$L1−L2$$
* Príklad: L1 ​= {a,ab,abc}, L2 = {ab,abc} → L1 ​− L2 ​= {a}


**4) Zreťazenie**
* Zreťazenie dvoch jazykov L1​ a L2 je jazyk, ktorý obsahuje všetky reťazce, ktoré vzniknú zreťazením reťazca z L1​ s reťazcom z L2. 
* Zápis: $$L1⋅L2$$​ alebo $$L1L2​$$
* Príklad: L1 ​= {a,ab}, L2 = {b,ba} → L1​⋅L2 ​= {ab,aba,abb,abba}


**5) Iterácia (nazývaná aj Kleeneho uzáver )**
* Iterácia jazyka L je jazyk, ktorý obsahuje všetky možné zreťazenia reťazcov z L, vrátane prázdneho reťazca ε. 
![Definícia Kleeneho uzáver, iterácia ](resources/kleeneho-hviezdicka.png)
* Zápis: $$L^*$$
* Príklad: L = {a,b} → L<sup>\*</sup> = {ε,a,b,aa,ab,ba,bb,aaa,…}


**6) Pozitívny uzáver (nazývaný aj Kleeneho kladný uzáver)**
* Iterácia jazyka L je jazyk, ktorý obsahuje všetky možné zreťazenia reťazcov z L, ale bez prázdneho reťazca ε.
![Kleeneho kladný uzáver, kladná iterácia ](resources/kleeneho-plus.png) 
* Zápis: $$L^+$$
* Príklad: L = {a,b} → L<sup>+</sup> = {a,b,aa,ab,ba,bb,aaa,…}


> Úloha:
> Máme jazyky $ L_1 = \{ aa, ab, ba, bb \}, \quad L_2 = \{ a, b \}. $
> Určte prienik jazyka $L_1$ a druhej mocniny jazyka $L_2$. 

> Vyučujúci:
> $ L_*2^2 = \{ aa, ab, ba, bb \} $ <br>
> $ L_1 \cap L_2^2 = \{ aa, ab, ba, bb \} $ <br>

> Úloha:
> Nech $A$ je ľubovoľná abeceda. Určte prvky jazyka $A^* – A^+$ a počet prvkov tohto jazyka.

> Vyučujúci:
> Nezáleží na abecede, výsledok je $ A^* - A^+ = \{ \epsilon \} $ <br>











## Krok {ciel_regexp}
Regulárne výrazy sú základným pojmom v teoretickej informatike a poskytujú stručný formalizmus na opis regulárnych jazykov. <br>

Zopakujte si [teóriu regulárnych výrazov](resources/regularne_vyrazy.pdf). <br>

 
 Regulárne výrazy sa môžu zapisovať rôznymi spôsobmi. V tabuľke je v druhom stĺpci uvedený zjednodušený zápis, ktorý sa používa na tomto predmete. V treťom stĺpci je uvedený zápis, s ktorým sa najčastejšie môžete stretnúť v existujúcich implementáciách regulárnych výrazov. Väčšina zápisov regulárnych výrazov tiež ponúka viaceré skrátené zápisy pre celé skupiny znakov.

  Regulárny výraz | Zjednodušený zápis (používaný na tomto predmete) | Zápis bežný v implementáciách
 ---|---|---
 **postupnosť (zoskupenie)** | `(xy)` | `(xy)`
 **alternatíva (x alebo y)** | `x\|y` | `x\|y`
 **tranzitívny uzáver (0 alebo viac krát)** | `{x}` | `(x)*`
 **opakovanie (1 alebo viac krát)** | `x{x}` | `(x)+`
 **voliteľnosť (0 alebo 1 krát)** | `[x]` | `(x)?` <br>
<br>
<br>

**1) Postupnosť (Zoskupenie)**
* Označujeme $(xy)$ čo znamená, že sa prvky objavia postupne za radom.
* Regex: $(abcd)$
* Popisuje reťazec: abcd

**2) Alternatíva**
* Označujeme $x|y$ čo znamená, že sa objaví buď prvok x alebo y.
* Regex: $a|b$
* Popisuje reťazce: a alebo b 

**3) Tranzitívny uzáver**
* Označujeme $\{x\}$ čo znamená, že sa prvok neobjaví alebo sa objaví viac krát.
![Definícia tranzitívneho (Kleeneho) uzáveru množiny r ](resources/tranzitivny-uzaver.png) 
* Regex: $ab\{c\}$
* Popisuje reťazce: ab, abc, abccc...


**4) Opakovanie**
* Označujeme $x\{x\}$ čo znamená, že sa prvok objaví aspoň raz alebo viac krát.
* Regex: $abc\{c\}$
* Popisuje reťazce: abc, abccc, abccccc...


**5) Volitelnosť**
* Označujeme $[x]$ čo znamená, že sa prvok neobjaví alebo sa objaví najviac raz.
* Regex: $colo[u]r$
* Popisuje reťazce: color alebo colour


Regulárne výrazy je možné zobraziť aj graficky pomocou **prechodových diagramov**. Princíp zostrojenia takéhoto diagramu je znázornený na obrázku.
![Princíp zostrojenia prechodového diagramu pre regulárny výraz](resources/prechodovy-diagramV2.png)


> Príklad:
> Postupnosť má vyššiu prioritu ako alternatíva! 
> Preto pozor napr. na prípady podobné tomuto:
>  
> ```
> a b | c {d} 
> ```
>je to isté ako    
> ```
> (a b) | (c {d})
> ```
>  
>![Ukážka prechodového diagramu pre regulárny výraz  `a b | c {d}` ](resources/p-diagram-abcd-príklad.png)
>
>
> Najvyššiu prioritu majú zátvorky. Preto ich používanie môže zabrániť nejednoznačnosti:
>  
> ```
> a (b | c) {d} 
> ```
>![Ukážka prechodového diagramu pre regulárny výraz  `a (b | c) {d}` ](resources/p-diagram-abcd2-príklad.png)



> Úloha:
> Regulárny výraz pre binárne numerály:
>
> ```
> 0 | 1 {0 | 1}
> ```
>
> Nakreslite prechodový diagram pre tento regulárny výraz. <br>
> Aký tvar môžu nadobúdať binárne numerály podľa uvedeného regulárneho výrazu?
><details>
  <summary>Zobraziť riešenie</summary>
  <p><strong>Odpoveď:</strong></p>
  
  Na zostrojenie regúlarného výrazu je doležite isť krok za krokom. <br>
  Tento výraz nám alternatíva delí na 2 časti: 0 a 1 {0 | 1}  <br>
  Začneme vyobrazením 0. <br>
  ![1 krok](resources/binarne-numeraly-1.png)
  Ďalej je na rade alternatíva 1 avšak vieme že za ňou bude nasledovať niečo dalšie takže si vyhradíme dostatok miesta.  <br>
  ![2 krok](resources/binarne-numeraly-2.png)
  Teraz prichádza na radu tranzitívny uzáver v ktorom sa nachádza alternatíva. Najprv vyobrazíme 0. <br>
  ![3 krok](resources/binarne-numeraly-3.png)
  A následne k tranzitívnemu uzáveru pripojíme 1 ktorá nenasléduje za 0 ale musí byť vyobrazená tak by bolo možné prejsť cez 0  **alebo** 1. <br>
  ![4 krok](resources/binarne-numeraly-prechodovy.png)
  Máme zostrojený prechodový diagram. <br>
  Na zobrazenie tvarov ktoré môže nadobúdať tento výraz je možne prechádzať diagram prstom v smere šípok. <br>
  Možme začať tým, že prejdeme prvú časť diagramu kde je možné nadobudnúť iba "0". <br>
  Prechádzaním druhej časti môžme zisiť že je možné nadobudnúť "1" alebo<br> 
  prechádzaním tranzitívneho uzáveru vieme nadobudnúť tvary ako sú "10", "11", "100", "101", a tak ďalej až do nekonečna. <br> 
  Takže tento regulárny výraz vie nadobúdať tvary "0", "1", "10", "11", "100", "101", "111", "1000" atď. <br> 
</details>




## Krok {ciel_regexp_cvic}

> Úloha:
> Skonštruujte regulárny výraz pre všetky reťazce pozostávajúce zo znakov *a* a *b*, ktorý obsahuje podreťazec *abba*.
>
><details>
  <summary>Zobraziť riešenie</summary>
  <p><strong>Odpoveď:</strong></p>
  <pre>{a|b}abba{a|b}</pre>
</details>

> Vyučujúci:
> `{a|b}abba{a|b}`


> Úloha:
> Skonštruujte regulárny výraz pre všetky reťazce pozostávajúce zo znakov *x* a *y*, v ktorých je každý výskyt znaku *y* bezprostredne nasledovaný postupnosťou troch znakov *x*.
>
><details>
  <summary>Zobraziť riešenie</summary>
  <p><strong>Odpoveď:</strong></p>
  <pre>{x|(yxxx)}</pre>
</details>

> Vyučujúci:
> `{x|(yxxx)}`


> Úloha:
> Skonštruujte regulárny výraz pre všetky reťazce pozostávajúce zo znakov *p* a *q*, ktoré obsahujú nepárny počet znakov *q*.
><details>
  <summary>Zobraziť riešenie</summary>
  <p><strong>Odpoveď:</strong></p>
  <pre>{p} q {(q {p} q) | p}</pre>
</details>

> Vyučujúci:
> `{p} q {(q {p} q) | p}`



> Úloha:
> Skonštruujte regulárny výraz pre overenie zápisu identifikátora.
>
> Zápis identifikátora má nasledujúce vlastnosti:
> * identifikátor môže (a nemusí) začínať znakom $,
> * následne prvý znak môže byť len malé alebo veľké písmeno latinskej abecedy,
> * ďalšie znaky (ak sa v pomenovaní vyskytujú) môžu tvoriť ľubovoľnú kombináciu malých alebo veľkých písmen latinskej abecedy alebo ľubovoľné číslice.
>
><details>
  <summary>Zobraziť riešenie</summary>
  <p><strong>Odpoveď:</strong></p>
  <pre>[$]?(a-z|A-Z){a-z|A-Z|0-9}*</pre>
</details>

> Vyučujúci:
> `[$](a-z|A-Z){a-z|A-Z|0-9}`

> Úloha:
> Skonštruujte regulárny výraz pre overenie zápisu rodného čísla (podľa slovenskej legislatívy).
>
> V zápise rodného čísla:
> * sa môže vyskytovať oddeľovač '/', prípadne zápis neobsahuje žiaden oddeľovač,
> * skupina číslic za oddeľovačom môže mať dĺžku 3 alebo 4 znaky,
> * sa pri mesiacoch vyskytujú dve možné postupnosti: 01-12, 51-62.
>
><details>
  <summary>Zobraziť riešenie</summary>
  <p><strong>Odpoveď:</strong></p>
  <pre>(0-9)(0-9)(0|1|5|6)(0-9)(0-3)(0-9)[/](0-9)(0-9)(0-9)[0-9]</pre>
</details>

> Vyučujúci:
> `(0-9)(0-9)(0|1|5|6)(0-9)(0-3)(0-9)[/](0-9)(0-9)(0-9)[0-9]`



> Úloha:
> Skonštruujte regulárny výraz pre overenie zápisu reálneho čísla.
>
> Zápis čísla má nasledujúce vlastnosti:
> * číslo môže byť kladné alebo záporné,
> * číslo môže a nemusí obsahovať desatinnú časť,
> * číslo musí mať vyjadrenú celú časť na aspoň jednu platnú číslicu,
> * ak číslo obsahuje aj desatinnú časť, aj tá musí byť vyjadrená na aspoň jednu platnú číslicu,
> * oddeľovač celej a desatinnej časti môže byť znak desatinnej čiarky ',' alebo desatinnej bodky '.'
>
> Ako zabezpečíte, aby numerál neobsahoval nevýznamné nuly zľava?
>
><details>
  <summary>Zobraziť riešenie</summary>
  <p><strong>Odpoveď:</strong></p>
  <pre>[+|-] (0 | (1-9) {0-9}) [(.|;) ((1-9) | {0-9}(1-9))]</pre>
</details>

> Vyučujúci:
> `[+|-] (0 | (1-9) {0-9}) [(.|;) ((1-9) | {0-9}(1-9))]`


> Úloha:
> Zostrojte prechodové diagramy pre regulárne výrazy z predchádzajúcich úloh.



## Doplňujúce zdroje
Vizualizačné nástroje znázorňujúce proces rozpoznávania textu na základe regulárnych výrazov využívajúce znázornenie na ich prechodových diagramoch.
  * [regex visualizer](https://27t.github.io/regex-visualizer/)
  * [debuggex](http://www.debuggex.com/)
  * [regex101](https://regex101.com/)

> Poznámka:
> Všetky nástroje používajú alternatívny bežný zápis regulárnych výrazov, s ktorým ste sa oboznámili na tomto cvičení. Tento zápis sa nebude používať na cvičeniach ani na skúške, zíde sa však pri implementácii programov. Pred použitím oboch vizualizačných nástrojov odporúčame dôkladne sa oboznámiť so vstupným tvarom regulárnych výrazov, ktoré obidva nástroje používajú.



## Dotazník na ohodnotenie učiva
Vážení študenti, <br>
poprosil by som Vás o vyplnenie tohto [dotazníka](https://forms.gle/Fhv3JgbkcHkjDptG7) .   <br>

Tento dotazník slúži na ohodnotenie vašich skúseností s pripravenými materiálmi z prvého cvičenia. Na vylepšovaní učiva sa aktívne pracuje a Vaše odpovede nám pomôžu zlepšiť kvalitu výučby. <br>

Ďakujem<br>