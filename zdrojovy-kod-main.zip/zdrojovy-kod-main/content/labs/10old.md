---
Nadpis: Opakovanie a prehĺbenie učiva.
---

## Ciele

  1. {ciel_opakovanie} Opakovanie a prehĺbenie učiva - gramatiky LL(1).
  2. {ciel_zadanie} Konzultácie k zadaniu č. 2.


## Úvod

Cieľom cvičenia prehĺbenie teoretických vedomostí formou testu s tvorbou odpovede. V druhej časti cvičenia je možnosť prediskutovať prípadné otázky k projektu č. 2.

## Krok {ciel_opakovanie}

Na nasledujúcich úlohách si zopakujte doteraz prebraté učivo o LL gramatikách.

> Úloha:
> Daná je nasledujúca gramatika
> $$\begin{array}{l}
> S \rightarrow ABaDb ~|~ aB ~|~ D	\\
> A \rightarrow Ba ~|~ c ~|~ \varepsilon	\\
> B \rightarrow d ~|~ \varepsilon	\\
> D \rightarrow \varepsilon
> \end{array}$$
>
> Zistite, či daná gramatika je LL(1).
>

> Úloha:
> Daná je nasledujúca gramatika
> $$\begin{array}{l}
> S \rightarrow CBA	\\
> A \rightarrow aXB	\\
> X \rightarrow Ad ~|~ \varepsilon	\\
> B \rightarrow \varepsilon ~|~ C \\
> C \rightarrow g ~|~ \varepsilon
> \end{array}$$
>
> Zistite, či daná gramatika je LL(1).
>

## Krok {ciel_zadanie}

Prediskutujte s pedagógom prípadné otázky a nejasnosti k projektu č. 2.