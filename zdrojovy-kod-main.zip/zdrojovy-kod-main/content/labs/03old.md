---
Nadpis: Úvod do lexikálnej analýzy.
---

## Ciele

1. {ciel_gramatika} Zopakovať si definíciu gramatiky a porozumieť odvodeniu gramatiky zo špecifikácie jazyka.
2. {ciel_bnf} Naučiť sa definovať gramatiku jazyka pomocou BNF.
3. {ciel_kontrola} Diskusia a priebežná kontrola.


## Úvod
Pretože gramatiky majú v oblasti prekladačov nezastupiteľnú rolu, je ďalším cieľom pochopenie vzťahu medzi gramatikou a jazykom a následné odvodenie gramatiky z danej špecifikácie jazyka.

## Krok {ciel_gramatika}

Gramatika je usporiadaná štvorica *G = (N, T, P, S)*, kde:
* *N* je množina neterminálnych symbolov,
* *T* je množina terminálnych symbolov,
* *P* je množina pravidiel,
* *S* je počiatočný (štartovací) symbol gramatiky.

> Úloha:
> Je daná gramatika *G = ({S, A, B}, {a, b, c}, P, S)* s nasledujúcimi pravidlami:\
> *S → BAB | ABA*\
> *A → AB | aA | ab*\
> *B → BA | b*
>
> a) Určte typ gramatiky.\
> b) Nájdite odvodenie slova *abbbab* v danej gramatike.
>

> Vyučujúci:
> *S ⇒ ABA ⇒ ABBA ⇒ abBBA ⇒ abbBA ⇒ abbbA ⇒ abbbab*\
> Gramatika je bezkontextová (viď tvary pravidiel).

## Krok {ciel_bnf}

Na vyjadrenie gramatiky jazyka sa väčšinou používa _Backusova-Naurova forma (BNF)_, prípadne niektoré jej rozšírenia. Na tomto predmete to bude rozšírená Backusova-Naurova forma (Extended BNF).

Základnými prvkami gramatiky sú pravidla a symboly, pričom symboly môžu byť terminálne (také, ktoré môžu byť prítomné na vstupe), alebo neterminálne. Pravidla budeme zapisovať v takomto tvare:
 
```
neterminal → postupnosť symbolov a operátorov
```

Pri zápisoch budeme používať tie isté operátory, aké boli použité v zápisoch regulárnych výrazov a v regulárnych jazykoch.

Zápis | Význam
------|----------
`\|`  | alternatíva
`{}`  | opakovanie 0 alebo viac krát
`[]`  | voliteľnosť

Ako príklad uveďme jazyk pre vyjadrenie štruktúr údajov (entít), s ktorými pracuje aplikácia. Pre každú štruktúru je uvedený jej názov a zoznam vlastností spolu s ich typmi. Napríklad firemná aplikácia môže pracovať s údajmi o oddeleniach a osobách. Na vyjadrenie toho, že niektoré vlastností sú povinné, je možné použiť kľúčové slovo "required". Veta v tomto jazyku môže teda vyzerať napríklad takto:
 
```
entity Person
    name : string required
    age : int
    salary : real
end
entity Department
    name : string required
    description : string
end
```

Gramatiku tohto jazyka môžeme vyjadriť napríklad naseldujúcim spôsobom ( **id** a reťazce v úvodzovkách predstavujú terminálne symboly):
 
 
```
Entities → { Entity }
Entity   → "entity" id { Property } "end"
Property → id ":" Type [ "required" ]
Type     → "int" | "real" | "string"
```

> Úloha:
> Definujte syntax jazyka konfiguračných parametrov. Parametre majú tvar "`názov = hodnota`", pričom hodnota môže byť celé číslo, alebo pravdivostná hodnota označená kľučovým slovom `yes` alebo `no`. Parametre sú zaradené do sekcií a každá sekcia musí začínať názvom uvedeným v hranatých zátvorkach. Príklad:
>  
>  
> ```
> [window]
> maximized = no
> width = 420
> height = 300
>  
> [history]
> store = yes
> limit = 120
> ```

> Vyučujúci:
>   
> ```
> Configuration → { Section }
> Section       → "[" id "]" { Property }
> Property      → id "=" Value
> Value         → number | "yes" | "no"
> ```

## Krok {ciel_kontrola}

Spolu s pedagógom prediskutuje riešenia vybraných úloh z [predošlého cvičenia](02.html).