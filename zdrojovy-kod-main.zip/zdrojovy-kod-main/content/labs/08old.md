---
Nadpis: Bezkontextové gramatiky, zásobníkové automaty, LL(1) parsovanie
---

## Ciele

  1. {id_zhodnotenie} Kontrola úloh z predošlého cvičenia.
  2. {id_za} Zopakovať si vlastnosti zásobníkových automatov a naučiť sa ich skonštruovať.
  3. {id_cfg} Zopakovať si vlastnosti bezkontextových gramatík a prehĺbiť poznatky o LL(1) parsovaní.


## Úvod

Cieľom cvičenia je opakovanie, prehĺbenie a precvičenie učiva zameraného na bezkontextové gramatiky, zásobníkové automaty a LL(1) parsovanie.

## Krok {id_zhodnotenie}

> Úloha:
> Prekontrolujte a prediskutujte riešenia úloh z cvičenia 7.

## Krok {id_za}

> Úloha:
> Navrhnite zásobníkový automat pre jazyk $L(M) = \left\{ a^{n}b^{2n}~  |  ~n \geq 1\right\}$, $n \in \mathbb{N}$.
>

> Vyučujúci:
> Riešenie je v dokumente https://kurzy.kpi.fei.tuke.sk/fj/labs/resources/ti_priklady.pdf na str. 31, pr. 4.2
> alebo tu: https://www.geeksforgeeks.org/npda-for-accepting-the-language-l-anb2n-n1-u-anbn-n1/
>

## Krok {id_cfg}

V tomto kroku vyriešime dve úlohy zamerané na vlastnosti bezkontextových gramatík.

> Úloha:
> Daná je nasledujúca gramatika:
>
>$$\begin{array}{ll}
> (1) & S \rightarrow A\#	\\
> (2) & A \rightarrow xAx	\\
> (3) & A \rightarrow C	\\
> (4) & B \rightarrow yBy	\\
> (5) & B \rightarrow C	\\
> (6) & C \rightarrow zBz	\\
> (7) & C \rightarrow wAw	\\
> (8) & C \rightarrow \varepsilon	\\
> \end{array}$$
>
> a) Určte množiny $N$, $T$.
>
> b) Skonštruujte deriváciu reťazca $xzzx\#$ začínajúc v $S$. Vyznačte, ktoré odvodzovacie pravidlá ste použili a nakreslite odvodzovací strom podľa Vašej derivácie.
>
> c) Nájdite množiny $\mathit{FIRST}$ a $\mathit{FOLLOW}$ pre každý neterminálny symbol gramatiky.
>
> d) Pre každé pravidlo gramatiky skonštruujte množinu $\mathit{PREDICT}$.
>
> e) Zostavte rozkladovú tabuľku pre danú gramatiku. Zistite, či daná gramatika je LL(1) gramatikou. Svoju odpoveď odôvodnite.
>
> f) Ukážte kroky, ktoré by váš analyzátor realizoval na analýzu vstupu $xzyyzx\#$.

> Vyučujúci:
> a) $T = \left\{x, y, z, w, \#\right\}$, $N=\left\{ S, A, B, C\right\}$.
> 
> b)
>$$\begin{array}{lll}
> S & \rightarrow A\#	& (1)	\\
> 	& \rightarrow xAx\#	& (2)	\\
> 	& \rightarrow xCx\#	&	(3)	\\
>	& \rightarrow xzBzx\#	&	(6)	\\
> 	& \rightarrow xzCzx\#	&	(5)	\\
>	& \rightarrow xzzx\#	&	(8)\\
> \end{array}$$
> Strom odvodenia vyplýva priamo z derivácie.
>
> c)
>
>$$\begin{array}{ll}
> \mathit{FIRST}(S) = \left\{ x, z, w, \# \right\} & \mathit{FOLLOW}(S) = \left\{ \right\}	\\
> \mathit{FIRST}(A) = \left\{ x, z, w, \varepsilon \right\} & \mathit{FOLLOW}(A) = \left\{ \#, x, w \right\}	\\
> \mathit{FIRST}(B) = \left\{ y, z, w, \varepsilon\right\} & \mathit{FOLLOW}(B) = \left\{ y, z \right\}	\\
> \mathit{FIRST}(C) = \left\{ z, w, \varepsilon\right\} & \mathit{FOLLOW}(C) = \left\{ \#, x, y, z, w \right\}	\\
> \end{array}$$
>
> d)
>$$\begin{array}{l}
> \mathit{PREDICT}(1) = \left\{ x, z, w, \# \right\}	\\
> \mathit{PREDICT}(2) = \left\{ x \right\}	\\
> \mathit{PREDICT}(3) = \left\{ z, w, x, \# \right\}	\\
> \mathit{PREDICT}(4) = \left\{ y \right\}	\\
> \mathit{PREDICT}(5) = \left\{ z, w, y \right\}	\\
> \mathit{PREDICT}(6) = \left\{ z \right\}	\\
> \mathit{PREDICT}(7) = \left\{ w \right\}	\\
> \mathit{PREDICT}(8) = \left\{ \#, x, y, z, w \right\}	\\
> \end{array}$$
>
> e)
>
>  |       |   x   |   y   |   z   |   w   |   #   |  
>  |  ---  |  :----:  |  :----:  |  :----:  |  :----:  |  :----:  |  
>  |   S   |    1   |       |   1    |   1    |   1    |  
>  |   A   |    2, 3   |       |   3    |   3    |   3    |  
>  |   B   |       |   4, 5    |   5    |   5    |       |  
>  |   C   |    8   |   8    |   6, 8    |   7, 8    |   8    |  
>
> Uvedená gramatika **nie je** LL(1) gramatikou, pretože v rozkladovej tabuľke sú konflikty.
>
> f) Analyzátor by nemohol analyzovať daný reťazec, pretože v tabuľke analýzy sú konflikty.


> Úloha:
> Daná je nasledujúca gramatika:
>
>$$\begin{array}{ll}
> (1) & S \rightarrow AB\#	\\
> (2) & A \rightarrow xA	\\
> (3) & A \rightarrow B	\\
> (4) & B \rightarrow yzB	\\
> (5) & B \rightarrow z	\\
> \end{array}$$
>
> a) Určte množiny $N$, $T$.
>
> b) Skonštruujte strom odvodenia pre vstupný reťazec $xyzzz\#$
>
> c) Nájdite množiny $\mathit{FIRST}$ a $\mathit{FOLLOW}$ pre každý neterminálny symbol gramatiky.
>
> d) Pre každé pravidlo gramatiky skonštruujte množinu $\mathit{PREDICT}$.
>
> e) Zostavte rozkladovú tabuľku pre danú gramatiku. Zistite, či daná gramatika je LL(1) gramatikou. Svoju odpoveď odôvodnite.
>
> f) Ak do danej gramatiky pridáme pravidlo $A \rightarrow \varepsilon$, zmení sa jej klasifikácia? Svoju odpoveď odôvodnite.

> Vyučujúci:
> a) $T = \left\{x, y, z, \#\right\}$, $N=\left\{ S, A, B \right\}$.
> 
> b)
> ![Strom odvodenia pre reťazec xyzzz\#](resources/cv8/xyzzz-stromodvodenia.png)
>
>
> c)
>
>$$\begin{array}{ll}
> \mathit{FIRST}(S) = \left\{ x, y, z \right\} & \mathit{FOLLOW}(S) = \left\{ \right\}	\\
> \mathit{FIRST}(A) = \left\{ x, y, z \right\} & \mathit{FOLLOW}(A) = \left\{ y, z \right\}	\\
> \mathit{FIRST}(B) = \left\{ y, z \right\} & \mathit{FOLLOW}(B) = \left\{ y, z, \# \right\}	\\
> \end{array}$$
>
> d)
>$$\begin{array}{l}
> \mathit{PREDICT}(1) = \left\{ x, y, z \right\}	\\
> \mathit{PREDICT}(2) = \left\{ x \right\}	\\
> \mathit{PREDICT}(3) = \left\{ y, z \right\}	\\
> \mathit{PREDICT}(4) = \left\{ y \right\}	\\
> \mathit{PREDICT}(5) = \left\{ z \right\}	\\
> \end{array}$$
>
> e)
>
>  |       |   x   |   y   |   z   |   #   |  
>  |  ---  |  :----:  |  :----:  |  :----:  |  :----:  |  
>  |   S   |    1   |    1   |   1    |      |  
>  |   A   |    2   |    3   |   3    |      |  
>  |   B   |       |   4    |   5    |      |  
>
> Uvedená gramatika **je** LL(1) gramatikou, pretože v rozkladovej tabuľke **nie sú** konflikty.
>
> f) Označme nové pravidlo $A \rightarrow \varepsilon$ poradovým číslom (6). Množiny $\mathit{FIRST}$ a $\mathit{FOLLOW}$ sa zmenia nasledovne:
>$$\begin{array}{ll}
> \mathit{FIRST}(S) = \left\{ x, y, z \right\} & \mathit{FOLLOW}(S) = \left\{ \right\}	\\
> \mathit{FIRST}(A) = \left\{ x, y, z, \varepsilon \right\} & \mathit{FOLLOW}(A) = \left\{ y, z \right\}	\\
> \mathit{FIRST}(B) = \left\{ y, z \right\} & \mathit{FOLLOW}(B) = \left\{ y, z, \# \right\}	\\
> \end{array}$$
>
> *Pozn.* Žiadna z množín $\mathit{FOLLOW}$ sa nezmenila.
>
> Množiny $\mathit{PREDICT}$
>$$\begin{array}{l}
> \mathit{PREDICT}(1) = \left\{ x, y, z \right\}	\\
> \mathit{PREDICT}(2) = \left\{ x \right\}	\\
> \mathit{PREDICT}(3) = \left\{ y, z \right\}	\\
> \mathit{PREDICT}(4) = \left\{ y \right\}	\\
> \mathit{PREDICT}(5) = \left\{ z \right\}	\\
> \mathit{PREDICT}(6) = \left\{ y, z \right\}	\\
> \end{array}$$
>
> *Pozn.* Množina $\mathit{PREDICT}(6)$ je rovnaká ako $\mathit{FOLLOW}(A)$.
>
> Ak by sme zostavili rozkladovú tabuľku pre túto novú gramatiku, dostaneme:
>
>  |       |   x   |   y   |   z   |   #   |  
>  |  ---  |  :----:  |  :----:  |  :----:  |  :----:  |  
>  |   S   |    1   |    1   |   1    |      |  
>  |   A   |    2   |    3, 6   |   3, 6    |      |  
>  |   B   |       |   4    |   5    |      |  
>
> Z uvedeného je zrejmé, že sme našli konflikt: pokiaľ expandujeme neterminál $A$ a vidíme na pravej symboly $y$ alebo $z$, potom nevieme, či je možný prepis na $B$ pomocou pravidla (3) alebo jeho odstránenie (prepis na $\varepsilon$) použitím pravidla (6). Gramatika teda nie je LL(1) gramatikou.