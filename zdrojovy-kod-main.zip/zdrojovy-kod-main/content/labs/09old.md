---
Nadpis: Jazyk definície KSA. Základy syntaktickej analýzy zdola-nahor.
---

## Ciele

  1. {ciel_uloha} Doménovo-špecifický jazyk pre definíciu stavového automatu a implementácia jeho prekladača.


## Úvod

V tomto cvičení sa zameriame na úvod do implementácie prekladača, ktorý zo špecifikácie v doménovo-špecifickom jazyku pre definíciu stavového automatu vygeneruje jeho implementáciu v jazyku C.

## Krok {ciel_uloha}

Úlohou je implementovať program, ktorý zo súboru zapísanom v doménovo špecifickom jazyku (DSL) pre definíciu stavového automatu vygeneruje jeho implementáciu v jazyku C. [Podrobnosti sú uvedené tu](https://kurzy.kpi.fei.tuke.sk/fj/assignments/2.html). Úloha spočíva v implementácii *transkompiltátora* (*transpiler*, *transcompiler*) zo zdrojovej podoby v DSL do cieľovej podoby v C.

![Transkompilátor](resources/cv9/transpiler-mod.jpg)


> Úloha:
> Zamyslite sa nad návrhom implementácie. Formulujte požiadavky na:
> * čítanie vstupu,
> * rozbor a spracovanie používateľského vstupu,
> * gramatiku pre jazyk stavového automatu,
> * implementáciu pravidiel gramatiky,
> * štruktúru tried, z ktorých bude pozostávať projekt (Lexer, Parser, Generator a pod.),
> * vyhodnotenie vstupu a poskytnutie výsledku.
>
> Svoj návrh **si odložte pre ďalšie použitie**.