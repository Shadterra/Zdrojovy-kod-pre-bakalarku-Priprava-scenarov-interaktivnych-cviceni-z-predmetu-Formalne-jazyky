---
Nadpis: Syntaktická analýza.
---

## Ciele

  1. {ciel_gramatika} Precvičiť základné vlastnosti gramatík.
  2. {ciel_mnoziny} Precvičiť určovanie množín `FIRST` a `FOLLOW`
  3. {ciel_operatory} Precvičiť typy odvodení a odvodzovacie stromy.


## Úvod

Tematický zámer cvičenia je rozdelený do dvoch logických celkov. V prvej (teoretickej) časti cvičenia sa venuje čas precvičeniu a upevneniu vedomostí nadobudnutých na prednáške: určenie základných vlastností gramatík a vlastností z nej vyplývajúcich, určenie množín `FIRST` a `FOLLOW` potrebných vo fáze syntaktickej analýzy.

## Krok {ciel_gramatika}

> Úloha:
> Daná je nasledujúca gramatika:
>
>$$\begin{array}{l}
> S \rightarrow AB	\\
> A \rightarrow xB ~|~ \varepsilon	\\
> B \rightarrow yA ~|~ zB
> \end{array}$$
>
>
> Odpovedzde na nasledujúce otázky týkajúce sa uvedenej gramatiky:
> 1) Vymenujte terminály a neterminály.
> 2) Vymenujte aspoň štyri príklady reťazcov jazyka definovaného danou gramatikou.
> 3) Nakreslite odvodzovací strom pre čiastočnú deriváciu $$S \Rightarrow xyyA$$
> 4) Je táto čiastočná derivácia ľavá alebo pravá?
> 5) Uveďte príklad čiastočnej derivácie z `S` v dvoch krokoch pomocou pravej derivácie.

> Vyučujúci:
> 1) Terminály - `x`, `y`, `z`. Neterminály: `S`, `A`, `B`
> 2) `y`, `zy`, `xyy`, `xyxzyy`, a pod.
> 3) ![Strom odvodenia](resources/cv6/parse-1.png)
> 4) ľavá derivácia
> 5) Dve možnosti: $$ S \Rightarrow AB \Rightarrow AyA$$ $$S \Rightarrow AB \Rightarrow AzB$$
>

## Krok {ciel_mnoziny}

> Úloha:
> Daná je nasledujúca gramatika:
>
>$$\begin{array}{l}
> A \rightarrow BC	\\
> B \rightarrow Ax ~|~ x ~|~ \varepsilon	\\
> C \rightarrow yC ~|~ y ~|~ \varepsilon
> \end{array}$$
>

>
> Nájdite množiny `FIRST(-)` a `FOLLOW(-)` pre neterminály `A, B, C`.

> Vyučujúci:
> `FIRST(A) = {x, y, ε}`, `FOLLOW(A) = {x}`\
> `FIRST(B) = {x, y, ε}`, `FOLLOW(B) = {x, y}`\
> `FIRST(C) = {y, ε}`, `FOLLOW(C) = {x}`
>

> Úloha:
> Daná je nasledujúca gramatika:
>
>$$\begin{array}{l}
> Prog \rightarrow Stmt	\\
> Stmt \rightarrow \mathbf{if}~ Expr~ \mathbf{then}~ Block	\\
> Stmt \rightarrow \mathbf{while}~ Expr~ \mathbf{do}~ Block	\\
> Stmt \rightarrow Expr \mathbf{;}	\\
> Expr \rightarrow Term \Rightarrow \mathbf{id}\\	
> Expr \rightarrow \mathbf{isZero}~Term\\
> Expr \rightarrow \mathbf{not}~Expr\\
> Expr \rightarrow \mathbf{++}~\mathbf{id}\\
> Expr \rightarrow \mathbf{--}~\mathbf{id}\\
> Term \rightarrow \mathbf{id}\\
> Term \rightarrow \mathbf{const}\\
> Block \rightarrow Stmt\\
> Block \rightarrow \left\{ Stmts \right\} \\
> Stmts \rightarrow Stmt~Stmts\\
> Stmts \rightarrow \varepsilon\\
> \end{array}$$
>
> Nájdite množiny `FIRST(-)` a `FOLLOW(-)` pre jednotlivé neterminály.
>

> Vyučujúci:
>
> $$\begin{array}{l}
> \mathit{FIRST}(Prog) = \left\{ \mathbf{if}, \mathbf{while}, \mathbf{id}, \mathbf{const}, \mathbf{isZero}, \mathbf{not}, ++, -- \right\}	\\
> \mathit{FIRST}(Stmt) = \left\{ \mathbf{if}, \mathbf{while}, \mathbf{id}, \mathbf{const}, \mathbf{isZero}, \mathbf{not}, ++, -- \right\}	\\
> \mathit{FIRST}(Expr) = \left\{ \mathbf{id}, \mathbf{const}, \mathbf{isZero}, \mathbf{not}, ++, -- \right\}	\\
> \mathit{FIRST}(Term) = \left\{ \mathbf{id}, \mathbf{const} \right\}	\\
> \mathit{FIRST}(Block) = \left\{ '\left\{\right.', \mathbf{if}, \mathbf{while}, \mathbf{id}, \mathbf{const}, \mathbf{isZero}, \mathbf{not}, ++, -- \right\}	\\
> \mathit{FIRST}(Block) = \left\{ \varepsilon, \mathbf{if}, \mathbf{while}, \mathbf{id}, \mathbf{const}, \mathbf{isZero}, \mathbf{not}, ++, -- \right\}	\\
> \mathit{FOLLOW}(Prog) = \left\{\varepsilon \right\}	\\
> \mathit{FOLLOW}(Stmt) = \left\{ \varepsilon, \mathbf{if}, \mathbf{while}, \mathbf{id}, \mathbf{const}, \mathbf{isZero}, \mathbf{not}, ++, -- \right\}	\\
> \mathit{FOLLOW}(Expr) = \left\{ \mathbf{then}, \mathbf{do}, \mathbf{;} \right\}	\\
> \mathit{FOLLOW}(Term) = \left\{ \Rightarrow, \mathbf{then}, \mathbf{do}, \mathbf{;} \right\}	\\
> \mathit{FOLLOW}(Block) = \left\{ \varepsilon, \mathbf{if}, \mathbf{while}, \mathbf{id}, \mathbf{const}, \mathbf{isZero}, \mathbf{not}, ++, -- \right\}	\\
> \mathit{FOLLOW}(Stmts) = \left\{'\left.\right\}' \right\}
> \end{array}$$
>

## Krok {ciel_operatory}

V tomto kroku navrhneme gramatiku pre implementáciu vreckovej kalkulačky aritmetických výrazov. Tento typ kalkulačky obvykle nezohľadňuje štandardné matematické priority operátorov, avšak môže obsahovať zátvorky.

> Úloha:
> Zostrojte gramatiku pre vreckovú kalkulačku, v ktorej operátory sčítania, odčítania, násobenia (príp. celočíselného delenia) majú štandardnú asociatívnosť a rovnakú prioritu. Jazyk nech obsahuje aj zátvorky.
>
> Nájdite dve rôzne najľavejšie odvodenia vety $$\mathbf{id}+\mathbf{id}*\mathbf{id}$$ a zostrojte príslušné odvodzovacie stromy.
>

> Vyučujúci:
> a) $$E \Rightarrow E+E \Rightarrow \mathbf{id}+E \Rightarrow \mathbf{id}+E*E \Rightarrow \mathbf{id}+\mathbf{id}*E \Rightarrow \mathbf{id}+\mathbf{id}*\mathbf{id}$$
>
> b) $$E \Rightarrow E*E \Rightarrow E+E*E \Rightarrow \mathbf{id}+E*E \Rightarrow \mathbf{id}+\mathbf{id}*E \Rightarrow \mathbf{id}+\mathbf{id}*\mathbf{id}$$
>
> ![Stromy odvodenia](resources/cv6/parsetrees.jpg)