---
Nadpis: Úvod do formálnych gramatík.
---

## Ciele

  1. {ciel_zakladne_definicie} Oboznámiť sa so základnými definíciami formálnych gramatík.
  2. {ciel_bnf_ebnf} Pochopiť základnú definíciu BNF (Backusova-Naurova forma) a EBNF (Rozvinutá Backusova-Naurova forma).
  3. {ciel_vytvaranie_gramatik} Naučiť sa vytvárať formálne gramatiky na základe množinovej špecifikácie jazyka a fragmentu jazyka.
  4. {ciel_ulohy} Naučiť sa zostrojiť gramatiku podľa špecifikácie.

## Úvod

V tomto cvičení sa oboznámime so základnými pojmami formálnych gramatík, spôsobmi ich zápisu (BNF a EBNF) a praktickými príkladmi ich použitia.

## Krok {ciel_zakladne_definicie}

Začnime so základnými definíciami potrebnými na pochopenie formálnych gramatík.

<br>

**Formálna gramatika** je štvorica **G=(N,T,P,S)** kde:
 - $N$ je konečná neprázdna množina neterminálnych symbolov (neterminálov).
 - $T$ je konečná množina terminálnych symbolov (terminálov), pričom $N \cap T = ∅$.
 - $S \in N$ je začiatočný (alebo štartovací) symbol gramatiky $a$.
 - $P$ je množina (prepisovacích) pravidiel, ktorá je konečnou podmnožinou množiny $(N \cup T)^* N (N \cup T)^* \times (N \cup T)^*$.

> Poznámka: 
> Neterminálne symboly (neterminály) sú pomocné symboly používané v pravidlách gramatiky. Tieto symboly sú nahradené (substituované) počas derivácie. Zvyčajne sa označujú veľkými písmenami, napr. A, B, C. <br>

> Poznámka: 
> Terminálne symboly (terminály) tvoria abecedu výsledného jazyka. V prípade regulárnych a bezkontextových gramatík sa tieto symboly sa v procese derivácie už ďalej nenahrádzajú. Zvyčajne sa označujú malými písmenami, napr. a, b, c. <br>

> Poznámka: 
> Prepisovacie pravidlá definujú, ako môžu byť neterminálne symboly nahradené reťazcami terminálov a neterminálov.


> Poznámka: 
> Výraz $(N \cup T)^* N (N \cup T)^* \times (N \cup T)^*$ definuje množinu usporiadaných dvojíc (α,β), kde:
> * α je reťazec z $(N \cup T)^* N (N \cup T)^*$, ktorý obsahuje aspoň jeden neterminálny symbol.
> * β je ľubovoľný reťazec $(N \cup T)^*$ (môže byť aj prázdny) zložený z terminálov a neterminálov. 
> * $ \times $ je kartezíansky súčin.
>
> <br>
>
> V kontexte formálnych gramatík tento zápis špecifikuje typ prepisovacích pravidiel. Konkrétne sa vzťahuje k definícii prepisovacích pravidiel typu 0 (neobmedzené gramatiky) v Chomského hierarchii, kde:
> * Pravidlo má tvar α→β.
> * Ľavá strana pravidla (α) musí obsahovať aspoň jeden neterminálny symbol.
> * Pravá strana pravidla (β) môže byť ľubovoľný reťazec (vrátane prázdneho reťazca).

---

Na základe tvaru prepisovacích pravidiel sú definované určité hierarchické triedy gramatík a jazykov. <br>
Existujú štyri základné triedy rozdelenia formálnych jazykov definované N. Chomským. <br>

<br>

Nech G=(N,T,P,S) je gramatika. Potom hovoríme, že gramatika G je: <br>

* **Frázová** (alebo typu 0), ak sa na tvar prepisovacích pravidiel nekladú žiadne ďalšie obmedzenia: $$ \alpha \to \beta $$ kde $\alpha \in (N \cup T)^* N (N \cup T)^*$. 

<br>

* **Kontextová** (alebo typu 1), ak každé prepisovacie pravidlo z P má tvar: $$ \alpha \to \beta $$ kde $\alpha \in (N \cup T)^* N (N \cup T)^+$ a platí $|\alpha| \leq |\beta|$.  

<br>

* **Bezkontextová** (alebo typu 2), ak každé prepisovacie pravidlo z P má tvar: $$ A \to \alpha $$ kde $ A \in N \quad $ a $\quad \alpha \in (N \cup T)^*$. 

<br>

* **Regulárna** (alebo typu 3), ak každé prepisovacie pravidlo z P má jeden z tvarov: $$ A \to bB \quad \text{alebo} \quad A \to b $$ kde $ A,B \in N $ a $ b \in T$ .

<br>
<br>


| Typ   | Typ gramatiky           | Tvar pravidiel |
|-------|-------------------------|----------------|
| $G_0$ | frázová gramatika       | $ \alpha \to \beta $ |
| $G_1$ | kontextová gramatika    | $ \alpha_1 A \alpha_2 \to \alpha_1 \beta \alpha_2 $ |
| $G_2$ | bezkontextová gramatika | $ A \to \alpha $ |
| $G_3$ | regulárna gramatika     | $ A \to bB $, $ A \to b $ |

<br>

Medzi jazykmi generovanými jednotlivými typmi gramatík platí nasledujúci vzťah:
$$ L(G_3) \subseteq L(G_2) \subseteq L(G_1) \subseteq L(G_0) .$$

---

**Reláciu krok odvodenia** (alebo **reláciu derivácie**) **⇒** definujeme na množine reťazcov zložených z terminálnych aj neterminálnych symbolov gramatiky $(N \cup T)^*$  nasledujúcim spôsobom: 
$$\alpha \beta \gamma \Rightarrow \alpha \delta \gamma$$

(čítame: z reťazca αβγ je možné priamo odvodiť (alebo derivovať) reťazec αδγ), ak v $P$ existuje pravidlo 
$$\beta \rightarrow \delta, \text{ pričom } \alpha, \gamma, \delta \in (N \cup T)^* \text{ a } \alpha \beta \in (N \cup T)^* N (N \cup T)^*.$$

---

Nech G=(N,T,P,S) je gramatika a $ \alpha_i \in (N \cup T)^* \text{ pre } i = 0,1,\ldots,k $. <br>
Potom hovoríme, že reťazec $ \alpha_k $ sa dá odvodiť z reťazca $ \alpha_0 $ (na $k$ krokov), ak platí, že 
$$ \alpha_i \in (N \cup T)^* \text{ pre } i = 0,1,\ldots,k .$$ <br>
Postupnosť reťazcov $ \alpha_0 \Rightarrow \alpha_1 \Rightarrow \dots \Rightarrow \alpha_k $ sa nazýva **odvodenie** (alebo **derivácia**) reťazca $ \alpha_k $ z reťazca $ \alpha_0 $ <br>
Vyjadrovať ju budeme vo forme mocniny relácie $ \Rightarrow $ v tvare $ \alpha_0 \Rightarrow^k \alpha_k $ <br>
Číslo $k$ sa nazýva **dĺžka odvodenia**. <br>

---

**Tranzitívnym uzáverom** relácie krok odvodenia nazývame reláciu $ \Rightarrow^+$, definovanú na množine $ (N \cup T)^* $ nasledovne:
$$ \alpha \Rightarrow^+ \beta $$
práve vtedy, keď existuje $ n \geq 1$ také, že $ \alpha \Rightarrow^n \beta $.

<br>

**Reflexívnym a tranzitívnym uzáverom** relácie krok odvodenia nazývame reláciu $ \Rightarrow^*$, definovanú :
$$ \alpha \Rightarrow^* \beta $$
práve vtedy, keď existuje $ n \geq 0$ také, že $ \alpha \Rightarrow^n \beta $. 

<br>

Pričom v obidvoch prípadoch platí $ \alpha, \beta \in (N \cup T)^* $.

---

Každý reťazec $ \alpha \in T^* $ , ktorý je možné odvodiť zo začiatočného symbolu gramatiky $ G $ sa nazýva **slovná forma** (alebo slovo jazyka); formálne, $\alpha $ je slovná forma práve vtedy, keď $ S \Rightarrow^* \alpha $ a $ \alpha \in T^* $.

<br>

Každý reťazec $ \alpha \in (N \cup T)^* $ , ktorý je možné odvodiť zo začiatočného symbolu gramatiky $ G $ sa nazýva **vetná forma**; formálne, $\alpha$ je vetná forma práve vtedy, keď $ S \Rightarrow^* \alpha $ .

> Poznámka: 
> Vetná forma môže obsahovať terminály aj neterminály (napr. $A B \Rightarrow a b B$ ), zatiaľ čo slovná forma obsahuje výlučne terminálne symboly a predstavuje "dokončené" odvodenie v gramatike (napr. $ B \Rightarrow a a b b$ ).

---

Nech G=(N,T,P,S) je bezkontextová gramatika.<br>
Ohodnotený strom sa nazýva **strom odvodenia (derivačný strom)** slova $w$ v gramatike $G$, ak spĺňa nasledujúce podmienky: <br>
* Každý vrchol stromu je ohodnotený symbolom z množiny $ N\cup T_\epsilon$ .
* Koreň stromu je ohodnotený začiatočným symbolom $S$.
* Ak má nejaký vrchol stromu potomkov, potom je ohodnotený symbolom z množiny $N$.
* Ak $X_1,X_2,\dots,X_k$​ sú ohodnotenia priamych potomkov vrcholu $A$, potom v $P$ musí existovať pravidlo $ A → X_1,X_2,\dots,X_k $
* Listy stromu sú ohodnotené symbolmi z množiny $T_\epsilon$.
* Slovo $w \in T^*$ sa dá získať zreťazením ohodnotení listov stromu zľava doprava.

<br>

<br>

**Abstraktný syntaktický strom** (AST) predstavuje štruktúrovanú reprezentáciu syntaxe programovacieho jazyka alebo výrazu, ktorá zachytáva podstatnú sémantickú štruktúru bez zachovania všetkých syntaktických detailov. Abstraktný syntaktický strom spĺňa nasledujúce podmienky:
* Každý vrchol stromu reprezentuje operáciu, príkaz alebo konštrukciu jazyka.
* Koreň stromu reprezentuje hlavnú operáciu alebo konštrukciu programu.
* Vnútorné uzly predstavujú operácie alebo štruktúry (napríklad +, *, if, while).
* Listy stromu sú tvorené operandmi - terminálnymi symbolmi (napríklad číselné literály, identifikátory premenných).
* Strom zachytáva hierarchiu operácií a prioritné vzťahy medzi operáciami.
* AST neobsahuje neterminálne symboly ani pomocné syntaktické prvky (zátvorky, bodkočiarky, atď.).
* AST je jazykovo špecifický a závisí od sémantiky cieľového jazyka.




> Príklad:
> Uvažujme o gramatike G={E,T,F} kde množinu pravidiel P tvoria nasledujúce pravidlá: <br>
> 
   > E → E + T | T <br>
   > T → T ∗ F | F <br>
   > F → (E) | id <br>
> 
>
> Vytvorte na danú gramatiku **strom odvodenia** a taktiež **abstraktný syntaktický strom**. <br>
>
>
>
> Na zostrojenie stromov je potrebné urobiť odvodenie z gramatiky. <br>
>
> Odvodenie: <br>
> $ E \Rightarrow E + T $ <br>
> $ E + T \Rightarrow T + T $ <br>
> $ T + T \Rightarrow T * F + T $ <br>
> $ T * F + T \Rightarrow F * F + T $ <br>
> $ F * F + T \Rightarrow id * F + T $ <br>
> $ id * F + T \Rightarrow id * F + F $ <br>
> $ id * F + F \Rightarrow id * id + id $ <br>
>
> Existuje viacero odvodení čo sme mohli vytvoriť avšak my budeme pracovať s odvodením **id * id + id**. <br>
> Podľa nasledujúceho postupu odvodenia vieme zostrojiť derivačný strom. <br>
>
> ![Stromy odvodenia](resources/cv5_new/derivacny_strom.png)
>
> * Koreň stromu odvodenia je tvorený začiatočným symbolom gramatiky.
> * Listy sú tvorené terminálnymi symbolmi.
> * Aplikácia nejakého pravidla na nejaký neterminál sa prejaví tým, že symboly na pravej strane použitého pravidla tvoria priamych potomkov prepísaného neterminálu (ľavej strany pravidla).
>
> <br>
>
> Abstraktný syntaktický strom je zjednodušená verzia derivačného stromu, ktorá odstraňuje neterminálne symboly a zachováva iba štruktúru výrazu. <br>
>
> ![Abstraktný syntaktický strom ](resources/cv5_new/ast_strom.png)
>
> * Koreň stromu reprezentuje hlavnú operáciu alebo konštrukciu programu.
> * Listy sú tvorené operandmi (napr. 1, 2 alebo premenné).
> * Vnútorné uzly reprezentujú operácie alebo štruktúry (napr. +, *, if, while).
> * Je jazykovo špecifický a závisí na sémantike cieľového jazyka (napr. priorita operátorov už nie je explicitne vyjadrená).
>



## Krok {ciel_bnf_ebnf}
**Backusova-Naurova forma (BNF)** je spôsob zápisu používaný na vyjadrenie bezkontextových gramatík. Je to formálny spôsob opisu syntaxu programovacích jazykov a iných formálnych jazykov.
 
<br>

BNF je sadou odvodzovacích pravidiel tvaru
$$ \langle \text{symbol} \rangle ::= \langle \text{výraz so symbolmi} \rangle $$

V BNF:
* Neterminálne symboly sú uzavreté v lomených zátvorkách, napr. **\<expr>**.
* Terminálne symboly sú zapísané ako samotné znaky alebo reťazce, napr. + alebo 123.
* Symbol **::=** (alebo **→**) označuje definíciu (prepisovacie pravidlo).
* Symbol **|** označuje alternatívu (možnosť výberu).

> Príklad:
> Zapíšme gramatiku pre zápis ľubovolného celého čísla v BNF:
>
  > \<celé_číslo> ::= \<znak> \<číslica> \<číslo> <br>
  > \<číslo> ::= \<číslica> \<číslo> | ε <br>
  > \<znak>>   ::= "-" | ε <br>
  > \<číslica>  ::= "0" | "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" <br>
>

> Poznámka:
> BNF vytvoril John Backus na opis syntaxu programovacieho jazyka ALGOL a zdokonalil ho Peter Naur.
> ![John Backus a Peter Naur](resources/cv5_new/John_Backus_Peter_Naur.jpg)

**Rozvinutá Backusova-Naurova forma (EBNF)** je rozšírením BNF, ktoré pridáva ďalšie konštrukcie pre jednoduchšie a kompaktnejšie vyjadrovanie gramatík.

<br>

Hlavné rozšírenia EBNF oproti BNF zahŕňajú:
* Voliteľnosť: [...] označuje voliteľnú časť.
* Opakovanie: {...} označuje nula alebo viac opakovaní.
* Terminálne symboly sú často uzavreté v úvodzovkách, napr. "+".

> Príklad:
> Prepíšme predchádzajúcu gramatiku do EBNF:
>
  > celé_číslo → znak, číslica, { číslica } ; <br>
  > znak   → [ - ] <br>
  > číslica  → "0" | "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" ; <br>
>
> Všimnite si, ako EBNF umožňuje kompaktnejší zápis.

> Poznámka:
> EBNF je široko používaná pri definícii syntaxe programovacích jazykov a je štandardizovaná v [ISO/IEC 14977](https://www.iso.org/obp/ui/#iso:std:iso-iec:14977:ed-1:v1:en). Existujú rôzne varianty EBNF s miernymi odchýlkami v notácii, ale základné princípy zostávajú rovnaké.


**Postup ako prepísať EBNF zápis do BNF podoby:** <br>

**Opakovanie** <br>
Máme EBNF: <br> 
  > A → B { C }  <br>

Na prevedenie do BNF je pre opakovanie potrebné vytvoriť nový rekurzívny neterminál s prázdnym koncom ε. <br>
BNF bude:  <br>
  > \<A> → \<B> \<A_tail> <br>
  > \<A_tail> → \<C> \<A_tail> | ε <br>

<br>

**Voliteľnosť** <br>
Máme EBNF: <br>
  > A → B [ C ] <br>

Na prevod do BNF máme možnosti: <br>
1. pre voliteľnosť je potrebné vytvoriť nový neterminál s prázdnym koncom ε. <br>
BNF bude: <br>
  > \<A> → \<B> \<A_tail> <br>
  > \<A_tail> → \<C> | ε <br>

 <br>

2. alebo použiť alternatívu.  <br>
BNF bude: <br> 
  > \<A> → \<B> \<C> | \<B> <br>


> Príklad: 
> Prepíšte EBNF do BNF: <br>
> EBNF: <br>
  > A → B { "+", B, [ C ] } <br>
> 
> Odstránime celé opakovanie a zavedieme nový rekurzívny neterminál \<A_tail>. <br>
  > \<A> → \<B> \<A_tail> <br>
  > \<A_tail> → "+" \<B> [ C ] <A_tail> | ε <br>
> 
> Následne odstráníme volitelnosť C a zavedieme nový neterminál \<C_opt>. <br>
>
> Výsledné BNF: <br>
  > \<A> → \<B> \<A_tail> <br>
  > \<A_tail> → "+" \<B> \<C_opt> \<A_tail> | ε <br>
  > \<C_opt> → \<C> | ε <br>



## Krok {ciel_vytvaranie_gramatik}
Teraz si ukážeme, ako vytvoriť formálne gramatiky na základe týchto prístupov: množinovej špecifikácie jazyka a fragmentu jazyka.

**Vytvorenie gramatiky na základe množinovej špecifikácie jazyka** <br>
Ak máme jazyk definovaný množinovou špecifikáciou, môžeme navrhnúť gramatiku, ktorá generuje práve tento jazyk.

> Príklad:
> Navrhnite gramatiku pre jazyka { a, b ∈ A | a * b *}. <br>
>
> **Krok 1: Interpretujme, čo tento výraz znamená.** <br>
> Notácia { a, b ∈ A | a * b *} opisuje množinu všetkých reťazcov, ktoré sa skladajú z ľubovoľného počtu symbolov "a" (vrátane nula) nasledovaných ľubovoľným počtom symbolov "b" (vrátane nula). <br>
>
> Formálna gramatika G = (N, T, P, S) pre tento jazyk bude: <br>
> N = {S, A, B} - množina neterminálnych symbolov <br>
> T = {a, b} - množina terminálnych symbolov <br>
> P - množina prepisovacích pravidiel: <br>
> - S → A (začiatok) <br>
> - S → Sb A → aA | B (generovanie "a" alebo prechod na generovanie "b") <br>
> - B → bB | ε (generovanie "b" alebo ukončenie) <br>
>
> **Krok 2: Vytvoríme prepisovacie pravidlá** <br>
> V BNF zápise to bude vyzerať takto: <br>
  > \<S> → \<A> <br>
  > \<A> → a \<A> | \<B> <br>
  > \<B> → b \<B> | ε <br>
>
> V EBNF zápise to môžeme zapísať kompaktnejšie: <br>
  > S → A <br>
  > A → {a} B <br>
  > B → {b} <br>

**Vytvorenie gramatiky na základe fragmentu jazyka** <br>
Niekedy nemáme presnú množinovú špecifikáciu jazyka, ale máme k dispozícii niekoľko príkladov (fragmentov) reťazcov, ktoré do jazyka patria. Na základe týchto príkladov sa snažíme odvodiť gramatiku.

> Príklad:
> Máme nasledujúce fragmenty jednoduchého jazyka na popis farieb: <br>
> "červená farba" <br>
> "modrá farba" <br>
> "zelená farba" <br>
> "svetločervená farba" <br>
> "tmavomodrá farba" <br>
> Na základe týchto fragmentov navrhnite gramatiku, ktorá bude generovať podobné výrazy. <br>
>
> **Krok 1: Identifikujeme vzory** <br>
> Pozrime sa na štruktúru každého fragmentu: <br>
> Všetky končia slovom "farba". <br>
> Pred slovom "farba" je vždy nejaká špecifikácia farby (červená, modrá, atď.). <br>
> Niektoré špecifikácie farby majú predponu (svetlo-, tmavo-). <br>
>
> **Krok 2: Pomenujeme vzory pomocou neterminálov** <br>
> \<farebny_vyraz> - celý výraz <br>
> \<odtien> - predpona ako "svetlo-" alebo "tmavo-" (môže byť prázdna) <br>
> \<farba> - základná farba (červená, modrá, zelená) <br>
>
> **Krok 3: Vytvoríme prepisovacie pravidlá** <br>
> V BNF zápise: <br>
  > \<farebny_vyraz> → \<odtien_farby> "farba" <br>
  > \<odtien_farby> → \<odtien> \<farba> <br>
  > \<odtien> → "svetlo" | "tmavo" | "" <br>
  > \<farba> → "červená" | "modrá" | "zelená" <br>
>
> V EBNF zápise : <br>
  > farebny_vyraz → odtien_farby "farba" <br>
  > odtien_farby → [odtien] farba <br>
  > odtien → "svetlo" | "tmavo" <br>
  > farba → "červená" | "modrá" | "zelená" <br>




<!---

toto pojde do 6 cvičenia


**Špecifikácia priority (násobenie > sčítanie)** <br>
Máme gramatiku v BNF: 

  > \<A>   → \<M> { ("+" | "-") \<M> }; <br>
  > \<M>   → \<T> { ("*" | "/") \<T> }; <br>
  > \<T> → číslo | "(" \<A> ")"; <br>

 

Ukážeme si špecifikáciu priority na príklade 1 + 2 * 3.

1. Priorita operátorov je nasledujúca:
* \+ (sčítanie) má nižšiu prioritu ako * (násobenie). Zároveň zátvorky majú najvyššiu prioritu.
To sa dosiahne tým, že pravidlo pre \<A> (sčítanie) odkazuje na \<M> (násobenie), a pravidlo pre \<M> odkazuje na \<T> (základné prvky).

2. Štruktúra gramatiky:
Každá úroveň pravidla zodpovedá jednej úrovni priority:
* \<A\>: Najnižšia priorita (sčítanie/odčítanie).
* \<M\>: Stredná priorita (násobenie/delenie).
* \<T\>: Najvyššia priorita (základné prvky: čísla, zátvorky).

<br>


![Stromy odvodenia pri rôznej priorite operátorov](resources/cv5_new/priorita.png)


<br>

**Špecifikácia asociatívnosti** <br>
**Asociatívnosť operátorov** určuje, v akom poradí sa budú vyhodnocovať operácie s rovnakou prioritou. Pri implementácii syntaktického analyzátora pomocou rekurzívnych funkcií sa asociatívnosť vyjadruje tvarom pravidiel gramatiky.

Pre zabezpečenie správnej **priority operátorov** sa pre každú prioritnú úroveň vytvorí jeden neterminál. Pravidlá sa pre jednotlivé úrovne zreťazia tak, že smerom dovnútra (vnáranie k operandom) sa zvyšuje priorita.


**Asociatívnosť operátorov** je zabezpečená tvarom pravidla nasledovne:

Asociatívnosť | Pravidlo
---|---
ľavá | `E → T { op T }`
pravá | `E → T [ op E ]`
neasociatívnosť | `E → T [ op T ]`

<br>

Asociativita je dôležitá, keď máme výraz s viacerými rovnakými operátormi za sebou. Napríklad v aritmetických výrazoch:

- Ľavá asociatívnosť: 5−3−2 sa vyhodnotí ako (5−3)−2=0.
- Pravá asociatívnosť: 2^3^2 sa vyhodnotí ako 2^(3^2)=512.
- Neasociatívne operátory: Napríklad operátor porovnania je neasociatívny.

<br>


![Stromy odvodenia pri rôznej asociatívnosti operátora](resources/cv5_new/asociativnost.png)



--->



## Krok {ciel_ulohy}

> Úloha:
> Vytvorte gramatiku v tvare EBNF pre jazyk aritmetických výrazov, s podporou operácií pre sčítanie, odčítanie, násobenie a delenie, pri zachovaní štandardných priorít a asociatívností. Jazyk výrazov obsahuje tiež zátvorky, výrazy obsahujú celé čísla a identifikátory. 

> Vyučujúci: 
>
> `E ->  T  { ( + | - ) T }` \
> `T ->  F  { ( * | / ) F }`	\
> `F ->  cislo | id | ( E )`

> Úloha:
> Prevedťe gramatiku z predošlého príkladu do BNF.

> Vyučujúci: 
>
> `<E> → <T> <E2>` \
> `<E2> → "+" <T> <E2> | "-" <T> <E2> | ε` \
> `<T> → <F> <T2>` \
> `<T2> → "*" <F> <T2> | "/" <F> <T2> | ε` \
> `<F> → <number> | <identifier> | "(" <E> ")"`

> Úloha:
> Pre gramatiku.
>
> `S → A B` \
> `A → a A | ε` \
> `B → b B | ε`
>
> 1. Napíšte všetky kroky odvodenia reťazca "aabb".
> 2. Nakreslite strom odvodenia reťazca "aabb".
> 3. Určte, či reťazec "baba" patrí do jazyka generovaného touto gramatikou.

> Vyučujúci: 
>
> 1. S ⇒ A B ⇒ a A B ⇒ a a A B ⇒ a a B ⇒ a a b B ⇒ a a b b B ⇒ a a b b
> 2. Zatial nemám obrázok
> 3. Reťazec "baba" nepatrí do jazyka. Gramatika nedovoľuje striedanie symbolov.

> Úloha:
> Vytvorte gramatiku pre jazyk všetkých reťazcov nad abecedou {a, b}, ktoré obsahujú párny počet symbolov 'a'.


> Úloha:
> Vytvorte gramatiku pre jazyk všetkých reťazcov nad abecedou {a, b, c}, kde každý symbol 'c' je obklopený symbolmi 'a' 



## Dotazník na ohodnotenie učiva
Vážení študenti, <br>
poprosil by som Vás o vyplnenie tohto [dotazníka](https://forms.gle/TMzd4ZexSNC3rLtq6) .   <br>

Tento dotazník slúži na ohodnotenie vašich skúseností s pripravenými materiálmi z piateho cvičenia. Na vylepšovaní učiva sa aktívne pracuje a Vaše odpovede nám pomôžu zlepšiť kvalitu výučby. <br>

Ďakujem<br>