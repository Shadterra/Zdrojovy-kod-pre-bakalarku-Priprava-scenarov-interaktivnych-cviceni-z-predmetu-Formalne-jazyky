#include <stdio.h>
#include <stdlib.h>

/* Tabulka konstant */
#define TCMAX 50
double TC[TCMAX];

// .......................................
// FRAGMENT POLYMORFNÉHO KALKULÁTORA

// Definícia syntaktického stromu výrazu

// Značky vrcholov stromu
enum NodeTags {
    // druhy konštánt
    INTCONST, FLOATCONST,
    // operátory polymorfných operácií
    PRINT_OP, ADD_OP, SUB_OP,
    // operátory monomorfných operácií
    PRINT_INT_OP, PRINT_FLOAT_OP,
    ADD_INT_OP, ADD_FLOAT_OP,
    SUB_INT_OP
};

// Typová definícia uzla stromu
typedef union ExpTreeNode {
        struct
        {
            int constTag;
            int constVal;
        } operand;
        struct
        {
            int binOp;
            ExpTreeNode* leftTree;
            ExpTreeNode* rightTree;
        } binaryop;
        struct
        {
            int unOp;
            ExpTreeNode* subTree;
        } unaryop;
} ExpTree;

// Konštruktory stromu

// Konštrukcia konštanty (listu stromu)
ExpTree* mkValNode(NodeTags constTag, int constVal)
{
    ExpTreeNode* node =
      (ExpTreeNode*) malloc(sizeof(ExpTreeNode));
    node->operand.constTag = constTag;
    node->operand.constVal = constVal;
    return node;
}

// Konštrukcia pre aplikáciu unárnej operácie
ExpTree* mkUnNode(NodeTags unOp, ExpTree* subTree)
{
    ExpTreeNode* node =
      (ExpTreeNode*) malloc(sizeof(ExpTreeNode));
    node->unaryop.unOp = unOp;
    node->unaryop.subTree = subTree;
    return node;
}

// Konštrukcia pre aplikáciu binárnej operácie
ExpTree* mkBinNode(NodeTags binOp,
            ExpTree* leftTree, ExpTree* rightTree)
{
    ExpTreeNode* node =
      (ExpTreeNode*) malloc(sizeof(ExpTreeNode));
    node->binaryop.binOp = binOp;
    node->binaryop.leftTree = leftTree;
    node->binaryop.rightTree = rightTree;
    return node;
}

// ..................................................

const char *OP_NAMES[] = {"", "", "print", "+", "-",
    "print_int", "print_float", "+_int", "+_float", "-_int"
};

int node_id = 0;
int draw_node(ExpTree *node)
{
    int l, r;
    int id = node_id++;
    switch (node->operand.constTag) {
    case INTCONST:
        printf("n%d[label=\"%d\"];\n", id, node->operand.constVal);
        break;
    case FLOATCONST:
        printf("n%d[label=\"%f\"];\n", id, TC[node->operand.constVal]);
        break;
    case PRINT_OP:
    case PRINT_INT_OP:
    case PRINT_FLOAT_OP:
        printf("n%d[label=\"%s\"];\n", id, OP_NAMES[node->unaryop.unOp]);
        l = draw_node(node->unaryop.subTree);
        printf("n%d -> n%d;\n", id, l);
        break;
    case ADD_OP:
    case SUB_OP:
    case ADD_INT_OP:
    case ADD_FLOAT_OP:
    case SUB_INT_OP:
        printf("n%d[label=\"%s\"];\n", id, OP_NAMES[node->binaryop.binOp]);
        l = draw_node(node->binaryop.leftTree);
        printf("n%d -> n%d;\n", id, l);
        r = draw_node(node->binaryop.rightTree);
        printf("n%d -> n%d;\n", id, r);
        break;
    }
    return id;
}

void draw_tree(ExpTree *node)
{
    printf("digraph ast {\n");
    draw_node(node);
    printf("}\n");
}

int main()
{
    /* Syntakticky strom pre vyraz "2 - (1.2 + 2.3) + 3"
     * (dany strom nie je spravny -- miesaju sa v nom polymorfne a
     * monomorfne operacie) */
    ExpTree *root =
        mkUnNode(PRINT_OP,
            mkBinNode(ADD_OP,
                mkBinNode(SUB_OP,
                    mkValNode(INTCONST, 2),
                    mkBinNode(ADD_FLOAT_OP,
                        mkValNode(FLOATCONST, 0),
                        mkValNode(FLOATCONST, 1)
                    )
                ),
                mkValNode(INTCONST, 3)
            )
        );
    /* Ulozenie konstant */
    TC[0] = 1.2;
    TC[1] = 2.3;
    draw_tree(root);
    return 0;
}
