import sys

instructions = [ 
	"NOP", "BZE", "JMP", "JSR", "RTS", "EXIT", "INPC", "INP",
	"INPR", "OUTC", "OUT", "OUTR", "POP", "POPR", "PUSH", "PUSHR",
	"LDA", "LDAM", "LDAI", "LDAX", "LDR", "LDRI", "STA", "STAI",
	"STRI", "LDX", "STX", "LDS", "STS", "OR", "AND", "NOT", "EQ",
	"NE", "LT", "LE", "GT", "GE", "EQR", "NER", "LTR", "LER", "GTR",
	"GER", "ADD", "ADDM", "SUB", "SUBM", "MUL", "DIV", "NEG", "ADDR",
	"SUBR", "MULR", "DIVR", "NEGR",
]

hasAttr = [
	"BZE", "JMP", "JSR", "LDA", "LDAM", "LDAI", "LDAX", "LDR", "LDRI",
	"STA", "STAI", "STRI", "LDX", "STX", "LDS", "STS", "OR", "AND", "EQ",
	"NE", "LT", "LE", "GT", "GE", "EQR", "NER", "LTR", "LER", "GTR",
	"GER", "ADD", "ADDM", "SUB", "SUBM", "MUL", "DIV", "ADDR", "SUBR", "MULR",
	"DIVR",
]


if len(sys.argv) < 1:
	f = open("program.bin")
else:
	f = open(sys.argv[1])

# First two bytes are always JMP in write_begin()
f.read(2)
# 2 byte convertion to number
byte = f.read(2)
value = 256*ord(byte[1]) + ord(byte[0])
print("[00] JMP 0{}".format(value))

# Why is this here? Because it is how it is
f.read(2)
print("[02] STACK_START")

memAddr = 3
byte = f.read(1)
#Instructions only take 1 byte, so 1 byte offset must be skipped
f.read(1)
while byte:
	index = ord(byte);
	if index > len(instructions):
		print(index)
	else:
		instruction = instructions[index]
		# print(f"[0{memAddr}] {instruction} ( {hex(index)} )", end='')
		print("[0{}] {}".format(memAddr, instruction))

		if instruction in hasAttr:
			attr = f.read(2)
			memAddr += 2
			value = 256*ord(attr[1]) + ord(attr[0])
			print(" 0{}".format(value))
		else:
			memAddr += 1
			print()

	byte = f.read(1)
	f.read(1)
