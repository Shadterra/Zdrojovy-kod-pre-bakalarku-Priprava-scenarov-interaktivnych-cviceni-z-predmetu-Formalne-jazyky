---
Nadpis: Test B. Odovzdanie zadaní.
---

## Ciele

  1. {id_ll} Realizácia Testu B.
  2. {id_odovzdanie} Odovzdanie zadania č. 2.

## Krok {id_ll}

Realizácia Testu B (druhého zápočtového testu). Pripravte si písacie pomôcky. Test vypracujte podľa pokynov vyučujúceho v stanovenom čase.



## Krok {id_odovzdanie}

Odovzdajte do git repozitára Vaše zadanie č. 2 a riaďte sa ďalšími pokynmi pedagóga pri obhajobe a prezentácii Vášho zadania.
