---
Nadpis: Regulárne výrazy, detekcia určitých vstupných postupností znakov.
---

## Ciele

  1. {ciel_organizacia} Oboznámiť sa s organizáciou cvičení predmetu Formálne jazyky.
  2. {ciel_regexp} Zopakovať a prehĺbiť poznatky o regulárnych výrazoch.
  3. {ciel_regexp_cvic} Prakticky precvičiť zostavenie vybraných regulárnych výrazov.



## Úvod

Na tomto cvičení sa oboznámite s organizáciou cvičení a podmienkami udelenia priebežného hodnotenia (zápočtu). Následne sa oboznámite regulárnymi výrazmi a s konečno-stavovými automatmi akceptujúcimi vstup podľa zadaného regulárneho výrazu. Tieto zručnosti si prakticky overíte na cvičení.


## Krok {ciel_organizacia}

Oboznámte sa s [organizáciou cvičení predmetu Formálne jazyky a prekladače](resources/FJ_cvicenia.pdf) a podmienkami udelenia zápočtu.

> Vyučujúci:
> Študijné materiály na prednášky sú v systéme Moodle - <https://moodle.fei.tuke.sk>, predmet Formálne jazyky a prekladače. Prihlasovací kľúč na predmet je „mudricitajuknihy”.

## Krok {ciel_regexp}

Zopakujte si [teóriu regulárnych výrazov](resources/regularne_vyrazy.pdf).

> Poznámka:
> Regulárne výrazy sa môžu zapisovať rôznymi spôsobmi. V tabuľke je v druhom stĺpci uvedený zjednodušený zápis, ktorý sa používa na tomto predmete. V treťom stĺpci je uvedený zápis, s ktorým sa najčastejšie môžete stretnúť v existujúcich implementáciách regulárnych výrazov. Väčšina zápisov regulárnych výrazov tiež ponúka viaceré skrátené zápisy pre celé skupiny znakov.
>
>  Regulárny výraz | Zjednodušený zápis (používaný na tomto predmete) | Zápis bežný v implementáciách
> ---|---|---
> **zoskupenie (postupnosť)** | `(xy)` | `(xy)`
> **alternatíva (x alebo y)** | `x\|y` | `x\|y`
> **tranzitívny uzáver (0 alebo viac krát)** | `{x}` | `(x)*`
> **opakovanie (1 alebo viac krát)** | `x{x}` | `(x)+`
> **voliteľnosť (0 alebo 1 krát)** | `[x]` | `(x)?`

> Poznámka:
> Postupnosť má vyššiu prioritu ako alternatíva, preto pozor napr. na prípady podobné tomuto:
>  
>  
> ```
> a | b {c} = a | (b {c})
> ```
>                          
> Najvyššiu prioritu majú zátvorky. Ich používaním môžete zabrániť nejednoznačnosti:
>  
>  
> ```
> (a | b) {c}
> ```
>

> Príklad:
> Regulárny výraz pre binárne numerály:
>
> ```
> 0 | 1 {0 | 1}
> ```
>
> Aký tvar môžu nadobúdať binárne numerály podľa uvedeného regulárneho výrazu?

> Úloha:
> Skonštruujte ďalšie výrazy pre binárne numerály.

Regulárne výrazy je možné zobraziť aj graficky pomocou **prechodových diagramov**. Princíp zostrojenia takéhoto diagramu je znázornený na obrázku.

![Princíp zostrojenia prechodového diagramu pre regulárny výraz](resources/prechodovy-diagram.png)


## Krok {ciel_regexp_cvic}

> Úloha:
> Skonštruujte regulárny výraz pre overenie zápisu identifikátora.
>
> Zápis identifikátora má nasledujúce vlastnosti:
> * identifikátor môže (a nemusí) začínať znakom $,
> * následne prvý znak môže byť len malé alebo veľké písmeno latinskej abecedy,
> * ďalšie znaky (ak sa v pomenovaní vyskytujú) môžu tvoriť ľubovoľnú kombináciu malých alebo veľkých písmen latinskej abecedy alebo ľubovoľné číslice.
>

> Vyučujúci:
> `[$](a-z|A-Z){a-z|A-Z|0-9}`

> Úloha:
> Skonštruujte regulárny výraz pre overenie zápisu reálneho čísla.
>
> Zápis čísla má nasledujúce vlastnosti:
> * číslo môže byť kladné alebo záporné,
> * číslo môže a nemusí obsahovať desatinnú časť,
> * číslo musí mať vyjadrenú celú časť na aspoň jednu platnú číslicu,
> * ak číslo obsahuje aj desatinnú časť, aj tá musí byť vyjadrená na aspoň jednu platnú číslicu,
> * oddeľovač celej a desatinnej časti môže byť znak desatinnej čiarky ',' alebo desatinnej bodky '.'
>
> Ako zabezpečíte, aby numerál neobsahoval nevýznamné nuly zľava?
>

> Vyučujúci:
> `[+|-] (0 | (1-9) {0-9}) [(.|;) ((1-9) | {0-9}(1-9))]`

> Úloha:
> Skonštruujte regulárny výraz pre overenie zápisu rodného čísla (podľa slovenskej legislatívy).
>
> V zápise rodného čísla:
> * sa môže vyskytovať oddeľovač '/', prípadne zápis neobsahuje žiaden oddeľovač,
> * skupina číslic za oddeľovačom môže mať dĺžku 3 alebo 4 znaky,
> * sa pri mesiacoch vyskytujú dve možné postupnosti: 01-12, 51-62.
>

> Vyučujúci:
> `(0-9)(0-9)(0|1|5|6)(0-9)(0-3)(0-9)[/](0-9)(0-9)(0-9)[0-9]`


> Úloha:
> Skonštruujte regulárny výraz pre všetky reťazce pozostávajúce zo znakov *a* a *b*, ktorý obsahuje podreťazec *abba*.
>

> Vyučujúci:
> `{a|b}abba{a|b}`


> Úloha:
> Skonštruujte regulárny výraz pre všetky reťazce pozostávajúce zo znakov *x* a *y*, v ktorých je každý výskyt znaku *y* bezprostredne nasledovaný postupnosťou troch znakov *x*.
>

> Vyučujúci:
> `{x|(yxxx)}`

> Úloha:
> Skonštruujte regulárny výraz pre všetky reťazce pozostávajúce zo znakov *p* a *q*, ktoré obsahujú nepárny počet znakov *q*.
>

> Vyučujúci:
> `{p} q {(q {p} q) | p}`


> Úloha:
> Zostrojte prechodové diagramy pre regulárne výrazy z predchádzajúcich úloh.




## Doplňujúce zdroje
Vizualizačné nástroje znázorňujúce proces rozpoznávania textu na základe regulárnych výrazov využívajúce znázornenie na ich prechodových diagramoch.
  * [debuggex](http://www.debuggex.com/)
  * [regex101](https://regex101.com/)

> Poznámka:
> Obidva nástroje používajú alternatívny zápis regulárnych výrazov, s ktorým ste sa oboznámili na tomto cvičení. Tento zápis sa nebude používať na cvičeniach ani na skúške, zíde sa však pri implementácii programov. Pred použitím oboch vizualizačných nástrojov odporúčame dôkladne sa oboznámiť so vstupným tvarom regulárnych výrazov, ktoré obidva nástroje používajú.
