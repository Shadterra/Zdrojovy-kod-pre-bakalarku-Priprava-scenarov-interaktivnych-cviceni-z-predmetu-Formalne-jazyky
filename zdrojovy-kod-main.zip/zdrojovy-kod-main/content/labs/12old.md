---
Nadpis: Odovzdanie zadania.
---