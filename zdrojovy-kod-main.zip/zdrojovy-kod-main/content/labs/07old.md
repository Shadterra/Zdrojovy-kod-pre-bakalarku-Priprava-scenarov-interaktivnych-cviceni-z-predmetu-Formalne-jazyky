---
Nadpis: Syntaktická analýza.
---

## Ciele

1. {ciel_syntakticka_analyza} Vlastnosti bezkontextových gramatík.

## Krok {ciel_syntakticka_analyza}

V tomto kroku sa zameriame na niektoré vlastnosti bezkontextových gramatík.

> Úloha:
> Daná je nasledujúca gramatika:
>
> $$S \rightarrow aS~|~Sb.$$
>
> Vysvetlite, aký jazyk generuje uvedená gramatika.
>

> Vyučujúci:
> Prázdny, pretože z neterminálu nevygenerujeme terminálne slovo. 

> Úloha:
> Na nasledujúcom obrázku je derivačný strom popisujúci odvodenie slova $w = abaaacac$ podľa určitej bezkontextovej gramatiky $G$.
>
> ![Derivačný strom](resources/cv7/derivstrom.png)
>
> a) Vypíšte pravidlá, ktorých existenciu môžeme vyvodiť z uvedeného derivačného stromu.\
> b) Napíšte ľavé odvodenie slova $w$ podľa gramatiky $G$.\
> c) Napíšte pravé odvodenie slova $w$ podľa gramatiky $G$.

> Vyučujúci:
> 
> a)
>$$\begin{array}{l}
> S \rightarrow AaB~|~\varepsilon	\\
> A \rightarrow AA ~|~ aSb ~|~ \varepsilon ~|~ SB	\\
> B \rightarrow SA ~|~ ac\\
> \end{array}$$
>
> b) S ⇒ AaB ⇒ AAaB ⇒ aSbAaB ⇒ abAaB ⇒ abaB ⇒ abaSA ⇒ abaAaBA ⇒ abaaBA ⇒ abaaacA ⇒ abaaacSB ⇒ abaaacB ⇒ abaaacac
>
> c) S ⇒ AaB ⇒ AaSA ⇒ AaSSB ⇒ AaSSac ⇒ AaSac ⇒ AaAaBac ⇒ AaAaacac ⇒ Aaaacac ⇒ AAaaacac ⇒ Aaaacac ⇒ aSbaaacac ⇒
abaaacac
>

> Úloha:
> Navrhnite gramatiku generujúcu jazyk palindromov $L=\left\{ w \in \left\{a, b \right\}^{*}~|~w = w^{R}\right\}$.
>

> Vyučujúci:
> 
> $S \rightarrow \varepsilon ~|~ a ~|~ b ~|~ aSa ~|~ bSb.$

> Úloha:
> (*Opakovanie*) Zistite, či uvedená gramatika je LL(1) gramatikou.
>
> $$\begin{array}{l}
> A \rightarrow BCb~|~aB	\\
> B \rightarrow bB ~|~ \varepsilon	\\
> C \rightarrow cA ~|~ \varepsilon \\
> \end{array}$$
>

> Vyučujúci:
> 
> Nie je to LL(1) gramatika.
