---
Nadpis: Syntaktický analyzátor jazyka LL(1)
---

## Ciele

  1. {ciel_teoriafirstfollow} Oboznámiť sa s teoretickými základmi syntaktickej analýzy LL(1) a naučiť sa vytvárať množiny First, Follow a Predict.
  2. {ciel_rozkladova_tabulka} Naučiť sa zostrojiť rozkladovú tabuľku pre LL(1) gramatiky.
  3. {ciel_syntakticka_analyza} Pochopiť princíp syntaktickej analýzy zhora nadol a jej implementáciu.


## Úvod



## Krok {ciel_teoriafirstfollow}

**Syntaktická analýza** je proces, ktorého základným cieľom je:

Overenie správnosti - Zistiť, či dané vstupné slovo (v prípade kompilátorov zdrojový kód programu) patrí do jazyka generovaného danou bezkontextovou gramatikou (to znamená overiť, či je zdrojový program syntakticky správny).

Konštrukcia derivačného stromu - Ak vstupné slovo patrí do jazyka, ďalšou úlohou syntaktického analyzátora je určiť jeho derivačný strom (alebo inú reprezentáciu syntaktickej štruktúry).

> Pri tvorbe syntaktického analyzátora je možné postupovať dvoma spôsobmi:
> * **zhora nadol** *(z angl. top-down)*,
> * **zdola nahor** *(z angl. bottom-up)*.

<br>

**Zhora nadol (Top-down)**

Začína sa začiatočným symbolom gramatiky a postupným aplikovaním pravidiel gramatiky sa generujú vetné formy (reťazce terminálnych a neterminálnych symbolov).

Cieľom je dosiahnuť vstupný reťazec (tokeny programu) v poslednom kroku derivácie.

$$S \Rightarrow^* w$$


**Zdola nahor (Bottom-up)**

Začína sa vstupným reťazcom (tokenmi) a postupnou redukciou (aplikáciou pravidiel sprava doľava) sa reťazec upravuje, až kým sa nedosiahne začiatočný symbol gramatiky.

$$w \Rightarrow^* S$$


# Syntaktická analýza zhora nadol.


---

**Teoretickým modelom** syntaktického analyzátora modelujúcim syntaktickú analýzu jazyka $L(G)$ metódou zhora-nadol bude (vo všeobecnosti nedeterministický) zásobníkový automat, ktorý možno zostrojiť ku gramatike $G$ a ktorý bude vychádzať z nasledujúcich princípov:

* Automat bude v zásobníku simulovať ľavé odvodenie vstupného slova w. 

* Na začiatku automat vloží do zásobníka začiatočný (neterminálny) symbol S gramatiky G (r.1).

* Ďalej bude automat opakovať nasledujúce akcie dovtedy, kým nevyprázdni zásobník resp. kým sa "nezasekne" (r.2–16):

* **Expanzia** - ak sa na vrchu zásobníka nachádza neterminál $A \in N$, algoritmus nedeterministicky vyberie jedno z pravidiel tvaru $A\to \alpha$ a neterminál $A$ nahradí jeho pravou stranou $\alpha$ (r.3–7); <br>

* **Porovnanie** - ak sa na vrchu zásobníka nachádza terminál $a \in T$, tento sa porovná s aktuálnym symbolom na vstupe; ak sú obidva symboly zhodné, automat odstráni $a$ zo zásobníka a prejde na nasledujúci vstupný symbol; ak sú symboly rôzne, "zasekne sa" a vstup neakceptuje (r.8–15). <br>

* Automat akceptuje vstupné slovo, ak spracuje celý vstup a skončí s prázdnym zásobníkom (r.17–21). 

* Ak automat vždy pri expanzii pošle na výstup pravidlo, podľa ktorého neterminál expandoval (r.6), získa sa postupnosť pravidiel, ktorá v ľavom odvodení generuje vstupné slovo.


***
**Algoritmus 1.** Syntaktická analýza zhora-nadol  
**Vyžaduje:** bezkontextovú gramatiku $G = (N,T,P,S)$, slovo (vetu) $w$  
**Zabezpečí:** zistenie, či $w \in L(G)$ a vytvorenie postupnosti pravidiel, ktorá generuje ľavé odvodenie $w$  
***
1. vlož do zásobníka začiatočný symbol gramatiky $S$;  
2. **pokiaľ** zásobník nie je prázdny **rob**  
3. &emsp; **ak** na vrchu zásobníka je $A \in N$ **potom**  
4. &emsp;&emsp; odstráň $A$ z vrchu zásobníka;  
5. &emsp;&emsp; vlož do zásobníka pravú stranu $\alpha$ niektorého z pravidiel $A \to \alpha$;  
6. &emsp;&emsp; pošli na výstup pravidlo $A \to \alpha$;  
7. &emsp; **koniec ak**  
8. &emsp; **ak** na vrchu zásobníka je $a \in T$ **potom**  
9. &emsp;&emsp; **ak** $a$ je totožné s aktuálnym vstupným symbolom $t$ **potom**  
10. &emsp;&emsp;&emsp; odstráň $a$ z vrchu zásobníka;  
11. &emsp;&emsp;&emsp; prejdi na ďalší vstupný symbol $t$;  
12. &emsp;&emsp; **ináč**  
13. &emsp;&emsp;&emsp; neakceptuj vstupné slovo a skonči;  
14. &emsp;&emsp; **koniec ak**  
15. &emsp; **koniec ak**  
16. **koniec pokiaľ**  
17. **ak** bolo spracované celé vstupné slovo **potom**  
18. &emsp; akceptuj vstupné slovo;  
19. **ináč**  
20. &emsp; neakceptuj vstupné slovo;  
21. **koniec ak**  
***

---

**FIRST**

Nech $G = (N, T, P, S)$ je redukovaná gramatika a $\alpha \in (N ∪ T)^∗$. Potom

$$\text{FIRST}(\alpha) = \{ a \mid \alpha \Rightarrow^* a\beta, \ a \in T \} \cup \{ \varepsilon, \text{ ak } \alpha \Rightarrow^* \varepsilon \}$$

Špecifické prípady:
* $FIRST(a\alpha)$ = $\{a\}$, kde a je terminál
* Ak $A \in N_\epsilon$ (neterminál, z ktorého je možné odvodiť $\epsilon$), potom $\epsilon \in FIRST(A)$
* Ak gramatika obsahuje pravidlo tvaru $ A \to \alpha $, potom $ \text{FIRST}(\alpha) \subseteq \text{FIRST}(A) $
* Ak gramatika obsahuje pravidlo tvaru $ A \to a\alpha $, potom $ a \in \text{FIRST}(A) $, lebo $ A \Rightarrow a\alpha $ tzn. po aplikovaní spomenutého pravidla na neterminál $A$ dostávame reťazec, ktorý sa začína terminálom $a$.

> Príklad:
> Majme bezkontextovú gramatiku G. Transformujte gramatiku G na bezkontextovú gramatiku G', ktorá nebude obsahovať nadbytočné symboly a L(G) = L(G'). <br>
>
> Uvažujme o gramatike G = (N, T, P, S), kde N = {S, A, B, C}, T = {a, b, +, (, ), $ \unicode{x24} $} a množina pravidiel P je tvorená pravidlami: <br>
> S → C $ \unicode{x24} $   <br>
> A → b | ε    <br>
> B → +C | ε   <br>
> C → A(C) | aB    <br>
>
>
> Potom: <br>
> 
> * FIRST(aBA) = {a} <br>
> 
> * FIRST(B) obsahuje: <br>
>  \+ – vďaka pravidlu B → +C  <br>
>  ε – vďaka odvodeniu B ⇒ ε <br>
> 
> *  FIRST(C) obsahuje terminály: <br>
>  a – vďaka pravidlu C → aB <br>
>  b – vďaka odvodeniu C ⇒ A(C) ⇒ b(C) <br>
>  $($ – vďaka odvodeniu C ⇒ A(C) ⇒ (C) <br>


Pre určenie množiny $FIRST(\alpha)$ pre reťazec $\alpha$, ktorý sa skladá zo symbolov terminálnej a neterminálnej abecedy je možné použiť tento algorytmus

***
**Algoritmus 2.** Určenie množiny $FIRST(\alpha)$ pre $\alpha \in (N \cup T)^*$<br>
**Vyžaduje:** Množiny $FIRST(X)$ pre $X \in N \cup T$, reťazec $\alpha \in (N \cup T)^*$<br>
**Zabezpečí:** Množina $FIRST(\alpha)$ pre $\alpha \in (N \cup T)^*$
***
1. **ak** $\alpha = \epsilon$ **potom vráť** $\{\epsilon\}$;
2. **ináč**
3. &emsp; **Nech** $\alpha = X_1X_2 \ldots X_n$;
4. &emsp; $FIRST(\alpha) \leftarrow FIRST(X_1) - \{\epsilon\}$;
5. &emsp; $i \leftarrow 1$;
6. &emsp; **pokiaľ** $\epsilon \in FIRST(X_i)$ **a zároveň** $i < n$ **rob**
7. &emsp;&emsp; $i \leftarrow i + 1$;
8. &emsp;&emsp; $FIRST(\alpha) \leftarrow FIRST(\alpha) \cup (FIRST(X_i) - \{\epsilon\})$;
9. &emsp; **koniec pokiaľ**
10. &emsp; **ak** $i = n$ **a zároveň** $\epsilon \in FIRST(X_n)$ **potom**
11. &emsp;&emsp; $FIRST(\alpha) \leftarrow FIRST(\alpha) \cup \{\epsilon\}$;
12. &emsp; **koniec ak**
13. &emsp; **vráť** $FIRST(\alpha)$;
14. **koniec ak**
***

Tento algoritmus nadväzuje na Algoritmus 2 a slúži na vytvorenie množín $FIRST(X)$ pre všetky terminálne a neterminálne symboly v gramatike.
***
**Algoritmus 3.** Vytvorenie množín $FIRST(X)$ pre $X \in N \cup T$  
**Vyžaduje:** redukovanú bezkontextovú gramatiku $G = (N, T, P, S)$  
**Zabezpečí:** vytvorenie množín $FIRST(X)$ pre $X \in N \cup T$  
***
1. **pre všetky** $A \in N$ **rob**  
2. &emsp; $FIRST(A) \leftarrow \emptyset$;  
3. **koniec pre**  
4. **pre všetky** $a \in T$ **rob**  
5. &emsp; $FIRST(a) \leftarrow \{a\}$;  
6. **koniec pre**  
7. **pre všetky** pravidlá tvaru $A \to a\alpha$ **rob**  
8. &emsp; $FIRST(A) \leftarrow FIRST(A) \cup \{a\}$;  
9. **koniec pre**  
10. **pre všetky** $A \in N_\varepsilon$ **rob**  
11. &emsp; $FIRST(A) \leftarrow FIRST(A) \cup \{\varepsilon\}$;  
12. **koniec pre**  
13. **opakuj**  
14. &emsp; **pre všetky** pravidlá tvaru $A \to B\alpha$ **rob**  
15. &emsp;&emsp; $FIRST(A) \leftarrow FIRST(A) \cup FIRST(B\alpha)$;  
16. &emsp; **koniec pre**  
17. **pokiaľ** nastala zmena u niektorej množiny $FIRST(A), A \in N$  
***

Tieto algorytmi vieme použiť na zostrojenie nasledujúcej tabuľky:

> Príklad:
> Určte množiny $FIRST(X), X \in N \cup T$, $FIRST(BS)$, $FIRST(AB)$, $FIRST(BA)$ ku gramatike z prvého príkladu. <br>
>
> Riešenie:
> Postupné určovanie množín $FIRST(X), X \in N \cup T$ môžeme zaznamenať pomocou nasledujúcej tabuľky:
>
>![Tabuľka FIRST](resources/cv8_new/tabulkaFirst.PNG)
>
>
>
> **Vysvetlenie:**
>
> V prvých troch riadkoch máme postupne zaznamenané špeciálne prípady– terminály, pravidlá tvaru $A \to a\alpha$ a neterminály, ktoré sa môžu prepísať na $\epsilon$. <br>
>
> V prvej iterácii pribudne: <br>
> * $a$ do $FIRST(S)$ – na základe pravidla $S → C\unicode{x24} $ a $FIRST(C\unicode{x24}) = {a}$,keďže $FIRST(C)$ obsahuje zatiaľ a; <br>
> * $b,($ do $FIRST(C)$ – na základe pravidla $C → A(C)$ a $FIRST(A(C)) = {b, (}$, keďže $FIRST(A)$ obsahuje zatiaľ $b,\epsilon$; <br>
>
> V druhej iterácii pribudne: <br>
> * $b,($ do $FIRST(S)$ –na základe pravidla $S → C\unicode{x24}$ a toho,že teraz už bude $FIRST(C\unicode{x24}) = {a,b,(}$, keďže po predchádzajúcej iterácii $FIRST(C)$ obsahuje $a,b,($. <br>
>
>
> V tretej iterácii už žiadne nové symboly nikde nepribudnú, výpočet môžeme preto ukončiť a „zosumarizované“ množiny $FIRST$ pre všetky symboly gramatiky vidíme v poslednom riadku tabuľky. Na základe nich potom môžeme určiť: <br>
>
> * $FIRST(BS) = {+,a,b,(}$ – keďže $\epsilon \in FIRST(B)$, do FIRST(BS) sa dostanú aj terminály z FIRST(S); <br>
> * $FIRST(AB) = {b,+,ε}$ – keďže $\epsilon \in FIRST(A),FIRST(B)$, do $FIRST(AB)$ sa dostanú terminály z $FIRST(A)$, $FIRST(B)$ a aj $\epsilon$; <br>
> * $FIRST(CB) = {a,b,(}$ – keďže $\epsilon / \epsilon  FIRST(C)$, do $FIRST(CB)$ sa dostanú len terminály z $FIRST(C)$. <br>

---

**FOLLOW**

Nech $G = (N, T, P, S)$ je redukovaná gramatika a $A \in N$. Potom

$$ \text{FOLLOW}(A) = { a \mid S \Rightarrow^+ \dots A a \dots, \text{ a zároveň } a \in T } \cup { unicode{x24}, \text{ ak } S \Rightarrow^* \alpha A } $$

Množina FOLLOW(A) pre neterminál $A$ je množina všetkých terminálnych symbolov, ktoré môžu stáť bezprostredne za neterminálom $A$ v nejakej vetnej forme – teda v reťazci odvoditeľnom zo začiatočného symbolu gramatiky.

Ak neterminál $A$ môže stáť na konci niektorej vetnej formy, potom FOLLOW(A) zahŕňa aj $\varepsilon$ (prázdny reťazec).

> Príklad:
> Majme bezkontextovú gramatiku G. Transformujte gramatiku G na bezkontextovú gramatiku G', ktorá nebude obsahovať nadbytočné symboly a L(G) = L(G'). <br>
>
> Uvažujme o gramatike G = (N, T, P, S), kde N = {S, A, B, C}, T = {a, b, +, (,), $} a množina pravidiel P je tvorená pravidlami: <br>
> S → C\$   <br>
> A → b | ε    <br>
> B → +C | ε   <br>
> C → A(C) | aB    <br>
>
>
> Potom: <br>
> 
>* $FOLLOW(S)$ obsahuje: <br>
> $\epsilon$– samotné $S $ je vetná forma, pričom $S$ stojí na jej konci; <br>
>
>* $FOLLOW(A)$ obsahuje: <br>
>–$($– vďaka odvodeniu $S ⇒ C$ ⇒ A(C)\unicode{x24}$; <br>
>
>* $FOLLOW(B)$ obsahuje: <br>
> $\unicode{x24}$– vďaka odvodeniu $S ⇒ C\unicode{x24} ⇒aB\unicode{x24}$; <br>
> $)$– vďaka odvodeniu $S ⇒ C\unicode{x24} ⇒ A(C)\unicode{x24} ⇒A(aB)$ <br>
>
>* $FOLLOW(C)$ obsahuje: <br>
> $\unicode{x24}$– vďaka odvodeniu $S ⇒ C\unicode{x24}$; <br>
> $)$– vďaka odvodeniu$ S ⇒ C\unicode{x24} ⇒ A(C)\unicode{x24}$. <br>




***
**Algoritmus 4.** Vytvorenie množín $FOLLOW(A)$ pre $A \in N$  
**Vyžaduje:** redukovanú bezkontextovú gramatiku $G = (N,T,P,S)$, množiny $FIRST(X)$ pre $X \in N \cup T$  
**Zabezpečí:** vytvorenie množín $FOLLOW(A)$ pre $A \in N$  
***
1. **pre všetky** $A \in N$ **rob**  
2. &emsp; $FOLLOW(A) \leftarrow \emptyset$;  
3. **koniec pre**  
4. $FOLLOW(S) \leftarrow \{ \unicode{x24} \} $;
5. **opakuj**  
6. &emsp; **pre všetky** $B \in N$ v pravých stranách pravidiel $A \to \alpha B\beta$ **rob**  
7. &emsp;&emsp; $FOLLOW(B) \leftarrow FOLLOW(B) \cup (FIRST(\beta) - \{\varepsilon\})$;  
8. &emsp;&emsp; **ak** $\varepsilon \in FIRST(\beta)$ **potom**  
9. &emsp;&emsp;&emsp; $FOLLOW(B) \leftarrow FOLLOW(B) \cup FOLLOW(A)$;  
10. &emsp;&emsp; **koniec ak**  
11. &emsp; **koniec pre**  
12. **pokiaľ** nastala zmena u niektorej množiny $FOLLOW(B), B \in N$  
***


> Príklad:
> Určte množiny $FOLLOW(A), A \in N$  ku gramatike z prvého príkladu. <br>
>
> Riešenie:
> Postupné určovanie množín $FOLLOW(A), A \in N$ môžeme zaznamenať pomocou nasledujúcej tabuľky:
>
>![Tabuľka FOLLOW](resources/cv8_new/tabulkaFollow.PNG)
>
>
>
> **Vysvetlenie:**
>
> V prvej iterácii:
>
>   * Na základe pravidla $B \to +C (kde A = B, B = C, \beta = \epsilon)$ nemá do $FOLLOW(C)$ čo pribudnúť, pretože v množine $FOLLOW(B)$ ešte nemáme žiaden symbol.
>
>   * Na základe pravidla$ C \to aB (kde A = C, B = B, \beta = \epsilon)$ do $FOLLOW(B)$ pribudnú všetky symboly, ktoré sa aktuálne nachádzajú v množine $FOLLOW(C)$, teda $\unicode{x24}$ a $)$.
>
> Pridávanie ostatných symbolov je zrejmé z pravidiel uvedených v tabuľke (podtrhnuté sú neterminály vystupujúce v pozícii neterminálu B).
>
> V druhej iterácii už žiaden nový symbol nepribudne do žiadnej FOLLOW množiny.

---



# Syntaktický analyzátor jazyka LL(1)

Základnou požiadavkou na v praxi použiteľný syntaktický analyzátor je, aby bol schopný deterministicky spracovávať vstupné reťazce s lineárnou časovou zložitosťou ⇒ **odstránenie nedeterminizmu** (uvedené v teoretickom modeli). <br>

Ak $A$ je expandovaný neterminál a ak východzia gramatika obsahuje viacero $A$-pravidiel, potom je potrebné stanoviť, ktoré z $A$-pravidiel sa na expanziu neterminálu $A$ použije ⇒ **syntaktický analyzátor jazyka LL(1)**. <br>

Syntaktický analyzátor jazyka LL(1) realizuje expanziu podľa toho $A$-pravidla, ktoré mu signalizuje usporiadaná dvojica $(A,t)$, kde $t$ je aktuálny vstupný symbol. <br>

Definícia znie: <br>

Nech $G = (N, T, P, S)$ je bezkontextová gramatika. Rozkladová tabuľka syntaktického analyzátora jazyka $LL(1)$ $RT[A,t]$ je zobrazenie $ N \times T_{\varepsilon} \rightarrow P $ popisujúce, ktoré pravidlo je potrebné použiť na expanziu neterminálu $A$ nachádzajúceho sa na vrchu zásobníka syntaktického analyzátora, ak je na vstupe terminál $t$ ($ t = \varepsilon $ znamená, že už bol prečítaný celý vstupný reťazec).

<br>
<br>

**Rozkladová tabuľka** je spravidla neúplné zobrazenie. V prípade, že vstupný symbol $t$ neurčuje použitie žiadneho pravidla pre expanziu neterminálu $A$ nachádzajúceho sa na vrchu zásobníka syntaktického analyzátora, signalizuje to syntaktickú chybu.

**PREDICT**

Nech $G = (N, T, P, S)$ je redukovaná gramatika a $ A \to \alpha \in P $. Potom

$$ \text{PREDICT}(A \to \alpha) = 
\begin{cases} 
\text{FIRST}(\alpha), & \text{ak } \varepsilon \notin \text{FIRST}(\alpha) \\ 
(\text{FIRST}(\alpha) - \{\varepsilon\}) \cup \text{FOLLOW}(A), & \text{ak } \varepsilon \in \text{FIRST}(\alpha).
\end{cases} $$


* Množina $ \text{PREDICT}(A \to \alpha)$ takto predstavuje množinu všetkých takých terminálnych symbolov (príp. $\varepsilon$ pre prípad prázdneho vstupu), ktoré, pokiaľ sanachádzajú na vstupe, signalizujú možnosť použiť na expanziu neterminálu $A$ pravidlo $A \to \alpha$.


* Ak sa máme pre daný neterminál $A$ na vrchu zásobníka syntaktického analyzátora jednoznačne rozhodnúť pri jeho expanzii pre jedno A-pravidlo, potom pre každý neterminál $A \in N$ musí platiť: Ak $A → \alpha_i$ a $A → \alpha_j$ sú dve rôzne A-pravidlá, potom
$$ \text{PREDICT}(A \rightarrow \alpha_i) \cap \text{PREDICT}(A \rightarrow \alpha_j) = \emptyset $$

---

Redukovaná bezkontextová gramatika $G = (N, T, P, S)$, v ktorej všetky dvojice pravidiel s rovnakou ľavou stranou spĺňajú (*), sa nazýva **LL(1) gramatika**.

V prípade LL(1) gramatiky môžeme jej **rozkladovú tabuľku** vytvoriť pomocou množín PREDICT nasledovne:
$$ \text{Ak } t \in \text{PREDICT}(A \rightarrow \alpha), \text{ potom } RT[A,t] \text{ obsahuje pravidlo } A \rightarrow \alpha. \quad (**) $$

Ak je gramatika LL(1) gramatika, potom každá položka rozkladovej tabuľky obsahuje maximálne jedno pravidlo a rozhodovanie o použití pravidla pri expanzii je preto vždy jednoznačné.


> Príklad:
> Zostrojte rozkladovú tabuľku syntaktického analyzátora j. LL(1) ku gramatike $ G = (N, T, P, S), \quad N = \{ \langle \text{program} \rangle, \langle \text{príkazy} \rangle, \langle \text{príkaz} \rangle \}, \quad T = \{ \text{begin}, \text{end}, ;, p \}, \quad S = \langle \text{program} \rangle $
>
>s pravidlami
>
> 1. $\quad  \langle \text{program} \rangle \rightarrow \text{begin } \langle \text{príkazy} \rangle \text{ end}$  <br>
> 2. $\quad  \langle \text{príkazy} \rangle \rightarrow \langle \text{príkaz} \rangle \; ; \; \langle \text{príkazy} \rangle$ <br>
> 3. $\quad  \langle \text{príkazy} \rangle \rightarrow \varepsilon$ <br>
>
> Riešenie:
> Najprv zostrojíme množiny FIRST(X), X ∈ N ∪T a FOLLOW(A), A ∈ N, ktoré nám pomôžu pri konštrukcii množín PREDICT (uvádzame už len výsledné tabuľky):
>
>![Tabuľka FOLLOW](resources/cv8_new/tabulkaFirstFollow.PNG)
>
> Ďalej určíme množiny PREDICT k jednotlivým pravidlám: <br>
> 
>$ \text{PREDICT}(1.) = \text{FIRST}(\text{begin } \langle \text{príkazy} \rangle \text{ end}) = \{ \text{begin} \}; $ <br>
>$ \text{PREDICT}(2.) = \text{FIRST}(\langle \text{príkaz} \rangle \; ; \; \langle \text{príkazy} \rangle) = \{ p \}; $ <br>
>$ \text{PREDICT}(3.) = \{ \text{end} \}, \text{ lebo } \text{FIRST}(\varepsilon) = \{ \varepsilon \}$, <br>
> $ (\varepsilon \text{ do množiny } \text{PREDICT}(3.) \text{ nezaradíme, avšak musíme do nej zaradiť symboly z } \text{FOLLOW}(\langle \text{príkazy} \rangle), \text{ tzn. end}); $ <br>
>$ \text{PREDICT}(4.) = \text{FIRST}(p) = \{ p \} $ <br>
>
>
>
> Na základe množín PREDICT a vzťahu (**) už ľahko zostrojíme rozkladovú tabuľku syntaktického analyzátora jazyka LL(1):
>
> ![Rozkladová Tabuľka](resources/cv8_new/tabulkaRozkladová.PNG)
>
> Keďže každá položka rozkladovej tabuľky obsahuje **maximálne jedno pravidlo** (prázdne položky signalizujú syntaktickú chybu), **gramatika je LL(1) gramatika**.


Nie každá bezkontextová gramatika je LL(1) gramatika, ba dokonca vo všeobecnosti pre daný bezkontextový jazyk ani LL(1) gramatika nemusí existovať.

V niektorých prípadoch môžeme bezkontextovú gramatiku upraviť na LL(1) gramatiku. 

To, že vstupná gramatika nie je LL(1) gramatika, zistíme napríklad tak, že do niektorej položky rozkladovej tabuľky môžeme umiestniť viacero pravidiel ⇒ vzniká konflikt – v danom prípade nevieme, ktoré pravidlo použiť na expanziu príslušného neterminálu.

Najčastejšie zdroje konfliktov, ktoré dokážeme odstrániť, sú:<br>
a) spoločné predpony, <br>
b) ľavá rekurzia.<br>


Nech G = (N, T, P, S) je bezkontextová gramatika, pričom súčasťou jej množiny pravidiel P sú pravidlá tvaru:

$$ A \rightarrow \alpha\beta_1 \mid \alpha\beta_2 \mid \dots \mid \alpha\beta_n, \text{ kde } n \geq 2. $$

Potom reťazec $\alpha \in (N \cup T)^+$ nazývame **spoločná predpona**.



---

**Vyčlenenie spoločných symbolov zľava** <br>

Jedným z častých problémov, ktoré bránia gramatike byť LL(1) gramatikou, je existencia **spoločných predpôn** v pravidlách pre rovnaký neterminál.

**Definícia:** <br>

Nech $G = (N, T, P, S)$ je bezkontextová gramatika, pričom súčasťou jej množiny pravidiel $P$ sú pravidlá tvaru:

$$ A \rightarrow \alpha\beta_1 \mid \alpha\beta_2 \mid \dots \mid \alpha\beta_n, \text{ kde } n \geq 2. $$

Potom reťazec $\alpha \in (N \cup T)^+$ nazývame **spoločná predpona**.

Problém nastáva, pretože syntaktický analyzátor jazyka LL(1) nedokáže jednoznačne určiť, ktorú z pravých strán pravidiel má použiť pri expanzii neterminálu $A$, keďže všetky začínajú rovnakou predponou $\alpha$.



Princíp vyčlenenia spoločných symbolov zľava spočíva v transformácii gramatiky tak, aby sa spoločná predpona analyzovala iba raz a rôzne možnosti pokračovania sa riešili pomocou nového neterminálu.

Pre pravidlá s rovnakou predponou:
$$ A \to \alpha\beta_1 \mid \alpha\beta_2 \mid \dots \mid \alpha\beta_n $$

Vytvoríme nové pravidlá:
$$ A \to \alpha A' $$
$$ A' \to \beta_1 \mid \beta_2 \mid \dots \mid \beta_n $$

kde $A'$ je nový neterminál.

Výhody transformácie: <br>
1. **Odstránenie konfliktu** - po transformácii je jednoznačne určené, ktoré pravidlo sa má použiť pri expanzii neterminálu
2. **Efektívnejšia analýza** - spoločná predpona sa analyzuje iba raz
3. **Možnosť deterministickej analýzy** - výsledná gramatika môže spĺňať podmienky LL(1)

> Poznámka
>
> Po vyčlenení spoločných symbolov zľava je nutné znovu vypočítať množiny FIRST, FOLLOW a PREDICT pre upravenú gramatiku a skontrolovať, či gramatika spĺňa podmienky LL(1).

**Algoritmus 5.** Vyčlenenie spoločných symbolov zľava  
**Vyžaduje:** bezkontextovú gramatiku $G = (N, T, P, S)$ s pravidlami, ktoré obsahujú spoločné predpony  
**Zabezpečí:** úpravu gramatiky $G$ odstránením spoločných predpôn  
***
1. **pre každý** neterminál $A \in N$ **rob**  
2. &emsp; **pokiaľ** existujú pravidlá tvaru $A \to \alpha\beta_1 \mid \alpha\beta_2 \mid \dots \mid \alpha\beta_n$ s rovnakou predponou $\alpha$ **rob**  
3. &emsp;&emsp; vytvor nový neterminál $A'$ taký, že $A' \notin N$;  
4. &emsp;&emsp; $N \leftarrow N \cup \{A'\}$;  
5. &emsp;&emsp; odstráň pravidlá $A \to \alpha\beta_1 \mid \alpha\beta_2 \mid \dots \mid \alpha\beta_n$ z $P$;  
6. &emsp;&emsp; pridaj pravidlo $A \to \alpha A'$ do $P$;  
7. &emsp;&emsp; pridaj pravidlá $A' \to \beta_1 \mid \beta_2 \mid \dots \mid \beta_n$ do $P$;  
8. &emsp; **koniec pokiaľ**  
9. **koniec pre**  
***

> **Príklad:**
> Nech máme gramatiku $ G = (N, T, P, S), \quad N = \{ \langle \text{príkaz} \rangle, \langle \text{príkazy} \rangle, \langle \text{podmienka} \rangle \}, \quad T = \{ \text{if}, \text{then}, \text{else}, \text{begin}, \text{end} \}, \quad S = \langle \text{príkaz} \rangle $
>
> s pravidlami:
>
> 1. $\langle \text{príkaz} \rangle \to \text{if } \langle \text{podmienka} \rangle \text{ then } \langle \text{príkaz} \rangle$  
> 2. $\langle \text{príkaz} \rangle \to \text{if } \langle \text{podmienka} \rangle \text{ then } \langle \text{príkaz} \rangle \text{ else } \langle \text{príkaz} \rangle$  
> 3. $\langle \text{príkaz} \rangle \to \text{begin } \langle \text{príkazy} \rangle \text{ end}$  
>
> V tejto gramatike pravidlá 1. a 2. majú spoločnú predponu $\text{if } \langle \text{podmienka} \rangle \text{ then } \langle \text{príkaz} \rangle$, čo spôsobí konflikt pri analýze LL(1).
>
> **Riešenie:**
> Aplikujme algoritmus vyčlenenia spoločných symbolov zľava:
>
> 1. Identifikujeme neterminál $\langle \text{príkaz} \rangle$ s pravidlami obsahujúcimi spoločnú predponu.
> 2. Vytvoríme nový neterminál $\langle \text{príkaz-else} \rangle$.
> 3. Nahradíme pravidlá 1. a 2. jedným pravidlom:
>    $\langle \text{príkaz} \rangle \to \text{if } \langle \text{podmienka} \rangle \text{ then } \langle \text{príkaz} \rangle \langle \text{príkaz-else} \rangle$
> 4. Pridáme nové pravidlá:
>    $\langle \text{príkaz-else} \rangle \to \text{else } \langle \text{príkaz} \rangle \mid \varepsilon$
>
> Nová gramatika $G' = (N', T, P', S)$ po transformácii má:
> $N' = \{ \langle \text{príkaz} \rangle, \langle \text{príkazy} \rangle, \langle \text{podmienka} \rangle, \langle \text{príkaz-else} \rangle \}$
>
> a pravidlá:
> 1. $\langle \text{príkaz} \rangle \to \text{if } \langle \text{podmienka} \rangle \text{ then } \langle \text{príkaz} \rangle \langle \text{príkaz-else} \rangle$  
> 2. $\langle \text{príkaz} \rangle \to \text{begin } \langle \text{príkazy} \rangle \text{ end}$  
> 3. $\langle \text{príkaz-else} \rangle \to \text{else } \langle \text{príkaz} \rangle$  
> 4. $\langle \text{príkaz-else} \rangle \to \varepsilon$  
>
> Táto gramatika už neobsahuje spoločné predpony a spĺňa podmienky LL(1) gramatiky.

---

[Kostra projektu na stiahnutie je dostupná tu. ](resources/cv8_new/cv8task.zip)

> Úloha:
> Vašou úlohou je analyzovať zdrojový kód napísaný v pythone a doplniť funkcionalitu.


# Dotazník na ohodnotenie učiva
Vážení študenti, <br>
poprosil by som Vás o vyplnenie tohto [dotazníka](https://forms.gle/zRuqDgm87pSkbCNp7) .   <br>

Tento dotazník slúži na ohodnotenie vašich skúseností s pripravenými materiálmi z ôsmeho cvičenia. Na vylepšovaní učiva sa aktívne pracuje a Vaše odpovede nám pomôžu zlepšiť kvalitu výučby. <br>

Ďakujem<br>