---
Nadpis: Konečno-stavové akceptory.
---

## Ciele

  1. {ciel_konstrukcia_ksa} Zopakovať si teóriu odvodenia konečno-stavových automatov z regulárnych výrazov.
  2. {ciel_konstrukcia_ksa_precvicenie} Precvičiť si odvodenie DKA na základe zadaného regulárneho výrazu.
  3. {ciel_implementacia_ksa} Porozumieť implementácii DKA pre daný regulárny výraz.  


## Úvod

Cieľom dnešného cvičenia je opakovanie a prehĺbenie teórie regulárnych výrazov a pochopenie priameho odvodenia deterministického konečno-stavového automatu z regulárneho výrazu (pomocou metódy vytvárania prechodových grafov). Ďalším cieľom je pochopenie dodanej implementácie konečno-stavového akceptora a možnosť implementácie ďalšieho akceptora. 

## Krok {ciel_konstrukcia_ksa}

Zopakujte si [teóriu regulárnych výrazov](resources/regularne_vyrazy.pdf). Už viete, že regulárne výrazy je možné zobraziť aj graficky pomocou **prechodových diagramov**. Princíp zostrojenia takýchto diagramov bol vysvetlený v predošlom cvičení.


Konečno-stavové automaty sa bežne v teórii informatiky vytvárajú prostredníctvom vytvárania prechodových tabuliek (ako je tomu v [zbierke](resources/ti_priklady.pdf) v kapitole 3.2). Takto vytvorené automaty sú **nedeterministické**. Nedeterministické automaty sú také, kde pri niektorom vstupe *x* je definovaná prechodová funkcia nie do jediného možného stavu *y*, ale do množiny možných stavov {*y1*, *y2*, ...*yn*}. Na vytvorenie deterministického automatu sa využíva metóda nazývaná **determinizácia**.

Na tomto predmete sa však využíva iná metóda, **vytváranie prechodových grafov** , ktorá je uvedená v animovanej [prezentácii](resources/ksa.ppsx). Táto metóda má tú výhodu, že pomocou nej je možné vytvoriť priamo deterministický konečno-stavový automat a **nie je potrebná ďalšia determinizácia**. Je ju však možné použiť _len vtedy_, ak množinu vstupných reťazcov pre KSA je možné definovať prostredníctvom _regulárnych výrazov_.

> Príklad:
> Nájdite DKA, ktorý reprezentuje regulárny výraz *0|1{0|1}* (z predošlého cvičenia).
>
> Postupovať budeme nasledujúcim spôsobom.
>
> 1. Pre daný regulárny výraz nakreslíme prechodový diagram:
> ![Prechodový diagram pre regulárny výraz *0|1{0|1}*](resources/cv2/regex.png)
>
> 2. Určíme počiatočný stav *q0* umiestnením tokenu:
> Stav *q0 = .0|.1{0|1}*
> ![Počiatočný stav](resources/cv2/regex-s0.png)
>
> 3. Vygenerujeme jednotlivé stavy pomocou prechodovej funkcie *δ*:
>
> * *δ(q0, 0) = q1*, dostávame stav *q1 = 0|1{0|1}.* (koncový stav)
> ![Zmena stavu na *q1*](resources/cv2/regex-s1.png)
>
> * *δ(q0, 1) = q2*, dostávame stav *q2 = 0|1{.0|.1}.* (koncový stav)
> ![Zmena stavu na *q2*](resources/cv2/regex-s2.png)
>
> * *δ(q1, 0) =* ⊥, prechod nie je definovaný
> * *δ(q1, 1) =* ⊥, podobne ako v predošlom prípade
>
> * *δ(q2, 0) = q2*
> * *δ(q2, 1) = q2*
>
>
> 4. Zostavíme tabuľku pre prechodovú funkciu:
>
>**stav**|**0**|**1**
>-----|-----|-----
>*q0*|*q1*|*q2*
>*q1*|⊥|⊥
>*q2*|*q2*|*q2*
>
> 5. Z prechodovej tabuľky nakreslíme DKA:
> ![DKA pre regulárny výraz *0|1{0|1}*](resources/cv2/dka.png)
>

> Poznámka:
> Symbolom ⊥ označujeme nedefinovanú hodnotu.
>

## Krok {ciel_konstrukcia_ksa_precvicenie}

Precvičte si vytváranie deterministického konečno-stavového akceptora na základe zadaného regulárneho výrazu s využitím metódy vytvárania prechodových grafov z predošlého kroku na nasledujúcich príkladoch:

> Úloha:
> Vytvorte prechodový diagram regulárneho výrazu a prechodový graf. Následne vytvorený prechodový graf prekreslite na DKA.
>
> Regulárny výraz:
>  
> ```
> a[a]{b}b
> ```

> Úloha:
> Vytvorte prechodový diagram regulárneho výrazu a prechodový graf. Následne vytvorený prechodový graf prekreslite na DKA.
> 
> Regulárny výraz:
>  
> ```
> [c]{ab}c
> ```

> Úloha:
> Vytvorte prechodový diagram regulárneho výrazu a prechodový graf. Následne vytvorený prechodový graf prekreslite na DKA.
> 
> Regulárny výraz:
>  
> ```
> {b}[c]ba
> ```

> Úloha:
> Vytvorte prechodový diagram regulárneho výrazu a prechodový graf. Následne vytvorený prechodový graf prekreslite na DKA.
>
> Regulárny výraz:
>  
> ```
> a{ab}a[ab]b
> ```

## Krok {ciel_implementacia_ksa}

V prvom kroku tohto cvičenia sme sa naučili, ako priamo vytvoriť z regulárneho výrazu DKA. V tomto kroku sa oboznámime s praktickou implementáciou daného DKA v jazyku C.

> Úloha:
> Podľa pokynov vyučujúceho samostatne implementuje DKA pre určený regulárny výraz binárnych numerálov. Zohľadnite skutočnosť, že na vstupe môže byť ľubovoľný reťazec. Váš program by mal vedieť nájsť binárne numerály v zadanom reťazci. Prediskutujte realizované riešenie.
>


> Úloha:
> Podľa pokynov vyučujúceho samostatne implementuje DKA pre určený regulárny výraz z predošlého kroku. Prediskutujte realizované riešenie.
>





## Doplňujúce úlohy

> Úloha:
> Prejdite si príklady na vytváranie regulárnych výrazov v [zbierke](resources/ti_priklady.pdf) od č. 1.13

> Úloha:
> Samostatne vyriešte príklady na vytváranie DKA v [zbierke](resources/ti_priklady.pdf) od č. 3.1 \- precvičte si ich pomocou metódy vytvárania prechodových diagramov.

> Úloha:
> Precvičiť znalosti regulárnych výrazov (v ich bežnejšom zápise) môžete aj pomocou [krížoviek](http://regexcrossword.com/). Skúste si niektoré regulárne výrazy z krížoviek prepísať do zápisu používaného na tomto cvičení.
>
>> Vyučujúci:
> Návrh: toto je možné prideliť študentom ako domácu úlohu a kto to celé vylúšti, dostane body naviac - napríklad pri nerozhodnom výsledku pri zadaní (alebo iné výhody). Upozorniť ich však, nech to medzi sebou vo vlastnom záujme nezdieľajú, lebo ak ich bude veľa, tak nedostane body nikto :-) Vyskušané, zabralo :D
