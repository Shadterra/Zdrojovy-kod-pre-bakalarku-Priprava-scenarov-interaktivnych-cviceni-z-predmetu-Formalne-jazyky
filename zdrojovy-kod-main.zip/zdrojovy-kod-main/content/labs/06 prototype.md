---
Nadpis: Implementacia interpretera kalkulačky
---

## Ciele

  1. {ciel_teoria} Zoznámiť sa z špecifikáciou priority a asociatívnosti.
  2. {ciel_interpreter} Predstaviť základnú teóriu Interpretera.
  3. {ciel_kalkulacka} Zostrojenie jednoduchého interpreteru kalkulačky.


## Úvod

V tomto učebnom materíali sa zoznámime s špecifikáciou priority a asociatívnosti, povieme si čo je to interpreter a následne implementujeme kalkulačku v jazyku Python pomocou rekurzívy.

## Krok {ciel_teoria}

Pri návrhu programovacích jazykov a vyhodnocovaní výrazov dva dôležité koncepty určujú, ako sa výrazy analyzujú a vyhodnocujú: **priorita operátorov (prednosť)** a **asociatívnosť operátorov**.

**Špecifikácia priority (prednosť)** <br>
Priorita určuje, ktoré operátory sa vyhodnocujú pred inými. Napríklad v matematike má násobenie vyššiu prioritu ako sčítanie, preto sa 1 + 2 * 3 vyhodnotí ako 7 a nie 9. <br>


Máme gramatiku v BNF: 

  > \<A> ::=  \<M> { ("+" | "-") \<M> }; <br>
  > \<M> ::=  \<T> { ("*" | "/") \<T> }; <br>
  > \<T> ::= číslo | "(" \<A> ")"; <br>

Táto gramatika vynucuje nasledujúce úrovne priority:

1. Najvyššia priorita: Zátvorky (spracované v <T>)
2. Stredná priorita: Násobenie a delenie (spracované v <M>)
3. Najnižšia priorita: Sčítanie a odčítanie (spracované v <A>)

Štruktúra gramatiky priamo určuje prioritu operátorov. Každá úroveň v gramatike zodpovedá úrovni priority operátorov. <br>
Táto hierarchia sa dosahuje prostredníctvom odkazov medzi pravidlami. Pravidlo pre \<A> odkazuje na \<M>, ktoré zase odkazuje na \<T>. <br>
Toto reťazenie zabezpečuje, že výrazy v rámci \<T> sa vyhodnotia najskôr, nasledované výrazmi v \<M>, a nakoniec výrazmi v \<A>. <br>

> Príklad:
> Zistite ako vyšie spomenutá gramatika analyzuje výraz 1 + 2 * 3. <br>
> 
> 1. Začíname s \<A>
> 2. \<A> sa rozšíri na \<M> + \<M>
> 3. Prvé \<M> sa rozšíri na \<T> (keďže tam nie sú násobenia)
> 4. Prvé \<T> je číslo 1
> 5. Druhé \<M> sa rozšíri na \<T> * \<T>
> 6. Tieto \<T> sú čísla 2 a 3
>
> Toto nám dáva syntaktický strom, kde sa najprv vypočíta 2 * 3, potom sa pripočíta k 1, čo dáva výsledok 1 + 6 = 7.
> ![Syntaktický strom pre výraz 1 + 2 * 3](resources/cv6_new/123_priorita_priklad.png)
>

![Stromy odvodenia pri rôznej priorite operátorov](resources/cv6_new/priorita.png)


> Úloha:
> Zostrojte nasledujúcu gramatiku tak aby matematické výrazy nemali prioritu.
  > BNF:
  > \<A> ::= \<M> { ("+" | "-") \<M> }; <br>
  > \<M> ::=  \<T> { ("*" | "/") \<T> }; <br>
  > \<T> ::=  číslo | "(" \<A> ")"; <br>
><details>
  <summary>Zobraziť riešenie</summary>
  <p><strong>Odpoveď:</strong></p>
  &lt;A&gt; ::= &lt;T&gt; { ("+" | "-" | "*" | "/") &lt;T&gt; }; <br>
  &lt;T&gt; ::= číslo | "(" &lt;A&gt; ")"; <br>
  Kedže nemáme v tejto gramatike zakódovanú prioritu, tak by sme tento výraz 1 + 2 * 3 analyzovali ako (1 + 2) * 3 = 9.

</details>


<br>





<br>

**Špecifikácia asociatívnosti** <br>
Asociatívnosť operátorov určuje, v akom poradí sa budú vyhodnocovať operácie s rovnakou prioritou. Pri implementácii syntaktického analyzátora pomocou rekurzívnych funkcií sa asociatívnosť vyjadruje tvarom pravidiel gramatiky.

Pre zabezpečenie správnej **priority operátorov** sa pre každú prioritnú úroveň vytvorí jeden neterminál. Pravidlá sa pre jednotlivé úrovne zreťazia tak, že smerom dovnútra (vnáranie k operandom) sa zvyšuje priorita.


**Asociatívnosť operátorov** je zabezpečená tvarom pravidla nasledovne:

Asociatívnosť | Pravidlo
---|---
ľavá | `E → T { op T }`
pravá | `E → T [ op E ]`
neasociatívnosť | `E → T [ op T ]`

<br>

Asociativita je dôležitá, keď sa v sekvencii objaví viacero operátorov s rovnakou prioritou za sebou. Napríklad v aritmetických výrazoch:

- Ľavá asociatívnosť: 5−3−2 sa vyhodnotí ako (5−3)−2=0.
- Pravá asociatívnosť: 2^3^2 sa vyhodnotí ako 2^(3^2)=512.
- Neasociatívne operátory: Napríklad operátor porovnania je neasociatívny.

<br>


![Stromy odvodenia pri rôznej asociatívnosti operátora](resources/cv6_new/asociativnost.png)



## Krok {ciel_interpreter}

Interpreter je počítačový program, druh prekladača, ktorý interpretuje iný program napísaný v nejakom programovacom jazyku. Interpretre môžu program interpretovať riadok po riadku alebo preložia program do nejakého medzikódu a tento medzikód potom vykonávajú. Ak je v programe syntaktická chyba, prvý druh interpretra vykoná program po túto syntaktickú chybu a zahlási chybu na príslušnom riadku, druhý druh interpretra program nezačne vykonávať a počas prekladu do medzikódu zahlási chybu. <br>

**Základné fázy interpretácie** <br>
Interpretér spracováva zdrojový kód v nasledujúcich krokoch: <br>

1. Lexikálna analýza (Lexing) <br>
Prvou fázou interpretácie je lexikálna analýza, pri ktorej sa vztupný reťazec rozdeľuje na tokeny. Tokeny sú základné stavebné prvky syntaktickej analýzy, ako sú kľúčové slová, identifikátory, literály a operátory. (Príklad: Pre výraz x = 10 + 5 by tokeny mohli byť x, =, +, čísla.) <br>

2. Syntaktická analýza (Parsing) <br>
Kontroluje, či postupnosť tokenov zodpovedá gramatickým pravidlám jazyka, a vytvára jeho vnútornú reprezentáciu, často vo forme abstraktného syntaktického stromu (AST). <br>

3. Sémantická analýza <br>
Kontroluje, či program dáva zmysel z hľadiska sémantiky jazyka. To zahŕňa kontrolu typov, rozlíšenie premenných a funkcií, a ďalšie kontextové informácie.

4. Interpretácia (Vykonanie) <br>
Interpretér vykonáva príkazy programu priamo podľa ich významu, pričom spracováva výpočty, volania funkcií a prácu s pamäťou.

<br>

<br>

Je veľke množstvo techník na tvorbu syntaktickej analýzy ktorých názvy sú väčšinou kombináciami „L“ a „R“ – [LL(k)](https://en.wikipedia.org/wiki/LL_parser), [LR(1)](https://en.wikipedia.org/wiki/LR_parser), [LALR](https://en.wikipedia.org/wiki/LALR_parser). <br>
My si ukážeme tu najzákladnejšiu metódu zvanú [rekurzívny zostup](https://en.wikipedia.org/wiki/Recursive_descent_parser). <br>

**Rekurzívny zostup** <br>
Rekurzívny zostup je najjednoduchší spôsob zostavenia analyzátora. Rekurzívny zostup sa považuje za syntaktický analyzátor zhora nadol, pretože začína od najvyššieho alebo najvzdialenejšieho gramatického pravidla a postupuje smerom nadol do vnorených podvýrazov, kým sa konečne dostane k listom syntaktického stromu. To je v kontraste s analyzátormi zdola nahor, ako je LR, ktoré začínajú primárnymi výrazmi a skladajú ich do väčších a väčších častí syntaxe.


Analyzátor rekurzívneho zostupu je doslovný preklad pravidiel gramatiky priamo do imperatívneho kódu. Každé pravidlo sa stáva funkciou. Gramatika sa prekladá do kódu zhruba ako: <br>

| Gramatická notácia   | Reprezentácia kódu| 
|-------|-------------------------|
| Terminál | kód na priradenie a využitie tokenu | 
| Neterminál| volanie funkcie tohto pravidla | 
| \| | **if** alebo **switch** |
| {R} alebo R{R} (\* alebo \+) | **while** alebo **for** loop | 
| [R] (?) | **if**    | 



## Krok {ciel_kalkulacka}
Predstavili sme si teóriu na tvorbu interpretera a teraz si  ako vytvoriť interpretér veľmi jednoduchej kalkulačky pre prirodzené čísla v programovacom jazyku python. <br>

**Gramatika našej kalkulačky** <br>
Vytvoríme si kalkulačku s nasledujúcimi operáciami: <br>
* plus +
* minus -
* krát *
* mocnina ^
* zátvorky ()

<br>

Najprv si definujeme prioritu operátorov tak ako fungujú v matematike: <br>

1. Najvyššia priorita: Zátvorky ()
2. Druhá priorita: Mocnina ^ (pravá asociatívnosť)
3. Tretia priorita: Násobenie * (ľavá asociatívnosť)
4. Najnižšia priorita: Sčítanie a odčítanie +, - (ľavá asociatívnosť)

<br>

Gramatika v EBNF notácii bude vyzerať následovne: <br>

  > \<E> ::= \<F> {("+" | "-") \<F>} <br>
  > \<F> ::= \<G> {"*" \<G>} <br>
  > \<G> ::= \<H> ["^" \<G>] <br>
  > \<H> ::= PRIRODZENÉ _ČÍSLA | "(" \<E> ")" <br>

  <br>

Teraz si môžeme ukázať ako bude vyzerať kód. <br>

**Lexikálna analýza (tokenizácia)** <br>
Najprv vytvoríme lexikálny analyzátor, ktorý rozdelí vstupný reťazec na tokeny. <br>

[Kostra projektu na stiahnutie je dostupná tu. ](resources/cv6_new/Kostra_projektu.zip)

> Úloha:
> Riešenie nie je kompletné. Vašou úlohou je analyzovať Lexer a doplniť funkcionalitu **def number(self)** pomocou [Hornerovej schémy](https://cs.wikipedia.org/wiki/Hornerovo_sch%C3%A9ma).

<div>

```python
import re
from enum import Enum, auto

# Definícia typov tokenov - základných prvkov, ktoré lexer rozpoznáva
class TokenType(Enum):
    NUMBER = auto()    # Číselná hodnota (prirodzené číslo)
    PLUS = auto()      # Operátor sčítania '+'
    MINUS = auto()     # Operátor odčítania '-'
    MULTIPLY = auto()  # Operátor násobenia '*'
    POWER = auto()     # Operátor mocniny '^'
    LPAREN = auto()    # Ľavá zátvorka '('
    RPAREN = auto()    # Pravá zátvorka ')'
    EOF = auto()       # Koniec vstupu (End Of File)

# Trieda reprezentujúca token - kombináciu typu a hodnoty
class Token:
    def __init__(self, type, value=None):
        self.type = type    # Typ tokenu (z enum TokenType)
        self.value = value  # Hodnota tokenu (relevantná hlavne pre čísla)
    
    def __repr__(self):
        # Reťazcová reprezentácia tokenu pre lepšie debuggovanie
        if self.value is not None:
            return f"Token({self.type}, {self.value})"
        return f"Token({self.type})"

# Lexikálny analyzátor - rozpoznáva a extrahuje tokeny zo vstupného reťazca
class Lexer:
    def __init__(self, text):
        self.text = text                                  # Vstupný text na analýzu
        self.pos = 0                                      # Aktuálna pozícia v texte
        self.current_char = self.text[0] if text else None  # Aktuálny znak alebo None ak je text prázdny
    
    def advance(self):
        """Posunie pozíciu na ďalší znak a aktualizuje current_char.
        Ak sa dostaneme za koniec textu, nastaví current_char na None."""
        self.pos += 1
        if self.pos < len(self.text):
            self.current_char = self.text[self.pos]
        else:
            self.current_char = None  # Dosiahli sme koniec textu
    
    def skip_whitespace(self):
        """Preskočí všetky medzery a nové riadky vo vstupe."""
        while self.current_char is not None and self.current_char.isspace():
            self.advance()
    
    def number(self):
        """Spracuje sekvenciu číslic ako prirodzené číslo používajúc Hornerovu schému.
        Vracia token typu NUMBER s číselnou hodnotou."""
        # Doplňte 


    
    def get_next_token(self):
        """Hlavná metóda lexikálneho analyzátora.
        Analyzuje text a vracia ďalší token v poradí."""
        while self.current_char is not None:
            # Ignorujeme medzery a formátovanie
            if self.current_char.isspace():
                self.skip_whitespace()
                continue
            
            # Rozpoznávanie čísla 
            if self.current_char.isdigit():
                return self.number()
            
            # Rozpoznávanie operátorov a zátvoriek - jeden znak = jeden token
            if self.current_char == '+':
                self.advance()
                return Token(TokenType.PLUS)
            
            if self.current_char == '-':
                self.advance()
                return Token(TokenType.MINUS)
            
            if self.current_char == '*':
                self.advance()
                return Token(TokenType.MULTIPLY)
            
            if self.current_char == '^':
                self.advance()
                return Token(TokenType.POWER)
            
            if self.current_char == '(':
                self.advance()
                return Token(TokenType.LPAREN)
            
            if self.current_char == ')':
                self.advance()
                return Token(TokenType.RPAREN)
            
            # Ak narazíme na neznámy znak, vyhodíme chybu
            raise ValueError(f"Nerozpoznaný znak: '{self.current_char}'")
        
        # Keď prejdeme celý text, vrátime token konca vstupu
        return Token(TokenType.EOF)
        
```
  
</div>

**Syntaktický analyzátor a interpreter** <br>
Teraz implementujeme rekurzívny zostupný parser, ktorý bude analyzovať a súčasne interpretovať výrazy. <br>

> Úloha:
> Riešenie nie je kompletné. Vašou úlohou je analyzovať Parser a doplniť funkcionalitu **def F(self)** a **def G(self)**.

<div>

```python

# Syntaktický analyzátor - implementuje rekurzívny zostup podľa gramatiky
class Parser:
    def __init__(self, lexer):
        self.lexer = lexer                        # Lexikálny analyzátor, ktorý dodáva tokeny
        self.current_token = self.lexer.get_next_token()  # Načítame prvý token
    
    def eat(self, token_type):
        """
        Verifikačná metóda - skontroluje, či aktuálny token je očakávaného typu.
        Ak áno, posunie sa na ďalší token. Ak nie, vyhodí chybu.
        
        Táto metóda implementuje prediktívnu analýzu - očakávame konkrétny token
        na základe gramatických pravidiel.
        """
        if self.current_token.type == token_type:
            self.current_token = self.lexer.get_next_token()  # Prejdeme na ďalší token
        else:
            raise SyntaxError(f"Syntaktická chyba: očakávaný token {token_type}, " 
                             f"získaný {self.current_token.type}")
    
    def E(self):
        """
        Implementuje gramatické pravidlo:
        <E> → <F> {("+" | "-") <F>}
        
        Spracuje sčítanie a odčítanie s ľavou asociatívnosťou.
        Najnižšia priorita operácií v našej gramatike.
         
        """
        # Najprv vyhodnotíme prvý F
        result = self.F()
        
        # Potom spracujeme všetky ďalšie operácie sčítania a odčítania
        while self.current_token.type in (TokenType.PLUS, TokenType.MINUS):
            token = self.current_token
            
            if token.type == TokenType.PLUS:
                self.eat(TokenType.PLUS)  # Overíme a posunieme sa za '+'
                result += self.F()     # Pripočítame hodnotu ďalšieho F
                
            elif token.type == TokenType.MINUS:
                self.eat(TokenType.MINUS)  # Overíme a posunieme sa za '-'
                term_value = self.F()   # Vyhodnotíme hodnotu F na odčítanie
                
                # Kontrola, či výsledok odčítania bude prirodzené číslo
                if term_value > result:
                    raise ValueError(f"Chyba: Výsledok odčítania ({result} - {term_value}) by bol záporný.")
                
                result -= term_value      # Odpočítame hodnotu ďalšieho F
        
        return result
    
    def F(self):
        """
        Implementujte gramatické pravidlo:
        <F> → <G> {("*") <G>}
        """
    
    def G(self):
        """
        Implementujte gramatické pravidlo:
        <G> → <H> ["^" <G>]
        """

    
    def H(self):
        """
        Implementuje gramatické pravidlo:
        <H> → number | "(" <E> ")"
        
        Spracuje základné prvky výrazu - buď číslo alebo výraz v zátvorke.
        Najvyššia priorita v gramatike.
        """
        token = self.current_token
        
        if token.type == TokenType.NUMBER:
            # Jednoducho vrátime hodnotu čísla
            self.eat(TokenType.NUMBER)  # Overíme a posunieme sa za číslo
            return token.value
            
        elif token.type == TokenType.LPAREN:
            # Vyhodnotíme výraz v zátvorkách
            self.eat(TokenType.LPAREN)  # Overíme a posunieme sa za '('
            result = self.E()        # Rekurzívne vyhodnotíme výraz medzi zátvorkami
            self.eat(TokenType.RPAREN)  # Overíme a posunieme sa za ')'
            return result
            
        else:
            # Ak nie je ani číslo ani zátvorka, ide o chybu
            raise SyntaxError(f"Syntaktická chyba: Neočakávaný token {token}")
    
    def parse(self):
        """
        Začne syntaktickú analýzu a vráti výsledok výrazu.
        Vstupný bod pre parser.
        """
        return self.E()  # Začíname najvrchnejším pravidlom gramatiky
        



```
  
</div>


**Hlavná trieda kalkulačky** <br>
Nakoniec vytvoríme hlavnú triedu pre našu kalkulačku a kód máme hotový. <br>

<div>

```python

# Hlavná trieda kalkulačky, ktorá spája lexer a parser
class Calculator:
    def evaluate(self, expression):
        """
        Vyhodnotí aritmetický výraz a vráti výsledok.
        
        Args:
            expression (str): Reťazec obsahujúci aritmetický výraz
            
        Returns:
            int: Výsledok výrazu, alebo chybovú správu
        """
        try:
            lexer = Lexer(expression)   # Vytvoríme lexikálny analyzátor pre daný výraz
            parser = Parser(lexer)      # Vytvoríme syntaktický analyzátor
            result = parser.parse()     # Vyhodnotíme výraz podľa gramatiky
            return result
        except Exception as e:
            return f"Chyba: {str(e)}"   # Vrátenie chyby

```
  
</div>


**Demonštrácia funkcionality** <br>
Ukážme si, ako naša kalkulačka spracuje niekoľko výrazov. <br>

<div>

```python

def test_calculator():
    calc = Calculator()
    
    # Základné operácie
    print("2 + 3 =", calc.evaluate("2 + 3"))                 # Očakávaný výsledok: 5
    print("5 - 3 =", calc.evaluate("5 - 3"))                 # Očakávaný výsledok: 2
    print("2 * 3 =", calc.evaluate("2 * 3"))                 # Očakávaný výsledok: 6
    print("2 ^ 3 =", calc.evaluate("2 ^ 3"))                 # Očakávaný výsledok: 8
    
    # Priorita operátorov
    print("2 + 3 * 4 =", calc.evaluate("2 + 3 * 4"))         # Očakávaný výsledok: 14 (nie 20)
    print("(2 + 3) * 4 =", calc.evaluate("(2 + 3) * 4"))     # Očakávaný výsledok: 20
    print("2 * 3 ^ 2 =", calc.evaluate("2 * 3 ^ 2"))         # Očakávaný výsledok: 18 (nie 36)
    
    # Asociatívnosť
    print("5 - 3 - 1 =", calc.evaluate("5 - 3 - 1"))         # Očakávaný výsledok: 1 (ľavá asociatívnosť)
    print("2 ^ 2 ^ 3 =", calc.evaluate("2 ^ 2 ^ 3"))         # Očakávaný výsledok: 256 (pravá asociatívnosť)
    
    # Komplexný výraz
    print("2 * (3 + 4) ^ 2 - 5 =", calc.evaluate("2 * (3 + 4) ^ 2 - 5"))  # Očakávaný výsledok: 93


if __name__ == "__main__":
    test_calculator()

```
  
</div>

<!---

Vieme aj spraviť úlohy aby mali odpovede zamknuté za heslom.


<details>
  <summary>Zobraziť riešenie</summary>
  <p><strong>Odpoveď:</strong></p>
  <div id="solution" style="display:none;">


      ```python

      def test_calculator():
          calc = Calculator()
          
          # Základné operácie
          print("2 + 3 =", calc.evaluate("2 + 3"))                 # Očakávaný výsledok: 5
          print("5 - 3 =", calc.evaluate("5 - 3"))                 # Očakávaný výsledok: 2
          print("2 * 3 =", calc.evaluate("2 * 3"))                 # Očakávaný výsledok: 6
          print("2 ^ 3 =", calc.evaluate("2 ^ 3"))                 # Očakávaný výsledok: 8
          
          # Priorita operátorov
          print("2 + 3 * 4 =", calc.evaluate("2 + 3 * 4"))         # Očakávaný výsledok: 14 (nie 20)
          print("(2 + 3) * 4 =", calc.evaluate("(2 + 3) * 4"))     # Očakávaný výsledok: 20
          print("2 * 3 ^ 2 =", calc.evaluate("2 * 3 ^ 2"))         # Očakávaný výsledok: 18 (nie 36)
          
          # Asociatívnosť
          print("5 - 3 - 1 =", calc.evaluate("5 - 3 - 1"))         # Očakávaný výsledok: 1 (ľavá asociatívnosť)
          print("2 ^ 2 ^ 3 =", calc.evaluate("2 ^ 2 ^ 3"))         # Očakávaný výsledok: 256 (pravá asociatívnosť)
          
          # Komplexný výraz
          print("2 * (3 + 4) ^ 2 - 5 =", calc.evaluate("2 * (3 + 4) ^ 2 - 5"))  # Očakávaný výsledok: 93


      if __name__ == "__main__":
          test_calculator()

      ```
        


  </div>
  <input type="password" id="password" placeholder="Zadajte heslo">
  <button onclick="checkPassword()">Odomknúť</button>
</details>

<script>
function checkPassword() {
  var password = document.getElementById("password").value;
  if (password === "tajneheslo") {
    document.getElementById("solution").style.display = "block";
  } else {
    alert("Nesprávne heslo!");
  }
}
</script>


--->

## Domáce úlohy

> Úloha:
> Upravte kód tak aby akceptoval celé čísla.


> Úloha:
> Pridajte do gramatiky našej kalkulačky unárne mínus.

> Úloha:
> Upravte kód tak aby akceptoval unárne mínus.



## Dotazník na ohodnotenie učiva
Vážení študenti, <br>
poprosil by som Vás o vyplnenie tohto [dotazníka](https://forms.gle/RknDHVT2TBrmeomM8) .   <br>

Tento dotazník slúži na ohodnotenie vašich skúseností s pripravenými materiálmi z šiesteho cvičenia. Na vylepšovaní učiva sa aktívne pracuje a Vaše odpovede nám pomôžu zlepšiť kvalitu výučby. <br>

Ďakujem<br>