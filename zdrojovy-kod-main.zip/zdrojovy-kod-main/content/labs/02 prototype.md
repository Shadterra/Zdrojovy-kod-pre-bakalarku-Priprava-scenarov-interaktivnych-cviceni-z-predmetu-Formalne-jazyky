---
Nadpis: Konečno-stavové akceptory DKA.
---

## Ciele

  1. {ciel_zopakova_reg_vyraz} Zopakovať regulárne výrazy.
  2. {ciel_zakladne_definicie} Oboznámiť sa zo základnymi definíciami pre deterministický konečno-stavový automat (DKA).
  3. {ciel_zostavenie_DKA} Zostaviť DKA z regulárneho výrazu.
  4. {ciel_implementacia_ksaa} Implementovať DKA pre akceptáciu slov vybraného regulárneho jazyka.

## Úvod

Na začiatku dnešného cvičenia si zopakujeme regulárne výrazy. Hlavným cieľom bude oboznámenie sa s deterministickým konečno-stavovým automatom a základnými pojmami. Ukážeme si  prechodové tabuľky a stavové diagrami, aby sme lepšie pochopili, ako tieto automaty pracujú. Následne sa zameriame na to, ako zostaviť DKA z daného regulárneho výrazu. A na záver
si ukážeme pseudokód na zostavenie DKA.


## Krok {ciel_zopakova_reg_vyraz}

Zopakujte si [teóriu regulárnych výrazov](resources/regularne_vyrazy.pdf). Už viete, že regulárne výrazy je možné zobraziť aj graficky pomocou **prechodových diagramov**. Princíp zostrojenia takýchto diagramov bol vysvetlený v predošlom cvičení.  Ale ukážeme si zostavenie regulárneho výrazu s ktorým budeme na tomto cvičení pracovať.

> Príklad:
> Skonštruujte regulárny výraz a jemu zodpovedajúci prechodový diagram pre reťazce nad abecedou A = {a, b, c}, ktoré spĺňajú nasledujúce podmienky:
>
> * Reťazec je buď zložený z ľubovoľného (aj prázdneho) počtu znakov b,
> * alebo začína sekvenciou ba a po nej nasleduje voliteľný podreťazec, ktorý môže byť:
> * - buď samotný znak c,
> * - alebo znak a, za ktorým môže nasledovať ľubovoľný počet znakov c.
>
> Odpoveď je: *{b}|(ba)[c|a{c}]*
>
>![Zostavenie prechodového diagramu pre regulárny výraz *{b}|(ba)[c|a{c}]*](resources/cv2/regular-vyraz-slow.gif)

## Krok {ciel_zakladne_definicie}

Pri konštrukcii niektorých súčastí prekladačov sa využíva takzvaný **akceptačný spôsob** špecifikácie jazyka, to znamená špecifikácia jazykov pomocou automatu.  <br>

Automat neformálne môžeme popísať ako zariadenie, ktoré dostáva na vstup reťazce zložené z terminálnych symbolov. 
Zariadenie daný vstupný reťazec spracuje a po konečnom čase (počte operácií) oznámi, či tento reťazec patrí do jazyka alebo nie (hovoríme, že automat slovo akceptuje resp. neakceptuje). <br>

Začneme vysvetlením najjednoduchšieho zariadenia tohto typu - Deterministický konečno-stavový automat (DKA). <br>

**Deterministický konečno-stavový automat (DKA)** je usporiadaná pätica 
$$ M = (Q, T, \delta, q_0, F), $$
kde:
* $ Q $ je konečná množina stavov automatu.
* $ T $ je konečná množina prípustných vstupných symbolov (alebo vstupná abeceda) automatu.
* $ \delta $ (delta) je prechodová funkcia automatu, $ \delta: Q \times \Sigma \to Q $.
* $ q_0 $ je začiatočný stav automatu, $ q_0 \in Q $.
* $ F $ je množina akceptujúcich (alebo koncových) stavov automatu $ F \subseteq Q $.
<br>
<br>


<div style="text-align: center;">
    <figure>
        <img src="resources/cv2/schema-konecneho-automatu.png" alt="Schéma konečného automatu" width="30%">
        <figcaption><strong>Obr. 1:</strong> Schéma konečného automatu</figcaption>
    </figure>
</div>

<!--- nasledujúce vysvetlenie by som nechal alebo v prípade vložil do tlačítka ktore rozbalí tento text
  <details>
  <summary>Zobraziť vysvetlenie schémy konečného automatu </summary>

  kopirovaný text

  </details>
--->

Schému konečného automatu môžeme vidieť na Obr. 1. Môžeme si predstaviť, že konečný automat je zariadenie, ktoré sa skladá zo vstupnej pásky a konečnostavovej riadiacej jednotky. <br>
Na vstupnej páske je zapísané slovo, o ktorom máme rozhodnúť, či patrí do jazyka. Slovo sa musí skladať zo symbolov z množiny T. <br> 
Konečnostavová riadiaca jednotka sa vždy nachádza v jednom z množiny stavov Q a vidí jeden aktuálny vstupný symbol na páske. <br> 
Konečný automat pracuje diskrétne po jednotlivých krokoch. V každom kroku prečíta aktuálny symbol zo vstupnej pásky, presunie čítaciu hlavu na nasledujúci symbol a prejde do nového stavu. <br> 
Nový stav sa určí na základe pôvodného stavu a prečítaného vstupného symbolu a formálne túto činnosť popisuje prechodová funkcia $\delta$. <br>
Na začiatku výpočtu je čítacia hlava nastavená na prvý symbol slova a konečnostavová riadiaca jednotka sa nachádza v stave $q_o$. <br> 
Výpočet sa skončí, keď sa spracuje celé vstupné slovo. Automat slovo akceptuje, ak sa mu podarí spracovať celé vstupné slovo, pričom skončí v akceptujúcom stave (tzn. v niektorom stave z množiny F). <br>
Uvedené skutočnosti sformalizujeme následovne.

<br>

Nech $ M = (Q, T, \delta, q_0, F), $ je konečný automat. Potom:
* **Konfigurácia konečného automatu** M je $ (q, w) \in Q \times T^* $ kde $q$ je momentálny stav automatu M a $w$ je ešte nespracovaná časť vstupu.
* **Začiatočná konfigurácia automatu** M je konfigurácia $ (q_0, w) $, kde $w$ je celý vstupný reťazec.
* **Koncová (alebo akceptujúca) konfigurácia automatu** M je konfigurácia $ (q, \epsilon) $ kde $ q \in F $.

<br>

Nech $ M = (Q, T, \delta, q_0, F), $ je deterministický konečný automat. 
* Potom nad množinou jeho konfigurácií $Q \times T^* $ definujeme **reláciu prechodu** (alebo **krok výpočtu**) **$ DKA \vdash $**  následovne:
$$
\text{Nech } \quad q, p \in Q, \quad w \in T^*, \quad a \in T.
$$
$$
\text{Potom }\quad (q, aw) \vdash (p, w) \quad \text{práve vtedy, keď} \quad \delta(q, a) = p.
$$

<br>

Nech $ M = (Q, T, \delta, q_0, F), $ je konečný automat.  
* Potom postupnosť konfigurácií $ (q_0, w_0), (q_1, w_1), \dots, (q_k, w_k) $ takých, že
$$
(q_0, w_0) \vdash (q_1, w_1) \vdash \dots \vdash (q_k, w_k),
$$
$ q_i \in Q, \ w_i \in T^*, \ i = 0,1, \dots, k, $ sa nazýva **výpočet konečného automatu** M z $ (q_0, w_0) \to (q_k, w_k) $ a vyjadrovať ho budeme v tvare 
$$
(q_0, w_0) \vdash^k (q_k, w_k).
$$
> Poznámka:
> Číslo $k$ predstavuje počet krokov výpočtu.

<br>

Nech $ M = (Q, T, \delta, q_0, F), $ je  konečný automat.  Potom: 
* **tranzitívnym uzáverom relácie** krok výpočtu nazývame reláciu $ \vdash^+ $ <br> 
definovanú na množine jeho konfigurácii následovne: <br>
$ (q,w) \vdash^+ (p,x) $ práve vtedy, keď existuje $ n \geq 1$ také, že $(q,w) \vdash^n (p,x) $.

* **reflexívnym a tranzitívnym uzáverom relácie** krok výpočtu nazývame reláciu $ \vdash^* $ <br> 
definovanú na množine jeho konfigurácii následovne: <br>
$ (q,w) \vdash^*+* (p,x) $ práve vtedy, keď existuje $ n \geq 0$ také, že $(q,w) \vdash^n (p,x) $.
<br>
* pričom v obidvoch prípadoch platí $ p, q \in Q, \quad$ a taktiež $w, x \in T^* .$

<br>

Nech $ M = (Q, T, \delta, q_0, F), $ je  konečný automat.
* Potom hovoríme, že stav $q \in Q$ je **dosiahnuteľný** ak existuje výpočet <br>
$(q_0, w) \vdash^n (q, \lambda)$ pre nejaké $ n \geq 0, w \in T^* .$

* Ak taký výpočet neexistuje, stav q je **nedosiahnuteľný**.

<br>

Nech $ M = (Q, T, \delta, q_0, F), $ je  konečný automat.
* Potom jazyk $L(M)$ **rozpoznávaný (prijímaný, špecifikovaný, akceptovaný) konečným automatom** M je množina:
$$
L(M) = \{ w \mid (q_0, w) \vdash^* (q, \epsilon), w \in T^*, q \in F \} 
$$





## Krok {ciel_zostavenie_DKA}

Konečno-stavové automaty sa bežne v teórii informatiky vytvárajú prostredníctvom vytvárania prechodových tabuliek (ako je tomu v [zbierke](resources/ti_priklady.pdf) v kapitole 3.2). Takto vytvorené automaty sú **nedeterministické**. Nedeterministické automaty sú také, kde pri niektorom vstupe *x* je definovaná prechodová funkcia nie do jediného možného stavu *y*, ale do množiny možných stavov {*y1*, *y2*, ...*yn*}. O nedeterministických automatoch si povieme viac v nasledujúcom cvičení.

Na vytvorenie deterministického automatu sa využíva metóda nazývaná **determinizácia**.

Na tomto predmete sa však využíva iná metóda, **vytváranie prechodových grafov** , ktorá je uvedená v animovanej [prezentácii](resources/ksa.ppsx). Táto metóda má tú výhodu, že pomocou nej je možné vytvoriť priamo deterministický konečno-stavový automat a **nie je potrebná ďalšia determinizácia**. Je ju však možné použiť _len vtedy_, ak množinu vstupných reťazcov pre KSA je možné definovať prostredníctvom _regulárnych výrazov_.

> Poznámka:
> Symbolom ⊥ označujeme nedefinovanú hodnotu.

> Príklad:
> Nájdite DKA, ktorý reprezentuje regulárny výraz *{b}|(ba)[c|a{c}]* .
>
> Postupovať budeme nasledujúcim spôsobom.
>
> 1. Pre daný regulárny výraz nakreslíme prechodový diagram:
> ![Prechodový diagram pre regulárny výraz *{b}|(ba)[c|a{c}]*](resources/cv2/complex-regex.png)
>
> 2. Určíme počiatočný stav *q0* umiestnením tokenov (Poznámka: tokeny fungujú na "označenie miesta kám sa na diagrame vieme dostať"):
> Stav $\{\textcolor{red}{.}b\} | (\textcolor{red}{.}ba)[c | a\{c\}]\textcolor{red}{.}$
> ![Počiatočný stav *q0*](resources/cv2/complex-regex-s0.png)
>
> 3. Vygenerujeme jednotlivé stavy pomocou prechodovej funkcie *δ*:
>
> * *δ(q0, a) =* ⊥ 
> * *δ(q0, b) =* $\{\textcolor{red}{.}b\} | (b\textcolor{red}{.}a)[c | a\{c\}]\textcolor{red}{.}$ = *q1*, dostávame stav *q1*  - Koncový stav
> * *δ(q0, c) =* ⊥
>
> ![Zmena stavu na *q1*](resources/cv2/complex-regex-s1.png)
>
> 4. Pokračujeme v generovaní jednotlivych stavou pomocou prechodovej funkcie *δ* pre každý nájdený stav až do bodu kedy sa nám už nebudú zobrazovať dalšie stavy:
> 
> * *δ(q1, a) =* $\{b\} | (ba)[\textcolor{red}{.}c | \textcolor{red}{.}a\{c\}]\textcolor{red}{.}$ = *q2* - Koncový stav
> * *δ(q1, b) =* $\{\textcolor{red}{.}b\} | (ba)[c | a\{c\}]\textcolor{red}{.}$ = *q3* - Koncový stav
> * *δ(q1, c) =* ⊥
>
> * Našli sme až 2 rôzne stavy q2 a q3.
>
> ![Zmena stavu na *q2*](resources/cv2/complex-regex-s2.png)
>
> 
> * *δ(q2, a) =* $\{b\} | (ba)[c | a\{\textcolor{red}{.}c\}]\textcolor{red}{.}$ = *q4* - Koncový stav
> * *δ(q2, b) =* ⊥
> * *δ(q2, c) =* $\{b\} | (ba)[c | a\{c\}]\textcolor{red}{.}$ = *q5* - Koncový stav
>
> ![Zmena stavu na *q3*](resources/cv2/complex-regex-s3.png)
>
> 
> * *δ(q3, a) =* ⊥
> * *δ(q3, b) =* q3  (dostaneme rovnaký stav aký už bol definovaný)
> * *δ(q3, c) =* ⊥
>
> ![Zmena stavu na *q4*](resources/cv2/complex-regex-s4.png)
>
> 
> * *δ(q4, a) =* ⊥
> * *δ(q4, b) =* ⊥
> * *δ(q4, c) =* q4
>
> ![Zmena stavu na *q5*](resources/cv2/complex-regex-s5.png)
>
> 
> * *δ(q4, (a,b,c)) =* ⊥
>
>

> Poznámka:
> Bodkou na konci označujeme **koncový stav** čo znamená, že v tomto stave vieme ukončiť prechod. 

>
> 5. Zostavíme tabuľku pre prechodovú funkciu a následne doplníme stavy, ktoré môžu jednotlivé stavy nadobúdať:
>
>**stav**|**a**|**b**|**c**
>-----|-----|-----|-----
>*q0*|
>*q1*|
>*q2*|
>*q3*|
>*q4*|
>*q5*|
>
>
>
>**stav**|**a**|**b**|**c**
>-----|-----|-----|-----
>*q0*|⊥|*q1*|⊥
>*q1*|*q2*|*q3*|⊥
>*q2*|*q4*|⊥|*q5*
>*q3*|⊥|*q3*|⊥
>*q4*|⊥|⊥|*q4*
>*q5*|⊥|⊥|⊥
>
> 6. Z prechodovej tabuľky nakreslíme DKA. Začnemé nakreslením stavu *q0* a jeho stavu *q1*, ktorý *q0* vie nadobúdať pomocou *b**. 
> ![DKA pre regulárny výraz stav *q0*](resources/cv2/complexDKA-0.png)
>    Zo stavu *q1* a je možné nadobudnúť stav *q2* pomocou *a* a stav *q3* pomocou *b*.
> ![DKA pre regulárny výraz stav *q1*](resources/cv2/complexDKA-1.png)
>    Zo stavu *q2* a je možné nadobudnúť stav *q4* pomocou *a* a stav *q5* pomocou *c*.
> ![DKA pre regulárny výraz stav *q2*](resources/cv2/complexDKA-2.png)
>    Zo stavu *q3* a je možné nadobudnúť stav *q3* pomocou *b* a to znamená, že stav je cyklický.
> ![DKA pre regulárny výraz stav *q3*](resources/cv2/complexDKA-3.png)
>    Zo stavu *q4* a je možné nadobudnúť stav *q4* pomocou *c* a to znamená, že stav je cyklický.
> ![DKA pre regulárny výraz stav *q4*](resources/cv2/complexDKA-4.png)
> 7. Stav *q5* už nenadobúda další stav a tým pádom sme nakreslili celý deterministický konečno-stavový automat (DKA) pre regulárny výraz *{b}|(ba)[c|a{c}]*. 
> ![DKA pre regulárny výraz *{b}|(ba)[c|a{c}]*](resources/cv2/complexDKA.png)

> Poznámka:
> Pri kreslení DKA označujeme **koncový stav**, tak že stav ešte raz zaokrúhlime.
> ![Nekoncový a koncový stav](resources/cv2/poznamka-koncovy-stav.png)


<br>
<br>

Precvičte si vytváranie deterministického konečno-stavového akceptora na základe zadaného regulárneho výrazu s využitím metódy vytvárania prechodových grafov z predošlého kroku na nasledujúcich príkladoch:

> Úloha:
> Vytvorte prechodový diagram regulárneho výrazu a prechodový graf. Následne vytvorený prechodový graf prekreslite na DKA.
>
> Regulárny výraz:
>  
> ```
> a[a]{b}b
> ```

> Úloha:
> Vytvorte prechodový diagram regulárneho výrazu a prechodový graf. Následne vytvorený prechodový graf prekreslite na DKA.
> 
> Regulárny výraz:
>  
> ```
> [c]{ab}c
> ```

> Úloha:
> Vytvorte prechodový diagram regulárneho výrazu a prechodový graf. Následne vytvorený prechodový graf prekreslite na DKA.
> 
> Regulárny výraz:
>  
> ```
> {b}[c]ba
> ```

> Úloha:
> Vytvorte prechodový diagram regulárneho výrazu a prechodový graf. Následne vytvorený prechodový graf prekreslite na DKA.
>
> Regulárny výraz:
>  
> ```
> a{ab}a[ab]b
> ```

## Krok {ciel_implementacia_ksa}

V predošlych krokov tohto cvičenia sme sa naučili, ako priamo vytvoriť z regulárneho výrazu DKA. V tomto kroku sa oboznámime s praktickou implementáciou daného DKA v jazyku Python.

Ukážeme si kód pre zostrojenie DKA regulárneho výrazu {b}|(ba)[c|a{c}] a následne otestujeme akceptáciu slov.

<div>

```python

# Definícia stavov:

# Definícia stavov:
# q0: Počiatočný stav. Máme dve možnosti: - 
#     - Akceptuje prázdny reťazec a končí.
#     - Akceptuje iba znak 'b' a prechádza do q1 
# q1: Po prečítaní prvého 'b' máme tri možnosti:
#     - Reťazec končí.
#     - Akceptuje 'a' a prechádza do q2 - Potenciálny začiatok vetvy (ba)[c|a{c}] 
#     - Akceptuje 'b' a prechádza do q3 - Vetva {b} (samotný reťazec pozostávajúci iba z 'b')
# q2: Po prečítaní 'ba' máme tri možnosti: 
#     - Reťazec končí.
#     - Akceptuje 'c' a prechádza do q5
#     - Akceptuje 'a' a prechádza do q4
# q3: Po prečítaní 'bb' máme dve možnosti: 
#     - Reťazec končí
#     - Akceptuje 'b' a prechádza do q3 - Cyklí v sebe samom
# q4: Po prečítaní "ba" + 'a' máme dve možnosti: 
#     - Reťazec končí
#     - Akceptuje 'c' a prechádza do q4 - Cyklí v sebe samom
# q5: Finálny stav. Po prijatí "bac" a dostaním sa do q5 už ďalej nepokračuje.

def match_regex(input_str, state, index):
    # Ak sme spracovali celý vstup a sme v akceptujúcom stave, vypíšeme true.
    if index == len(input_str):
        if state in ['q0','q1', 'q2', 'q3', 'q4', 'q5']:
            return True
        else:
            return False

    current_char = input_str[index]
    next_index = index + 1

    # Zoznam možných prechodov zo súčasného stavu na základe aktuálneho znaku
    transitions = []

    if state == 'q0':
        if current_char == 'b':
            # Po prečítaní b prejdeme do stavu q1
            transitions.append('q1')
        else:
            return False

    elif state == 'q1':
        # q1 očakáva 'b' pre {b} alebo 'a' pre dokončenie prefixu "ba"
        if current_char == 'b':
            transitions.append('q3')
        elif current_char == 'a':
            transitions.append('q2')
        else:
            return False

    elif state == 'q2':
        # Po "ba" je voliteľná skupina [c|a]
        if current_char == 'c':
            transitions.append('q5')
        elif current_char == 'a':
            transitions.append('q4')
        else:
            return False

    elif state == 'q3':
        # q3 môže prijímať len 'b'
        if current_char == 'b':
            transitions.append('q3')
        else:
            return False

    elif state == 'q4':
        # q4: po "ba" + 'a', môžeme prijímať len 'c' 
        if current_char == 'c':
            transitions.append('q4')  # zostávame v q4, pretože môžeme opakovane čítať 'c'
        else:
            return False

    elif state == 'q5':
        # q5 je finálny stav ktorý už dalej nepokračuje
            return False
            
    # Rekurzívne prejdeme všetkými možnými prechodmi
    for next_state in transitions:
        if match_regex(input_str, next_state, next_index):
            return True

    return False

def match(input_str):
    # Začíname v počiatočnom stave q0 a indexe 0.
    return match_regex(input_str, 'q0', 0)

# Príklady použitia:
print(match(""))         # Akceptované
print(match("  "))       # Neakceptované
print(match("ab"))       # Neakceptované 
print(match("bbb"))      # Akceptované 
print(match("ba"))       # Akceptované 
print(match("bac"))      # Akceptované 
print(match("baaccc"))   # Akceptované 
print(match("bab"))      # Neakceptované


```
  
</div>



> Úloha:
> Podľa pokynov vyučujúceho samostatne implementuje DKA pre určený regulárny výraz binárnych numerálov. Zohľadnite skutočnosť, že na vstupe môže byť ľubovoľný reťazec. Váš program by mal vedieť nájsť binárne numerály v zadanom reťazci. Prediskutujte realizované riešenie.
>


> Úloha:
> Podľa pokynov vyučujúceho samostatne implementuje DKA pre určený regulárny výraz z predošlého kroku. Prediskutujte realizované riešenie.
>



## Doplňujúce úlohy

> Úloha:
> Prejdite si príklady na vytváranie regulárnych výrazov v [zbierke](resources/ti_priklady.pdf) od č. 1.13

> Úloha:
> Samostatne vyriešte príklady na vytváranie DKA v [zbierke](resources/ti_priklady.pdf) od č. 3.1 \- precvičte si ich pomocou metódy vytvárania prechodových diagramov.

> Úloha:
> Precvičiť znalosti regulárnych výrazov (v ich bežnejšom zápise) môžete aj pomocou [krížoviek](http://regexcrossword.com/). Skúste si niektoré regulárne výrazy z krížoviek prepísať do zápisu používaného na tomto cvičení.
>
>> Vyučujúci:
> Návrh: toto je možné prideliť študentom ako domácu úlohu a kto to celé vylúšti, dostane body naviac - napríklad pri nerozhodnom výsledku pri zadaní (alebo iné výhody). Upozorniť ich však, nech to medzi sebou vo vlastnom záujme nezdieľajú, lebo ak ich bude veľa, tak nedostane body nikto :-) Vyskušané, zabralo :D


## Dotazník na ohodnotenie učiva
Vážení študenti, <br>
poprosil by som Vás o vyplnenie tohto [dotazníka](https://forms.gle/c6mGwiZGjkdsQpr38) .   <br>

Tento dotazník slúži na ohodnotenie vašich skúseností s pripravenými materiálmi z druhého cvičenia. Na vylepšovaní učiva sa aktívne pracuje a Vaše odpovede nám pomôžu zlepšiť kvalitu výučby. <br>

Ďakujem<br>