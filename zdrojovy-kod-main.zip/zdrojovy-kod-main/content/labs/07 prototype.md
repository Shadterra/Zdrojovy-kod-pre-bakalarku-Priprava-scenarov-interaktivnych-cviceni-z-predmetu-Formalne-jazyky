---
Nadpis: Tranformacie bezkontextovych gramatik.
---

## Ciele

1. {ciel_zakladne_transformacie} Oboznámiť sa s transformáciami bezkontextových gramatík.
2. {ciel_chomsky} Oboznámiť sa s Chomského normálnym tvarom a naučiť sa transformovať gramatiku do tohto tvaru.
3. {ciel_syntakticky_analyzator} Implementácia rekurzívného syntaktického analyzátora.
4. {ciel_ulohy} Precvičiť si transformáciu bezkontextových gramatík.

## Úvod

Transformácia gramatiky predstavuje postup, pomocou ktorého získame z danej gramatiky ekvivalentnú gramatiku (t.j. generujúcu rovnaký jazyk), ktorá navyše spĺňa určité dodatočné požiadavky.

## Krok {ciel_zakladne_transformacie}
V praxi je možné sa stretnúť s gramatikami, ktoré obsahujú rôzne "nedokonalosti" alebo prvky, ktoré komplikujú ich spracovanie a nie je možné zostrojiť ich syntaktický analyzátor. Transformácie gramatík nám umožňujú tieto nedokonalosti odstrániť a previesť gramatiku do štandardizovanej ekvivalentnej formy, ktorá je vhodnejšia pre praktické použitie a dovoľuje zostrojenie syntaktického analyzátora. <br>

Medzi základné transformácie bezkontextových gramatík patria:<br>
* **Odstránenie nadbytočných symbolov gramatiky** 
* **Odstránenie ε-pravidiel** 
* **Odstránenie jednoduchých pravidiel  a cyklov** 
* **Odstránenie ľavej rekurzie**

---

# Odstránenie nadbytočných symbolov gramatiky

**Nedostupný symbol** je taký symbol X (terminál alebo neterminál) v gramatike, ktorý sa neobjavuje v žiadnej vetnej forme. Teda neexistuje derivácia $ S \Rightarrow^* u X v $, kde $S$ je počiatočný neterminál a $ u, v \in (N \cup T)^* $.

**Nadbytočný symbol** je taký symbol X (terminál alebo neterminál) v gramatike, ktorý je nedostupný alebo ktorého výskyt v rámci vetnej formy spôsobí, že žiadnou deriváciou nie je možné túto vetnú formu premeniť na vetu. Teda neexistuje derivácia $ S \Rightarrow^* xXz \Rightarrow^* uwv $, kde $S$ je počiatočný neterminál a $ u,v,w \in T^* $.

> Poznámka:
> Každý nedostupný symbol je nadbytočný. Obrátené tvrdenie neplatí. Teda nie každý nadbytočný symbol je nedostupný.


**Redukovaná bezkontextová gramatika** je bezkontextová gramatika bez nadbytočných symbolov.

**Vlastná bezkontextová gramatika** je bez cyklu, bez ε-pravidiel a bez nadbytočných symbolov.

# Ako z bezkontextovej gramatiky odstránime nadbytočné symboly?
<br>

1) Iteratívne skonštruujeme množinu „ukončiteľných" neterminálov $N_t$ (t.j. neterminálov, ktoré generujú nejaký reťazec): <br>

    > a) Inicializácia: $N_t^0 = \{A\}$.

    > b) Prvý krok:  $N_t^1 = N_t^0 \cup$ {všetky neterminály, ktoré priamo generujú(majú na pravej strane) reťazce terminálnych symbolov alebo ε }.

    > c) Druhý krok:  $N_t^2 = N_t^1 \cup${všetky neterminály, ktoré priamo generujú(majú na pravej strane) reťazce terminálnych symbolov v kombinácii s neterminálmi z predchádzajúcej množiny $ N_t^1$}.

    > d) ...

    > e) i-tý krok: $N_t^i = N_t^i-1 \cup${ všetky neterminály, ktoré priamo generujú(majú na pravej strane) reťazce terminálnych symbolov v kombinácii s neterminálmi z predchádzajúcej množiny $ N_t^i-1$}.

    > f) ...

    > g) Množina $N_t$ je hotová, pokiaľ ďalší krok už do množiny nepridá žiadny nový neterminál.

<br>

2. Všetky neterminály, ktoré nie sú v množine $N_t$ z gramatiky odstránime.


3. Iteratívne skonštruujeme množinu dostupných symbolov $V$ (možno vykonať až po ukončení predchádzajúcich krokov):

    > a) Inicializácia: $V^0 = \{S\}$ (S je počiatočný neterminálny symbol).

    > b) Prvý krok: $V^1 = V^0 \cup$ {všetky terminály a neterminály vyskytujúce sa na pravej strane pravidiel pre neterminál S}.

    > c) Druhý krok: $V^2 = V^1 \cup$ {všetky terminály a neterminály vyskytujúce sa na pravej strane pravidiel pre neterminály z predchádzajúcej množiny $V^1$}.

    > d) ...

    > e) i-tý krok: $V^i = V^i-1 \cup${všetky terminály a neterminály vyskytujúce sa na pravej strane pravidiel pre neterminály z predchádzajúcej množiny $V^i-1$}.

    > f) ...

    > g) Množina $V$ je hotová, pokiaľ ďalší krok už do množiny nepridá žiadny nový (ne)terminál.

<br>

4. Všetky neterminály a terminály, ktoré nie sú v množine $V$ z gramatiky odstránime.

<br>

> Príklad:
> Majme bezkontextovú gramatiku G. Transformujte gramatiku G na bezkontextovú gramatiku G', ktorá nebude obsahovať nadbytočné symboly a L(G) = L(G'). <br>
>
> G = ({S, A, B, C, D}, {a, b, c}, P, S), kde <br>
> P = { <br>
>    S → AB | C,  <br>
>    A → aA | a,  <br>
>    B → bB,  <br>
>    C → c,  <br>
>    D → bc} <br>
>
> Riešenie: <br>
> $N_t^0$ = {} <br>
> $N_t^1$ = {A, C, D} (pretože A, C a D generujú terminálne reťazce A→a, C→c a D→bc )<br>
> $N_t^2$ = {S, A, C, D} (pretože S má pravidlo S→C, kde C je už v $N_t^1$) <br>
> $N_t^3$ = {S, A, C, D} = $N_t^2$ (žiadny nový neterminál sa nepridal) <br>
>
> Vidíme, že $B \not\in N_t$. Neterminál B je nadbytočný a z gramatiky ho odstránime. Gramatika G' tak bude po prvej fáze vyzerať nasledovne: <br>
>
> G' = ({S, A, C, D}, {a, b, c}, P, S), kde <br>
> P = { <br>
>    S → C, (odstránili sme S → AB, pretože obsahuje B) <br>
>    A → aA | a,  <br>
>    C → c,  <br>
>    D → bc} <br>
>
> Riešenie: <br>
> $V^0$ = {S} <br>
> $V^1$ = {S, C} (S má pravidlo S → C, takže pridávame C) <br>
> $V^2$ = {S, C, c} (C má pravidlo C → c, takže pridávame c)<br>
> $V^3$ = {S, C, c} = $V^2$ (žiadne nové symboly už nemáme) <br>
>
> Vidíme, že A, D, a, b ∉ $V$. Tieto symboly sú nadbytočné a z gramatiky ich môžeme odstrániť. Výsledná gramatika G' bez nadbytočných symbolov bude vyzerať nasledovne: <br>
>
> G' = ({S, C}, {c}, {S → C, C → c}, S).


---

# Odstránenie ε-pravidiel

**ε-pravidlo** je pravidlo tvaru $A \rightarrow \varepsilon$, kde $A$ je ľubovoľný neterminál. Intuitívne nám toto pravidlo hovorí, že daný neterminál môže v priebehu derivácie kedykoľvek zmiznúť.

**Bezkontextová gramatika bez ε-pravidiel** je taká bezkontextová gramatika, kde:
* neexistuje žiadne ε-pravidlo, alebo
* existuje iba jediné: $S \rightarrow \varepsilon$, kde $S$ je počiatočný neterminál a $S$ sa nevyskytuje na pravej strane žiadneho z pravidiel gramatiky.

# Ako z bezkontextovej gramatiky odstránime ε-pravidlá?

1. Iteratívne zostavíme množinu $N_\varepsilon$ obsahujúcu všetky neterminály, ktoré možno priamo či nepriamo prepísať na prázdny reťazec:

   a) Inicializácia: $N_\varepsilon^0 = \{\}$.
   
   b) Prvý krok: $N_\varepsilon^1 = N_\varepsilon^0 \cup \{$ všetky neterminály, ktoré majú v gramatike ε-pravidlo $\}$.
   
   c) Druhý krok: $N_\varepsilon^2 = N_\varepsilon^1 \cup \{$ všetky neterminály, ktoré majú na pravej strane aspoň jedného z pravidiel ľubovoľnú kombináciu neterminálov z predchádzajúcej množiny $N_\varepsilon^1$ (pozor, bez terminálnych symbolov a neterminálov, ktoré nie sú v množine $N_\varepsilon^1$) $\}$.
   
   d) ...
   
   e) $i$-tý krok: $N_\varepsilon^i = N_\varepsilon^{i-1} \cup \{$ všetky neterminály, ktoré majú na pravej strane aspoň jedného z pravidiel ľubovoľnú kombináciu neterminálov z predchádzajúcej množiny $N_\varepsilon^{i-1}$ (pozor, bez terminálnych symbolov a neterminálov, ktoré nie sú v množine $N_\varepsilon^{i-1}$) $\}$.
   
   f) ...
   
   g) Množina $N_\varepsilon$ je hotová, ak ďalší krok už do množiny nepridá žiadny nový neterminál.

<br>

2. Pomocou výslednej množiny $N_\varepsilon$ upravíme pravidlá v gramatike:

    a) Z gramatiky najprv odstránime všetky ε-pravidlá. Ak $S \in N_\varepsilon$ (kde $S$ je počiatočný neterminál), potom pravidlo $S \rightarrow \varepsilon$:
    * v gramatike ponecháme (iba ak sa $S$ nevyskytuje na pravej strane),
    * inak toto pravidlo odstránime, ale do gramatiky pridáme nový počiatočný neterminál $S'$ s pravidlami $S' \rightarrow S \mid \varepsilon$.

    <br>
   
    b) Prejdeme jednotlivé pravidlá v gramatike a ak sa na pravej strane vyskytuje nejaký neterminál z množiny $N_\varepsilon$, potom do gramatiky pridáme kópiu tohto pravidla, ktorá však nebude obsahovať príslušný neterminál z množiny $N_\varepsilon$. (Napríklad: $A \rightarrow aBc$ a $B \in N_\varepsilon$, potom pravidlá upravíme na $A \rightarrow aBc \mid ac$.)
      
> Poznámka: 
> Ak sa na pravej strane pravidla vyskytuje viac než jeden neterminál z množiny $N_\varepsilon$, je nutné pridať pravidlá so všetkými možnými kombináciami bez týchto neterminálov na pravej strane. 
>      
> Napríklad: $A \rightarrow bBBCD$ a $B, C \in N_\varepsilon$, potom pravidlá upravíme na $A \rightarrow bBBCD \mid bBBD \mid bBCD \mid bD \mid bBD \mid bCD \mid bBBD$.
>     
> Ak sa počas pridávania nových pravidiel dostaneme do situácie, kedy by sme do gramatiky mali vložiť ε-pravidlo, do gramatiky ho nepridáme. 
>      
> Napríklad: $A \rightarrow BC$, kde $B, C \in N_\varepsilon$, upravíme iba na $A \rightarrow BC \mid B \mid C$ a pravidlo $A \rightarrow \varepsilon$ nepridáme.
      

> Príklad:
> Majme bezkontextovú gramatiku $G = (\{S, A, B\}, \{a, b\}, P, S)$, kde $P$ obsahuje pravidlá: <br>
> $S \rightarrow AB$ <br>
> $A \rightarrow aA \mid \varepsilon$ <br>
> $B \rightarrow bB \mid \varepsilon$ <br>
> 
> Odstráňme z tejto gramatiky ε-pravidlá.
>
> Riešenie: <br>
> 1. Nájdeme množinu $N_\varepsilon$:
>    * $N_\varepsilon^0 = \{\}$
>    * $N_\varepsilon^1 = \{A, B\}$ (neterminály, ktoré majú ε-pravidlo)
>    * $N_\varepsilon^2 = \{A, B, S\}$ (pretože $S \rightarrow AB$ a oba neterminály $A$ aj $B$ sú v $N_\varepsilon^1$)
>    * $N_\varepsilon^3 = \{A, B, S\}$ (žiadne nové neterminály, takže $N_\varepsilon = \{A, B, S\}$)
>
> 2. Upravíme pravidlá:
>    * Odstránime všetky ε-pravidlá: $A \rightarrow \varepsilon$ a $B \rightarrow \varepsilon$
>    * Keďže $S \in N_\varepsilon$ a $S$ sa nevyskytuje na pravej strane žiadneho pravidla, ponecháme pravidlo $S \rightarrow \varepsilon$
>    * Upravíme pravidlo $S \rightarrow AB$:
>      * $S \rightarrow AB \mid A \mid B \mid \varepsilon$ (pretože $A, B \in N_\varepsilon$)
>      * Ale pravidlo $S \rightarrow \varepsilon$ už máme, takže výsledné pravidlá pre $S$ sú: $S \rightarrow AB \mid A \mid B \mid \varepsilon$
>    * Pravidlá pre $A$ a $B$ zostávajú bez ε-pravidiel: $A \rightarrow aA$ a $B \rightarrow bB$
>
> Výsledná gramatika je $G' = (\{S, A, B\}, \{a, b\}, P', S)$, kde $P'$ obsahuje pravidlá:
> $S \rightarrow AB \mid A \mid B \mid \varepsilon$ <br>
> $A \rightarrow aA$ <br>
> $B \rightarrow bB$ <br>

---


# Odstránenie jednoduchých pravidiel a cyklov

**Jednoduché pravidlo** je pravidlo tvaru A → B, kde A a B sú ľubovoľné neterminály. Intuitívne nám toto pravidlo hovorí, že neterminál A na ľavej strane sa "vie správať rovnako" ako neterminál B na pravej strane.

**Bezkontextová gramatika bez cyklu** je taká bezkontextová gramatika, kde nie je pre žiadny neterminál možná derivácia A ⇒<sup>+</sup> A. Platí, že ak je gramatika bez jednoduchých a ε-pravidiel, potom je bez cyklu (obrátene platiť nemusí).

# Ako z bezkontextovej gramatiky odstránime jednoduché pravidlá?

1. Iteratívne zostavíme množinu $N_A$ pre každý neterminál $A \in N$. Jedná sa o taký "uzáver" cez jednoduché pravidlá. Majme teda napríklad neterminál $A$. Množinu $N_A$ pre tento neterminál zostavíme nasledovne:
   
   a) Inicializácia: $ N^0_A = \{A\} $.
   
   b) Prvý krok: $ N^1_A = N^0_A \cup$ {všetky neterminály, ktoré spolu s neterminálom A na ľavej strane tvoria jednoduché pravidlo}.
   
   c) Druhý krok: $ N^2_A = N^1_A \cup$ {všetky neterminály, ktoré spolu s neterminálom z množiny $N^1_A $ na ľavej strane tvoria jednoduché pravidlo}.
   
   d) ...
   
   e) i-tý krok: $ N^i_A = N^{i-1}_A \cup$ {všetky neterminály, ktoré spolu s neterminálom z množiny $ N^{i-1}_A $ na ľavej strane tvoria jednoduché pravidlo}.
   
   f) ...
   
   g) Množina $N_A$ je hotová, ak ďalší krok už do množiny nepridá žiadny nový neterminál.

<br>

2. Ak máme vytvorenú množinu $N_A$  pre každý neterminál $A \in N$, upravíme pravidlá gramatiky nasledovne:
   
   a) Z gramatiky najprv odstránime všetky jednoduché pravidlá.
   
   b) Teraz budeme prechádzať jednotlivé množiny a upravovať zodpovedajúce pravidlá. Majme teda opäť napríklad neterminál A s množinou N<sub>A</sub>. Množina N<sub>A</sub> nám intuitívne hovorí, že neterminál A sa "správa" ako neterminály vo vnútri tejto množiny. Všetky pravé strany pravidiel pre neterminály z množiny N<sub>A</sub> teda nakopírujeme k neterminálu A.

> Príklad:
> Majme bezkontextovú gramatiku G. Transformujte gramatiku G na bezkontextovú gramatiku G', ktorá nebude obsahovať jednoduché pravidlá a L(G) = L(G'). <br>
>
> G = ({S, A, B, C, D}, {a, b, c, d}, P, S), kde <br>
> <br>
>   P = { 
>   S → A | B,  <br>
>   A → C | aA | bS,  <br>
>   B → D | cB | dS,  <br>
>   C → bC | a,  <br>
>   D → dD | c <br>
>   }
>
> Riešenie:
> 
> N<sub>S</sub> = {S, A, B, C, D}
> 
> N<sub>A</sub> = {A, C}
> 
> N<sub>B</sub> = {B, D}
> 
> N<sub>C</sub> = {C}
> 
> N<sub>D</sub> = {D}
>
> Teraz za použitia príslušnej množiny upravíme pravidlá pre jednotlivé neterminály:
>
> * Pravidlá pre S upravíme za použitia množiny N<sub>S</sub>. Do gramatiky G' pridáme nasledujúce pravidlá:
    >   S → aA | bS | cB | dS | bC | a | dD | c
>
> * Pravidlá pre A upravíme za použitia množiny N<sub>A</sub>. Do gramatiky G' pridáme nasledujúce pravidlá:
    >   A → aA | bS | bC | a
>
> * Pravidlá pre B upravíme za použitia množiny N<sub>B</sub>. Do gramatiky G' pridáme nasledujúce pravidlá:
    >   B → cB | dS | dD | c
>
> * Pravidlá pre C upravíme za použitia množiny N<sub>C</sub>. Do gramatiky G' pridáme nasledujúce pravidlá:
    >   C → bC | a
>
> * Pravidlá pre D upravíme za použitia množiny N<sub>D</sub>. Do gramatiky G' pridáme nasledujúce pravidlá:
    >   D → dD | c
>
> Výsledná gramatika G' bez jednoduchých pravidiel vyzerá nasledovne: <br>
>
> G' = ({S, A, B, C, D}, {a, b, c, d}, P, S), kde P = { <br>
>   S → aA | bS | cB | dS | bC | a | dD | c, <br>
>   A → aA | bS | bC | a, <br>
>   B → cB | dS | dD | c, <br>
>   C → bC | a, <br>
>   D → dD | c <br>
> } 


---

# Odstránenie ľavej rekurzie

Neterminálny symbol rekurzívny zľava je taký neterminálny symbol $A$, pre ktorý existuje derivácia $A \Rightarrow^* A\beta$, kde $\beta \in (N \cup \sigma)^*$. Rozlišujeme dva typy ľavej rekurzie:
* **priama rekurzivita zľava**, ktorá je viditeľná priamo v pravidlách pre daný neterminál (napr. A → Aa),
* **nepriama rekurzivita zľava**, ktorá nie je viditeľná priamo v pravidlách pre daný neterminál (napr. A → Ba, B → Ac).

Zľava rekurzívna gramatika je taká gramatika, ktorá má aspoň jeden neterminálny symbol rekurzívny zľava.

# Ako z bezkontextovej gramatiky odstránime priamu ľavú rekurziu?

$A \rightarrow A\alpha \mid \beta \quad $ možno zameniť za $ A \rightarrow \beta A' \mid \beta, \quad A' \rightarrow \alpha A' \mid \alpha  $  
$$ ( \alpha, \beta \in (N \cup \Sigma)^*, A \in N ) $$

Napríklad $\quad A \rightarrow Aab \mid cB \quad $ možno zameniť za $\quad A \rightarrow cBA' \mid cB, \quad A' \rightarrow abA' \mid ab.$

Pre viac výskytov  $\alpha, \beta $ možno vzorec intuitívne rozšíriť nasledovne:

$A \rightarrow A\alpha_1 \mid A\alpha_2 \mid \beta_1 \mid \beta_2 $ možno zameniť za 
$$A \rightarrow \beta_1 A' \mid \beta_2 A' \mid \beta_1 \mid \beta_2, \quad A' \rightarrow \alpha_1 A' \mid \alpha_2 A' \mid \alpha_1 \mid \alpha_2$$

# Ako z bezkontextovej gramatiky odstránime ľavú rekurziu (priamu i nepriamu)?

1. **Gramatiku najprv prevedieme na vlastnú bez jednoduchých pravidiel.** Teda odstránime ε-pravidlá, jednoduché pravidlá a potom zbytočné symboly. (Pozn. zbytočné symboly môžeme odstrániť aj na začiatku - ako prvú úpravu - rovnako je potom ale potrebné ešte na záver - po odstránení ε-pravidiel a jednoduchých pravidiel - skontrolovať, či sa počas úprav nevytvorili nejaké ďalšie zbytočné symboly)

2. Zvolíme ľubovoľné usporiadanie neterminálov $(A_1, A_2, \dots, A_n)$. Následne začneme upravovať pravidlá pre jednotlivé neterminály v gramatike, pričom začneme zľava od začiatku usporiadania. Pravidlá pre jednotlivé neterminály Aᵢ upravíme tak, že:
   
   a) Pravidlá pre neterminál $A_i$ začínajúce na pravej strane terminálnym symbolom - $tj. A_i \rightarrow a\alpha, \quad \text{kde } a \in \Sigma, \; \alpha \in (N \cup \Sigma)^*$ - neupravujeme.
   
   b) Pravidlá pre neterminál $A_i$ začínajúce na pravej strane neterminálnym symbolom $A_i$, alebo neterminálom  $A_j$, ktorý je vo zvolenom usporiadaní za neterminálom $A_i$ - to je $A_i \rightarrow A_j\alpha, \quad \text{kde } j > i, \; \alpha \in (N \cup \Sigma)^*$ - neupravujeme.
   
   c) Pravidlá pre neterminál $A_i$ začínajúce na pravej strane neterminálnym symbolom $A_j$, ktorý je vo zvolenom usporiadaní pred neterminálom $A_i$ - to je $A_i \rightarrow A_j\alpha, \quad \text{kde } j < i, \; \alpha \in (N \cup \Sigma)^* $ - upravíme tak, že za neterminál $A_j$ dosadíme všetky pravé strany pravidel pre $A_j$  (pozor, dosadzovať je občas nutné opakovane). <br>
   
   d) Akonáhle pravidlá pre neterminál $A_i$ začínajú na pravej strane iba terminálnym symbolom alebo neterminálnym symbolom $A_i$ či neterminálnym symbolom, ktorý je vo zvolenom usporiadaní za neterminálom $A_i$, potom skontrolujeme, či sa v pravidlách pre neterminál $A_i$ vyskytuje priama ľavá rekurzia. Ak áno, štandardne ju odstránime.

> Poznámka:
> Vysvetlenie C) Čiže ak máme:
> * Pravidlo $A*i \rightarrow A*j$ α, kde j < i
> * Pravidlá pre $A_j$ v tvare $ A_j \rightarrow \beta_1 \mid \beta_2 \mid \dots \mid \beta_n $
>
> Potom pravidlo $A*i \rightarrow A*j$ α nahradíme množinou pravidiel: <br>
> $ A_i \rightarrow \beta_1 \alpha \mid \beta_2 \alpha \mid \dots \mid \beta_n \alpha $

> Príklad:
>
> Majme bezkontextovú gramatiku G. Transformujte gramatiku G na bezkontextovú gramatiku G', ktorá nebude obsahovať ľavú rekurziu a L(G) = L(G'). <br>
> G = ({E, T, F}, {+, *, a, (, )}, P, E), kde  <br>
>  <br>
>   P = <br>
>   {E → E+T | T,  <br>
>   T → T*F | F,  <br>
>   F → (E) | a} <br>
>
>
> Riešenie:
> Gramatika obsahuje iba priamu ľavú rekurziu, a to pre neterminály E a T. Odstránime ju podľa návodu - nie je nutné používať "zložitejší" spôsob popísaný vyššie, pretože gramatika neobsahuje nepriamu ľavú rekurziu. <br>
>
> Gramatika G' bez ľavej rekurzie bude vyzerať nasledovne:
> G' = ({E, E', T, T', F}, {+, *, a, (, )}, P, E), kde  <br>
>  <br>
> P = <br>
> {E → TE' | T, <br> 
> E' → +TE' | +T, <br> 
> T → FT' | F, <br>
> T' → *FT' | *F, <br>
> F → (E) | a}

> Príklad:
>
> Majme bezkontextovú gramatiku G. Transformujte gramatiku G na bezkontextovú gramatiku G', ktorá nebude obsahovať ľavú rekurziu a L(G) = L(G'). <br>
> G = ({S, A, B, C, D}, {a, b, c}, P, S), kde   <br>
> 
> P =   <br>
> {S → A,   <br>
> A → Aa | Bc,   <br>
> B → Ba | CD,   <br>
> C → Cb | ε,   <br>
> D → Bb | a}   <br>
>
>
> Riešenie: <br>
> Gramatika G obsahuje priamu ľavú rekurziu pri netermináloch A, B a C. Obsahuje však aj nepriamu ľavú rekurziu pri netermináloch B (pretože existuje derivácia B => CD => Cb => Bb) a pri netermináloch D (pretože existuje derivácia D => Bb => Ba => CD => Cb => Bb). <br>
> Použijeme teda univerzálny postup na odstránenie oboch typov rekurzie. <br>
>
> 1. Gramatiku prevedieme na vlastnú bez jednoduchých pravidiel. <br>
> <br>
>    (a) Odstránime zbytočné symboly. Začneme nájdením „ukončiteľných" neterminálov: <br>
>        N⁰ = {}, N¹ = {C, D}, N² = {C, D, B}, N³ = {C, D, B, A}, N⁴ = {C, D, B, A, S} = $N_t$ => všetky neterminály sú „ukončiteľné". <br>
>        Pokračujeme teda nájdením dostupných symbolov: <br>
>        V⁰ = {S}, V¹ = {S, A}, V² = {S, A, a, B, c}, V³ = {S, A, a, B, c, C, D}, V⁴ = {S, A, a, B, c, C, D} = V => všetky symboly sú užitočné. <br>
>  <br>
>    (b) Odstránime ε-pravidlá. <br>
>        $N_\epsilon$ = {}, $N_\epsilon^1$¹ = {C}, $N_\epsilon^2$² = {C} = $N_\epsilon$. <br>
>        Gramatika bez ε-pravidiel vyzerá nasledovne: <br>
>        G = ({S, A, B, C, D}, {a, b, c}, P, S), kde <br>
>        P = {S → A, <br>
>           A → Aa | Bc, <br>
>           B → Ba | CD | D, <br>
>           C → Cb | b, <br>
>           D → Bb | a} <br>
> <br>
>    (c) Odstránime jednoduché pravidlá. <br>
>        $N_S$ = {S, A}, $N_A$ = {A}, $N_B$ = {B, D}, $N_C$ = {C}, $N_D$ = {D}. <br>
>        Gramatika bez jednoduchých pravidiel vyzerá nasledovne: <br>
>        G = ({S, A, B, C, D}, {a, b, c}, P, S), kde <br>
>        P = {S → Aa | Bc, <br>
>             A → Aa | Bc, <br>
>             B → Ba | CD | Bb | a, <br>
>             C → Cb | b, <br>
>             D → Bb | a} <br>
> <br>
>    (d) Odstránime zbytočné symboly. Žiadne nové zbytočné symboly však nevznikli. Všetky symboly v gramatike sú užitočné. <br>
>
> 2. Zvolíme usporiadanie neterminálov, napríklad: (S, A, D, B, C). Teraz ideme zľava usporiadania a kontrolujeme, či pravé strany práve kontrolovaného neterminálu nezačínajú nejakým neterminálom, ktorý je v usporiadaní skôr (ak áno, potom by sme dosadili). Toto usporiadanie však žiadne dosadzovanie nevyžaduje (máme šťastie). Vždy teda iba upravíme prípadnú priamu ľavú rekurziu pri danom neterminále. <br>
>
> Výsledná gramatika G' bez ľavej rekurzie tak vyzerá nasledovne: <br>
> G' = ({S, A, A', B, B', C, C', D}, {a, b, c}, P, S), kde   <br>
> 
> P =   <br>
> {S → Aa | Bc,   <br>
> A → BcA' | Bc,   <br>
> A' → aA' | a,   <br>
> B → a | CD | aB' | CDB',   <br>
> B' → aB' | bB' | a | b,   <br>
> C → bC' | b,   <br>
> C' → bC' | b,   <br>
> D → Bb | a} <br>






> Príklad:
>
> Transformujte gramatiku $G=(\{$`E`, `T`, `F`$\}$, $\{$`+`, `*`, `(`, `)`$\}$, $P$, `E`$)$, kde $P$ je množina nasledujúcich pravidiel:
>
> <div class="grammar">
>
|${}$|
|---|
| `E` $\to$ `E + T \| T` |
| `T` $\to$ `T * F \| F` |
| `F` $\to$ `cislo \| ( E )` |
> 
> </div>
> na bezkontextovú gramatiku $G'$, ktorá nebude obsahovať priamu ľavú rekurziu a $L(G) = L(G')$.

> Riešenie:
> Gramatika obsahuje dva ľavo rekurzívne neterminály $E$ a $T$. Gramatiku teda upravíme jednoducho podľa vyššie uvedenej schémy na nasledujúci tvar:
> $G' = (\{$`E`, `E`', `T`, `T`', `F`$\}$, $\{$`+`, `*`, `(`, `)`$\}$, $P$, `E`$)$, kde $P$ je množina nasledujúcich pravidiel:
>
> <div class="grammar">
>
|${}$|
|---|
| `E` $\to$ `T E`'$\;\;$`\| T` |
| `E`' $\to$ `+ T E`'$\;\;$`\| + T` |
| `T` $\to$ `F T`'$\;\;$`\| F` |
| `T`' $\to$ `* F T`'$\;\;$`\| * F` |
| `F` $\to$ `cislo \| ( E )` |
> 
> </div>



## Krok {ciel_syntakticky_analyzator}


Prepíšeme BNF gramatiku z predošléj úlohy do EBNF:

E $\to$ T [ E' ] <br>
E' $\to$ + T [ E' ] <br>
T $\to$ F [ T' ] <br>
T' $\to$ * F [ T' ] <br>
F $\to$ cislo \| ( E )  <br>

<!---
[] sposobuju fatal error a neviem najst ako ich spojazdnit

<div class="grammar"

|${}$|
|---|
| `E` $\to$ `T \[ E' \]`  |
| `E'`' $\to$ `+ T \[ E' \]` |
| `T` $\to$ `F \[ T' \]` |
| `T'`' $\to$ `* F \[ T' \]` |
| `F` $\to$ `cislo \| ( E )` |
 
</div>
--->

Na to aby sme avšak vedeli túto gramatiku implementovať do python kódu si musíme vysvetliť ako implementovať voliteľnosť.

<div>

```python
    def E(self):
        # Implementácia pravidla: E → T [E']
        # Spracuje T.
        node = self.T()
        
        # A následne sa pozrieme na voliteľné E_prime. 
        # Ak nasleduje '+', vykonáme aj E' procedúru.
        if self.current_token.type == TokenType.PLUS:
            node = self.E_prime(node)
        
        return node
```
  
</div>

Pozrime sa na vizualizáciu znázorňujúcu proces syntaktickej analýzy pre jednoduchý výraz 3 + 7 podľa zadanej gramatiky.

<!---
<div style="display: grid; grid-template-columns: 1fr 1fr;justify-content: center;
  align-items: center;">
  <div>

  ![Vizualizácia syntaktickej analýzy](resources/cv7_new/3plus7.PNG)
  </div>
  <div>

  ![Zjednodušená vizualizácia syntaktickej analýzy](resources/cv7_new/3plus7jednoduchy.PNG)
  </div>
</div>
--->


<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; justify-content: center; align-items: start;">
  <div style="text-align: center;">
    <div style="height: 300px; display: flex; align-items: center; justify-content: center;">
      <img src="resources/cv7_new/3plus7.PNG" alt="Vizualizácia syntaktickej analýzy" style="max-height: 100%; max-width: 100%; object-fit: contain;">
    </div>
    <p style="margin-top: 5px;">Vizualizácia syntaktickej analýzy</p>
  </div>
  <div style="text-align: center;">
    <div style="height: 300px; display: flex; align-items: center; justify-content: center;">
      <img src="resources/cv7_new/3plus7jednoduchy.PNG" alt="Zjednodušená vizualizácia syntaktickej analýzy" style="max-height: 100%; max-width: 100%; object-fit: contain;">
    </div>
    <p style="margin-top: 5px;">Zjednodušená vizualizácia syntaktickej analýzy</p>
  </div>
</div>

<br>
<br> 

1. Začíname neterminálom E, ktorý sa podľa pravidla E → T [E'] rozkladá na T a E'.
2. T sa podľa pravidla T → F [T'] rozkladá na F a T'.
* F sa prepisuje na číslo 3.
* T' sa prepisuje na ε (prázdny reťazec), keďže po čísle 3 nenasleduje operátor násobenia.
* F vracia hodnotu 3 späť do T.
* T' vracia ε (nemení hodnotu), takže T celkovo vracia hodnotu 3.


3. E' sa podľa pravidla E' → + T [E'] prepisuje na + T E'.
* Operátor + indikuje operáciu sčítania.
* T sa rozkladá na F a T'.
  * F sa prepisuje na číslo 7.
  * T' sa prepisuje na ε (prázdny reťazec), pretože po čísle 7 nenasleduje operátor násobenia.
  * F vracia hodnotu 7 späť do T.
  * T' vracia ε (nemení hodnotu), takže T celkovo vracia hodnotu 7.


* Druhé E' sa prepisuje na ε (prázdny reťazec), pretože po čísle 7 nenasleduje ďalší operátor sčítania.
* E' vykoná sčítanie 3 + 7 = 10 a vracia túto hodnotu späť do E.


4. E teda vracia konečný výsledok 10.

Hodnoty sa propagujú nahor cez jednotlivé neterminálne symboly, pričom každý z nich prispieva k výslednému výpočtu podľa sémantických pravidiel.


<!---



<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; justify-content: center; align-items: start;">
  <div style="text-align: center;">
    <div style="height: 300px; display: flex; align-items: center; justify-content: center;">
      <img src="resources/cv7_new/2plus3krat4.PNG" alt="Vizualizácia syntaktickej analýzy" style="max-height: 100%; max-width: 100%; object-fit: contain;">
    </div>
    <p style="margin-top: 5px;">Vizualizácia syntaktickej analýzy</p>
  </div>
  <div style="text-align: center;">
    <div style="height: 300px; display: flex; align-items: center; justify-content: center;">
      <img src="resources/cv7_new/2plus3krat4jednoduchy.PNG" alt="Zjednodušená vizualizácia syntaktickej analýzy" style="max-height: 100%; max-width: 100%; object-fit: contain;">
    </div>
    <p style="margin-top: 5px;">Zjednodušená vizualizácia syntaktickej analýzy</p>
  </div>
</div>

<br>
<br> 


1. Začíname s neterminálom E, ktorý sa podľa pravidla E → T [E'] prepisuje na T a E'.

2. T sa podľa pravidla T → F [T'] prepisuje na F a T'.
* F sa ďalej prepisuje na číslo 2.
* T' sa prepisuje na ε (prázdny reťazec), keďže tam nie je operácia násobenia.
* F vráti hodnotu 2 späť do T.
* T' vráti ε (nemení hodnotu), takže T celkovo vracia hodnotu 2.


3. E' sa podľa pravidla E' → + T [E'] prepisuje na + T E'.

* Operátor + indikuje operáciu sčítania.
* T sa rozkladá na F a T'.

  * F sa ďalej prepisuje na číslo 3.
  * T' sa prepisuje na * F T'.

    * Operátor * indikuje operáciu násobenia.
    * F sa ďalej prepisuje na číslo 4.
    * T' sa prepisuje na ε (prázdny reťazec).
    * F vracia hodnotu 4 späť do T'.
    * T' vykoná násobenie 3 * 4 = 12 a vracia túto hodnotu do T.


  * T teda vracia hodnotu 12.


* Druhé E' sa prepisuje na ε.
* E' vykoná sčítanie 2 + 12 = 14 a vracia túto hodnotu späť do E.


4. E teda vracia konečný výsledok 14.

Hodnoty sa propagujú nahor cez jednotlivé neterminálne symboly, pričom každý z nich prispieva k výslednému výpočtu podľa sémantických pravidiel.

--->

[Kostra projektu na stiahnutie je dostupná tu. ](resources/cv7_new/CV7task.zip)

> Úloha:
> Vašou úlohou je analyzovať zdrojový kód napísaný v pythone a doplniť funkcionalitu.

<div>

```python
from lexer import TokenType, Token, Lexer

class Parser:
    def __init__(self, lexer):
        # Inicializácia parsera s lexikálnym analyzátorom 
        self.lexer = lexer
        # Načítanie prvého tokenu zo vstupu
        self.current_token = self.lexer.get_next_token()

    def error(self, expected=None):
        # Funkcia na generovanie chybových hlásení pri syntaktickej analýze
        token_str = f"{self.current_token.type}"
        if self.current_token.attribute is not None:
            token_str += f" (hodnota: {self.current_token.attribute})"
        
        if expected:
            raise SyntaxError(f"Syntaktická chyba: Očakávané {expected}, získané {token_str}")
        else:
            raise SyntaxError(f"Syntaktická chyba: Neočakávaný token {token_str}")

    def eat(self, token_type):
        # Kontrola, či aktuálny token zodpovedá očakávanému typu
        # Ak áno, posunie sa na ďalší token, ak nie, vyhlási chybu
        if self.current_token.type == token_type:
            self.current_token = self.lexer.get_next_token()
        else:
            self.error(expected=token_type)

    def E(self):
        # Implementácia pravidla: E → T [E']
        # Spracuje T a následne voliteľne E_prime
        node = self.T()
        
        # Ak nasleduje '+', spracuje aj E'
        if self.current_token.type == TokenType.PLUS:
            node = self.E_prime(node)
        
        return node

    def E_prime(self, left):
        # Implementácia pravidla: E' → + T [E']
        # Spracuje operáciu sčítania a prípadné ďalšie sčítania
        
        # TODO: Implementujte E'

    def T(self):
        # Implementácia pravidla: T → F [T']
        # Spracuje faktor a následne voliteľne T_prime
        
        # TODO: Implementujte T

    def T_prime(self, left):
        # Implementácia pravidla: T' → * F [T']
        # Spracuje operáciu násobenia a prípadné ďalšie násobenia 
        if self.current_token.type == TokenType.MULTIPLY:
            self.eat(TokenType.MULTIPLY)
            right = self.F()
            result = left * right
            
            if self.current_token.type == TokenType.MULTIPLY:
                return self.T_prime(result)
            return result
        
        return left

    def F(self):
        # Implementácia pravidla: F → cislo | ( E )
        # Spracuje buď číslo alebo výraz v zátvorkách
        token = self.current_token

        if token.type == TokenType.NUMBER:
            self.eat(TokenType.NUMBER)
            return token.attribute

        elif token.type == TokenType.LPAREN:
            self.eat(TokenType.LPAREN)
            result = self.E()
            self.eat(TokenType.RPAREN)
            return result

        self.error()

    def parse(self):
        # Hlavná metóda parsera - začína analýzu výrazu
        # Implementuje celkové vyhodnotenie výrazu
        result = self.E()
        
        # Kontrola, či sa spracoval celý vstup
        if self.current_token.type != TokenType.EOF:
            self.error(expected="koniec výrazu")
            
        return result
```
  
</div>

## Krok {ciel_chomsky}

# Chomského normálny tvar gramatiky

Každú bezkontextovú gramatiku možno previesť do normálneho tvaru podľa Chomského. Bezkontextová gramatika je v **normálnom tvare podľa Chomského**, ak má iba pravidlá tvaru: <br>
* $A \rightarrow a$ alebo $A \rightarrow BC$ kde 
$$A, B, C \in N, a \in \Sigma$$

Jedinou povolenou výnimkou z týchto pravidiel je pravidlo $S \rightarrow \varepsilon$. Toto pravidlo sa v gramatike môže vyskytnúť za predpokladu, že počiatočný neterminál $S$ sa nevyskytuje na pravej strane žiadneho pravidla.

# Ako prevedieme bezkontextovú gramatiku do normálneho tvaru podľa Chomského?

1. Gramatiku najprv **prevedieme na vlastnú bez jednoduchých pravidiel**. Teda odstránime $\varepsilon$-pravidlá, jednoduché pravidlá a následne zbytočné symboly. (Poznámka: zbytočné symboly môžeme odstrániť aj na začiatku - ako prvú úpravu - rovnako je však potrebné ich skontrolovať aj na záver - po odstránení $\varepsilon$-pravidiel a jednoduchých pravidiel - či sa počas úprav nevytvorili nejaké ďalšie zbytočné symboly.)

2. Následne budeme **prechádzať jednotlivé pravidlá** a prípadne ich **upravovať** do požadovaného tvaru:
   
   a) Pravidlá tvaru $A \rightarrow a$ a $A \rightarrow BC$ (kde $A, B, C \in N, a \in \Sigma$) neupravujeme. <br>
   
   b) Všetky pravé strany pravidiel, kde sa vyskytuje terminál v kombinácii s ďalšími symbolmi, upravíme tak, že **terminál nahradíme novým neterminálom.** Napríklad: <br>
   $A \rightarrow BaC$ (kde $A, B, C \in N, a \in \Sigma$) nahradíme pravidlami: <br>
   $A \rightarrow Ba'C, a' \rightarrow a$, kde $a'$ je nový neterminál. <br>
   
   c) Ak je pravá strana tvorená **viac než dvoma neterminálmi**, postupným „ukrajovaním" vytvoríme postupnosť nových pravidiel spĺňajúcich obmedzenie dvoch neterminálov na pravej strane. Napríklad: <br>
   $A \rightarrow ABCD$ (kde $A, B, C, D \in N$) nahradíme postupnosťou pravidiel: <br>
   $A \rightarrow A(BCD)$ <br>
   $(BCD) \rightarrow B(CD)$ <br>
   $(CD) \rightarrow CD$,  <br>
   kde $(BCD), (CD) \in N$. <br>


> Príklad:
>
> Majme vlastnú bezkontextovú gramatiku $G$ bez jednoduchých pravidiel. Transformujme gramatiku $G$ na bezkontextovú gramatiku $G'$, ktorá bude v normálnom tvare podľa Chomského a $L(G) = L(G')$.
>
> $G = (\{S, A, B\}, \{a, b\}, P, S)$, kde $P = \{S \rightarrow aB|bA, A \rightarrow aS|bAA|a, B \rightarrow AA|aBBaA\}$
> 
> 
> Riešenie:
> 
> Vstupná gramatika je už vlastná a bez jednoduchých pravidiel. Iba teda jednotlivé pravidlá upravíme do normálneho tvaru podľa Chomského.
> 
> 1. $S \rightarrow aB \Rightarrow$ do $G'$ pridáme pravidlá: $S \rightarrow a'B, a' \rightarrow a$.
> 2. $S \rightarrow bA \Rightarrow$ do $G'$ pridáme pravidlá: $S \rightarrow b'A, b' \rightarrow b$.
> 3. $A \rightarrow aS \Rightarrow$ do $G'$ pridáme pravidlo: $A \rightarrow a'S$. Pravidlo $a' \rightarrow a$ už gramatika $G'$ obsahuje.
> 4. $A \rightarrow bAA \Rightarrow$ do $G'$ pridáme pravidlá: $A \rightarrow b'(AA), (AA) \rightarrow AA$. Pravidlo $b' \rightarrow b$ už $G'$ obsahuje.
> 5. $A \rightarrow a \Rightarrow$ do $G'$ iba toto pravidlo prekopírujeme.
> 6. $B \rightarrow AA \Rightarrow$ do $G'$ iba toto pravidlo prekopírujeme.
> 7. $B \rightarrow aBBaA \Rightarrow$ do $G'$ pridáme pravidlá: $B \rightarrow a'(BBa'A), (BBa'A) \rightarrow B(Ba'A), (Ba'A) \rightarrow B(a'A), (a'A) \rightarrow a'A$. Pravidlo $a' \rightarrow a$ už gramatika obsahuje.
> 
> Výsledná gramatika $G'$ v normálnom tvare podľa Chomského vyzerá teda nasledovne:
> 
> $G' = (\{S, A, B, (AA), (BBa'A), (Ba'A), (a'A), a', b'\}, \{a, b\}, P', S)$, kde 
> $P' = \{S \rightarrow a'B | b'A, A \rightarrow a'S | b'(AA) | a, B \rightarrow AA | a'(BBa'A), (BBa'A) \rightarrow B(Ba'A), (Ba'A) \rightarrow B(a'A), (a'A) \rightarrow a'A, a' \rightarrow a, b' \rightarrow b\}$
> 


<br>
<br>


## Krok {ciel_ulohy}


> Úloha:
>
> Majme bezkontextovú gramatiku G. Transformujte G na bezkontextovú gramatiku G', ktorá nebude obsahovať zbytočné symboly a L(G) = L(G'). <br>
>
> G = ({S, A, B, C, D}, {0,1}, P, S), kde <br>
> P = {S → 0S | 1D | ε, <br>
> A → 0CB | 0AD, <br>
> B → 1B | 110, <br>
> C → 1CC | 0A1B, <br>
> D → 11A | 0D00 | 1S | ε} <br>
>


> Vyučujúci: 
> Heslo je tajneheslo1.

<details>
  <summary>Zobraziť riešenie</summary>
  <p><strong>Odpoveď:</strong></p>
  <div id="solution1" style="display:none;">

Riešenie: <br>
N⁰ = {} <br>
N¹ = {S, B, D} <br>
N² = {S, B, D} = Nₜ <br>

Vidíme, že A, C ∉ Nₜ. Neterminály A, C sú zbytočné a z gramatiky ich odstránime. Gramatika G' tak bude po prvej fáze vyzerať nasledovne:  <br>

G' = ({S, B, D}, {0, 1}, P, S), kde <br>
P = {S → 0S | 1D | ε, <br>
B → 1B | 110, <br>
D → 0D00 | 1S | ε} <br>

V⁰ = {S} <br>
V¹ = {S, 0, 1, D} <br>
V² = {S, 0, 1, D} = V <br>

Vidíme, že B ∉ V. Tento symbol je tak zbytočný a z gramatiky ho môžeme odstrániť. Výsledná gramatika G' bez zbytočných symbolov bude vyzerať nasledovne: <br>

G' = ({S, D}, {0, 1}, P, S), kde P = {S → 0S | 1D | ε, D → 0D00 | 1S | ε} <br>


  </div>
  <input type="password" id="password1" placeholder="Zadajte heslo">
  <button onclick="checkPassword1()">Odomknúť</button>
</details>

<script>
function checkPassword1() {
  var password1 = document.getElementById("password1").value;
  if (password1 === "tajneheslo1") {
    document.getElementById("solution1").style.display = "block";
  } else {
    alert("Nesprávne heslo!");
  }
}
</script>




> Úloha:
>
> Majme nasledujúcu bezkontextovú gramatiku G. Transformujte gramatiku G na bezkontextovú gramatiku G', ktorá nebude obsahovať ε-pravidlá a L(G) = L(G').
>
> G = ({S, A, B, C, D}, {0,1,2,3}, P, S), kde <br>
> P = {S → 0A0 | 0, <br>
>      A → BC | 2 | CCC, <br>
>      B → 1C | 3D | ε, <br>
>      C → A3 | ε, <br>
>      D → A | 2} <br>
>


> Vyučujúci: 
> Heslo je tajneheslo2.

<details>
  <summary>Zobraziť riešenie</summary>
  <p><strong>Odpoveď:</strong></p>
  <div id="solution2" style="display:none;">

 Riešenie: <br>
 N⁰ₑ = {} <br>
 N¹ₑ = {B, C} <br>
 N²ₑ = {B, C, A} <br>
 N³ₑ = {B, C, A, D} <br>
 N⁴ₑ = {B, C, A, D} = Nₑ <br>

 G' = ({S, A, B, C, D}, {0,1,2,3}, P, S), kde <br>
 P = {S → 0A0 | 00 | 0, <br>
      A → BC | B | C | 2 | CCC | CC, <br>
      B → 1C | 1 | 3D | 3, <br>
      C → A3 | 3, <br>
      D → A | B | 2} <br>
     

  </div>
  <input type="password" id="password2" placeholder="Zadajte heslo">
  <button onclick="checkPassword2()">Odomknúť</button>
</details>

<script>
function checkPassword2() {
  var password = document.getElementById("password2").value;
  if (password === "tajneheslo2") {
    document.getElementById("solution2").style.display = "block";
  } else {
    alert("Nesprávne heslo!");
  }
}
</script>

> Úloha:
>
> Majme bezkontextovú gramatiku G. Transformujte gramatiku G na bezkontextovú gramatiku G', ktorá nebude obsahovať jednoduché pravidlá a L(G) = L(G').
>
> G = ({S, A, B, C}, {a, b}, P, S), kde <br>
> P = {S → aBa | A, <br>
>      A → aA | B, <br>
>      B → bB | AB | C | ε, <br>
>      C → bA | b} <br>
>


> Vyučujúci: 
> Heslo je tajneheslo3.

<details>
  <summary>Zobraziť riešenie</summary>
  <p><strong>Odpoveď:</strong></p>
  <div id="solution3" style="display:none;">

 Riešenie: <br>
 $N_s$ = {S, A, B, C} <br>
 $N_a$ = {A, B, C} <br>
 $N_b$ = {B, C} <br>
 $N_c$ = {C} <br>

 G' = ({S, A, B, C}, {a, b}, P, S), kde <br>
 P = {S → aBa | aA | bB | AB | bA | b | ε, <br>
      A → aA | bB | AB | bA | b | ε, <br>
      B → bB | AB | bA | b | ε, <br>
      C → bA | b} <br>

     

  </div>
  <input type="password" id="password3" placeholder="Zadajte heslo">
  <button onclick="checkPassword3()">Odomknúť</button>
</details>

<script>
function checkPassword3() {
  var password = document.getElementById("password3").value;
  if (password === "tajneheslo3") {
    document.getElementById("solution3").style.display = "block";
  } else {
    alert("Nesprávne heslo!");
  }
}
</script>


> Úloha:
>
> Majme bezkontextovú gramatiku G. Transformujte gramatiku G na bezkontextovú gramatiku G', ktorá nebude obsahovať ľavú rekurziu a L(G) = L(G'). <br>
>
> G = ({A, B, C}, {a, b, c}, P, A), kde <br>
> P = {A → aaB | BC, <br>
>      B → abB | bb | Ac, <br>
>      C → bbC | cC | c} <br>
>


> Vyučujúci: 
> Heslo je tajneheslo4.

<details>
  <summary>Zobraziť riešenie</summary>
  <p><strong>Odpoveď:</strong></p>
  <div id="solution4" style="display:none;">

 Riešenie: <br>
 Táto gramatika obsahuje iba nepriamu ľavú rekurziu, a to u neterminálov: <br>
 A (pretože existuje derivácia A => BC => AcC) a <br>
 B (pretože existuje derivácia B => Ac => BCc). <br>

 Použijeme teda univerzálny postup na odstránenie oboch typov rekurzie. <br>

 1. Gramatika je už vlastná bez jednoduchých pravidiel (nie je potrebné previesť). <br>
 2. Zvolíme usporiadanie: (A, B, C). V rámci usporiadania postupujeme zľava a upravujeme pravidlá pre jednotlivé neterminály: <br>
    • (A → aaB | BC) v poriadku, teda neupravujeme, <br>
    • (B → abB | bb | Ac) dosadíme za neterminál A: <br>
      B → abB | bb | aaBc | BCc <br>
      odstránime priamu ľavú rekurziu: <br>
      B → abB | bb | aaBc | abBB' | bbB' | aaBcB', <br>
      B' → CcB' | Cc <br>
    • (C → bbC | cC | c) v poriadku, neupravujeme. <br>

 Výsledná gramatika G' bez ľavej rekurzie tak vyzerá nasledovne: <br>
 G' = ({A, B, B', C}, {a, b, c}, P, A), kde <br>
 P = {A → aaB | BC, <br>
      B → abB | bb | aaBc | abBB' | bbB' | aaBcB', <br>
      B' → CcB' | Cc, <br>
      C → bbC | cC | c} <br>


  </div>
  <input type="password" id="password4" placeholder="Zadajte heslo">
  <button onclick="checkPassword4()">Odomknúť</button>
</details>

<script>
function checkPassword4() {
  var password = document.getElementById("password4").value;
  if (password === "tajneheslo4") {
    document.getElementById("solution4").style.display = "block";
  } else {
    alert("Nesprávne heslo!");
  }
}
</script>

# Dotazník na ohodnotenie učiva
Vážení študenti, <br>
poprosil by som Vás o vyplnenie tohto [dotazníka](https://forms.gle/siCxzEJ37fGM8WgF6) .   <br>

Tento dotazník slúži na ohodnotenie vašich skúseností s pripravenými materiálmi z siedmeho cvičenia. Na vylepšovaní učiva sa aktívne pracuje a Vaše odpovede nám pomôžu zlepšiť kvalitu výučby. <br>

Ďakujem<br>