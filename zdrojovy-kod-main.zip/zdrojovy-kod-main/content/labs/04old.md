---
Nadpis: Lexikálna analýza.
---

## Ciele

  1. {ciel_opakovanie} Zopakovať si definíciu a vlastnosti gramatiky a formu zápisu pomocou BNF.
  2. {ciel_gramatika} Porozumieť konštrukcii gramatiky.
  3. {ciel_prior_asoc} Naučiť sa definovať syntax operátorov rôznych priorít a asociatívnosti pomocou gramatiky.
  4. {ciel_ast} Naučiť sa zostrojiť gramatiku podľa špecifikácie.


## Úvod

V tomto cvičení predstavíme základné poznatky a precvičíme praktické zručnosti, ktoré budú základom pre úspešné vypracovanie druhého zadania - kalkulačky aritmetických výrazov. Zameriame sa na konštrukciu gramatiky a na porozumenie priority a asociatívnosti operátorov.

## Krok {ciel_opakovanie}

V tomto kroku si zopakujte základnú definíciu gramatiky a možnosti jej vyjadrenia pomocou BNF, ktoré boli predstavené v <a href="03.html">Cvičení 3</a>.

>Úloha:
> Zopakujte si:
> - Čo je to gramatika?
> - Čo je typické pre bezkontextové gramatiky?
> - Ako sa odlišujú regulárne a bezkontextové gramatiky a aké sú hlavné účely ich použitia?

## Krok {ciel_gramatika}

Zopakujeme, že na vyjadrenie gramatiky jazyka sa väčšinou používa _Backusova-Naurova forma (BNF)_ , prípadne niektoré jej rozšírenia. Na tomto predmete to bude *rozšírená Backusova-Naurova forma* (Extended BNF).

> Úloha:
> Aké sú rozdiely medzi základnou BNF a rozšírenou EBNF?

Základnými prvkami gramatiky sú pravidla a symboly. Symboly môžu byť terminálne (také, ktoré môžu byť prítomné na vstupe), alebo neterminálne. Pravidlá sa zapisujú v obvyklom tvare:
 
```
neterminal → postupnosť symbolov a operátorov
```
                         

Pri zápise v EBNF budeme používať tie isté operátory, aké boli použité zápise regulárnych jazykov.

Zápis | Význam
------|----------
`\|`  | alternatíva
`{}`  | opakovanie 0 alebo viackrát
`[]`  | voliteľnosť


## Krok {ciel_prior_asoc}

Ak je syntaktický analyzátor implementovaný pomocou rekurzívnych funkcií, prioritu a asociatívnosť operátorov je možné vyjadriť tvarom a poradím pravidiel gramatiky.

Pre zabezpečenie správnej **priority operátorov** sa pre každú prioritnú úroveň vytvorí jeden neterminál. Pravidlá sa pre jednotlivé úrovne zreťazia tak, že smerom dovnútra (vnáranie k operandom) sa zvyšuje priorita.

**Asociatívnosť operátorov** je zabezpečená tvarom pravidla nasledovne:

Asociatívnosť | Pravidlo
---|---
ľavá | `E → T { op T }`
pravá | `E → T [ op E ]`
neasociatívnosť | `E → T [ op T ]`

> Úloha:
> Vytvorte gramatiku pre jazyk aritmetických výrazov, s podporou operácií pre sčítanie, odčítanie, násobenie a delenie, pri zachovaní štandardných priorít a asociatívností. Jazyk výrazov obsahuje tiež zátvorky, výrazy obsahujú celé čísla a identifikátory. 

> Vyučujúci: 
>
> `E ->  T  { ( + | - ) T }` \
> `T ->  F  { ( * | / ) F }`	\
> `F ->  cislo | id | ( E )`


 
> Úloha:
> Pridajte do uvedenej gramatiky pravidlo pre operátor *unárne mínus*.
>


> Úloha:
> Uveďte pre každý typ asociatívnosti niektoré typické operácie. Vysvetlite vplyv tvaru gramatiky na postupnosť volaní jednotlivých funkcií.
>

> Vyučujúci:
> Vplyv tvaru gramatiky na postupnosť volaní jednotlivých funkcií je znázornený na nasledujúcom obrázku.
>
> ![Stromy odvodenia pri rôznej priorite operátorov](resources/priorita.png)
>
>
>
> ![Stromy odvodenia pri rôznej asociatívnosti operátora](resources/asociativnost.png)

> Úloha:
> Pridajte do rozšírenej gramatiky z tohto kroku operáciu mocniny "^" a operáciu zvyšku po delení "%" pri dodržaní obvyklých matematických pravidiel priority a asociatívnosti.


## Krok {ciel_ast}

> Úloha:
>Predpokladajme jazyk aritmetických výrazov tvorený identifikátormi (tokenmi), zátvorkami a dvoma binárnymi operátormi &#8855; a &#8853;. Pre uvedené operátory platia nasledujúce vlastnosti:
>
> * operátor &#8853; má vyššiu prioritu ako operátor &#8855;
> * operátor &#8853; je pravo-asociatívny
> * operátor &#8855; je ľavo-asociatívny.
>
> Nakreslite strom odvodenia pre reťazec **id** &#8853; **id** &#8853; **id** &#8855; **id** &#8855; **id** podľa Vašej gramatiky a vysvetlite štruktúru výrazu podľa priority a asociatívnosti.

> Vyučujúci:
> Použijeme tradičné označenia pre neterminály: `F` pre najvyššiu úroveň (operandy a zátvorky), `T` pre úroveň s operátorom ⊕ a `E` pre úroveň s operátorom ⊗, pričom tento neterminál je zároveň štartovacím symbolom gramatiky. Vzhľadom na asociatívnosť je vhodné použiť ľavú rekurziu pre ľavú asociatívnosť a pravú rekurziu pre pravú asociatívnosť. Gramatika by vyzerala nasledovne:
>
> `E → E ⊗ T | T`\
> `T → F ⊕ T | F`\
> `F → id | (E)`
>
> Odvodzovací strom vyzerá nasledovne:
> 
>![Strom odvodenia](resources/cv5/strom_odvodenia.png)
>
> Štruktúra reťazca podľa pravidiel a vyjadrená v strome odvodenia môže byť explicitne znázornená pomocou hranatých zátvoriek (kvôli zohľadneniu priority a asociatívnosti) takto:
>
> `[[id ⊕ [id ⊕ id]] ⊗ id] ⊗ id`
>

## Doplňujúce úlohy

> Úloha:
> Navrhnite gramatiku pre klasickú vreckovú kalkulačku, ktorá nerozlišuje priority operátorov.
> Výsledok pre `10+2*3` je `36` a pre `2*3+10` je výsledok `16`.

> Úloha:
> Rozšírte gramatiku z kroku 3 rozšírte o operátor `==`, ktorý je neasociatívny, má najnižšiu prioritu, a správa sa ako operátor nerovnosti.